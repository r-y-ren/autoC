"""LLM harness for OpenSpiel Backgammon.

Drop the body of this file into the notebook attached to the competition via
``HarnessKernelId``. The auto-generated ``main.py`` calls these three
module-level functions: ``get_legal_moves``, ``generate_prompt``,
``parse_response``.

Backgammon is a two-player race. Player 0 ('x') and Player 1 ('o') each have
fifteen checkers. The board has 24 points plus a bar and a bear-off tray.
Both dice are rolled by the game (the framework hides chance nodes from
agents), and on each turn the active player consumes both dice values --
each die moves one checker that many pips toward home. Whichever player
bears off all fifteen checkers first wins.

OpenSpiel exposes legal moves with action strings of the form
``"<action_id> - <notation>"`` (for example ``"648 - Bar/21 Bar/20"`` or
``"0 - 24/23 24/22"``). Notation is *player-relative*: each player counts
from their own 1-point. The proxy observation, by contrast, is in
*absolute* OpenSpiel coordinates (``board[0..23]``). The harness translates
between the two so the prompt and the action notation use the same
numbering as the legal-move strings.
"""

from __future__ import annotations

import json
import re
from typing import Any, Mapping, Sequence

import pyspiel

from kaggle_environments.core_harness import ParseResult, parse_json_action, render_rethink_suffix

# Players: 0 = X, 1 = O (matches the proxy's "x"/"o" labels).
_PLAYER_LABELS = {0: "x", 1: "o"}


# --- Coordinate conversion --------------------------------------------------


def _abs_to_point(player_id: int, abs_pos: int) -> int:
    """OpenSpiel absolute pos (0..23) -> player-relative point (1..24).

    Player O numbers points 1..24 in increasing OpenSpiel order; player X
    uses the mirror, so their 1-point is OpenSpiel pos 23.
    """
    if player_id == 1:
        return abs_pos + 1
    return 24 - abs_pos


# --- Prompt -----------------------------------------------------------------


BACKGAMMON_PROMPT_TEMPLATE = """Let's play Backgammon.

Rules: Each player has 15 checkers. Player 0 plays 'x' and player 1 plays
'o'. The board has 24 points numbered 1..24 from your own perspective:
points 1-6 are your home board (where you bear off from), 7-12 your outer
board, 13-18 your opponent's outer board, and 19-24 your opponent's home
board. Your checkers move from high-numbered points down toward your
1-point, then off the board. Your opponent moves the opposite way on the
same board.

The two dice are already rolled for you. On your turn you must use BOTH
dice if possible -- each die moves one of your checkers that many pips
toward your 1-point. You may move two different checkers, or use both dice
on the same checker. A move is legal only if the destination point is (a)
empty, (b) occupied by your own checkers, or (c) occupied by exactly one
opposing checker (a "blot") -- landing on a blot sends it to the bar and
the destination becomes yours. A point with two or more opposing checkers
is blocked.

If you have any checker on the bar you MUST re-enter it before making any
other move. Bar entries go to your opponent's home board: a die value of N
brings the checker to your point (25 - N). Once every checker is in your
home board (points 1-6) you may bear off: a die of N bears off the checker
on your N-point. If no checker sits on your N-point, you may bear off the
checker furthest from home, but only when N exceeds the highest occupied
point.

If only ONE of the two dice can be legally used, you must still account for
the unused die by writing ``Pass`` in its place (e.g. ``Bar/24 Pass`` means
"enter from the bar with one die, the other die is unusable"). Write the
move first and ``Pass`` second. Write a bare ``Pass`` only when NEITHER
die can be played at all.

You win by bearing off all fifteen of your checkers first. If neither
player has borne off all checkers within 500 player turns, the game ends
in a draw.

Dice rolled this turn: {dice_str}
Move number: {move_number}
Bar -- yours: {my_bar}, opponent's: {opp_bar}
Borne off -- yours: {my_off}, opponent's: {opp_off}

Your checkers (point: count):
{my_points}

Opponent's checkers (point: count):
{opp_points}

Moves you have played so far: {move_history}

You are Player {player_id} ('{my_piece}'). Choose a single legal move that
uses BOTH dice when possible.

Action notation: use the part AFTER the ``" - "`` in legal-move strings.
Examples (your own perspective in every case):
* ``24/23 24/22`` -- two different checkers, one die each.
* ``13/11 13/8`` -- two different starting points.
* ``24/22/21`` -- same checker uses both dice in sequence (24 -> 22 -> 21).
* ``13/11(2)`` -- doubles: the same start/end is played twice.
* ``Bar/22`` -- enter from the bar onto your 22-point.
* ``6/Off`` -- bear off the checker on your 6-point.
* ``13/8*`` -- a hit: if your destination has exactly one opponent checker
  (a blot), append ``*`` to that step. Without the ``*`` the move will be
  rejected as illegal.
* ``Bar/24 Pass`` -- the second die cannot be used. ``Pass`` always comes
  after the playable move. Bare ``Pass`` is only for turns where neither
  die can be played.

Tradition is to list moves with the higher starting point first.

Respond with your reasoning followed by your move in a JSON block:

```json
{{
  "move": "<notation>"
}}
```

For example: `{{"move": "24/23 24/22"}}`

Failure to output your final answer in the specified format, or selecting
an illegal move, will result in a loss.
"""


RETHINK_ILLEGAL = """

You suggested move "{previous_action}" but this is not a legal move.
Reconsider the rules and the current state, then pick a legal move.

(Keep using the same JSON output format as before -- only the move value needs to change.)
"""

RETHINK_UNPARSABLE = """

Your previous response ended with:
{previous_response}

No JSON answer could be parsed from that. Conclude your response
with your final move as JSON in a ```json fenced block, exactly
as the original instructions required:

```json
{{"move": "<notation>"}}
```

For example: `{{"move": "24/23 24/22"}}`

The move you choose must also be legal in the current state.
"""


# --- Helpers ----------------------------------------------------------------


def _parse_observation_payload(observation: Mapping[str, Any]) -> dict[str, Any]:
    """Pull the structured backgammon state dict out of the observation."""
    raw = observation.get("observationString", "") or ""
    if raw:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
    serialized = observation.get("serializedGameAndState", "")
    if serialized:
        _, state = pyspiel.deserialize_game_and_state(serialized)
        try:
            return json.loads(state.observation_string(0))
        except (json.JSONDecodeError, RuntimeError):
            pass
    return {}


def _format_points_for_player(
    board: Sequence[Mapping[str, Any] | None],
    player_id: int,
    want_label: str,
) -> str:
    """Render occupied points (for one side) in player-relative numbering."""
    entries: list[tuple[int, int]] = []  # (player_point, count)
    for abs_pos, slot in enumerate(board):
        if not slot:
            continue
        if slot.get("player") != want_label:
            continue
        point = _abs_to_point(player_id, abs_pos)
        entries.append((point, int(slot.get("count", 0))))
    if not entries:
        return "  (none on the board)"
    entries.sort(key=lambda t: -t[0])  # high to low, matches play order
    return "\n".join(f"  point {pt:>2}: {ct}" for pt, ct in entries)


def _format_dice(dice: Sequence[Mapping[str, Any]]) -> str:
    """Render the dice as ``"3, 5"`` (omit dice already consumed)."""
    if not dice:
        return "(none rolled)"
    remaining = [str(d.get("value")) for d in dice if not d.get("used")]
    if not remaining:
        return "(both dice already used)"
    return ", ".join(remaining)


# --- Public functions (called by main.py) -----------------------------------


def get_legal_moves(observation: Mapping[str, Any]) -> dict[int, str]:
    """Return ``{action_id: action_string}`` for the current state."""
    legal_actions = observation.get("legalActions")
    legal_action_strings = observation.get("legalActionStrings")
    if legal_actions and legal_action_strings:
        return dict(zip(legal_actions, legal_action_strings))

    serialized = observation.get("serializedGameAndState", "")
    if not serialized:
        return {}
    _, state = pyspiel.deserialize_game_and_state(serialized)
    player_id = observation.get("playerId", state.current_player())
    actions = state.legal_actions()
    return {a: state.action_to_string(player_id, a) for a in actions}


def generate_prompt(
    observation: Mapping[str, Any],
    move_history: list[str],
    previous_response: str | None = None,
    previous_action: str | None = None,
) -> str:
    """Build the LLM prompt for the current backgammon state."""
    state = _parse_observation_payload(observation)
    player_id = int(observation.get("playerId", 0))
    my_label = _PLAYER_LABELS.get(player_id, "x")
    opp_label = "o" if my_label == "x" else "x"

    board = state.get("board") or [None] * 24
    bar = state.get("bar") or {"x": 0, "o": 0}
    off = state.get("off") or {"x": 0, "o": 0}
    dice = state.get("dice") or []
    move_number = state.get("move_number", 0)

    move_history_str = ", ".join(move_history) if move_history else "None"

    prompt = BACKGAMMON_PROMPT_TEMPLATE.format(
        dice_str=_format_dice(dice),
        move_number=move_number,
        my_bar=bar.get(my_label, 0),
        opp_bar=bar.get(opp_label, 0),
        my_off=off.get(my_label, 0),
        opp_off=off.get(opp_label, 0),
        my_points=_format_points_for_player(board, player_id, my_label),
        opp_points=_format_points_for_player(board, player_id, opp_label),
        move_history=move_history_str,
        player_id=player_id,
        my_piece=my_label,
    )

    prompt += render_rethink_suffix(
        RETHINK_ILLEGAL, RETHINK_UNPARSABLE,
        previous_response, previous_action,
    )

    return prompt


# --- Parsing ----------------------------------------------------------------


def _strip_action_id_prefix(action_string: str) -> str:
    """``"648 - Bar/21 Bar/20"`` -> ``"Bar/21 Bar/20"``.

    Legal-move strings from OpenSpiel always start with the action id and a
    ``" - "`` separator; the LLM is asked to write only the right-hand side.
    """
    sep = " - "
    idx = action_string.find(sep)
    return action_string[idx + len(sep) :] if idx >= 0 else action_string


def _normalize_notation(notation: str) -> str:
    """Lowercase + collapse whitespace so model and reference compare equal."""
    return re.sub(r"\s+", " ", notation.strip().lower())


_PASS_SUFFIX = " pass"


def _tolerance_variants(notation: str) -> set[str]:
    """Generate forgiving lookup keys for ``*`` and trailing ``Pass``.

    OpenSpiel encodes hits with ``*`` and unused-die markers with ``Pass``
    appended to the move (e.g. ``Bar/24 Pass``). Models routinely omit one
    or both because they feel like cosmetic annotations. Treat them as
    optional on both sides of the match so the model's intent gets through.
    """
    variants = {notation, notation.replace("*", "")}
    for v in list(variants):
        if v.endswith(_PASS_SUFFIX):
            variants.add(v[: -len(_PASS_SUFFIX)].strip())
    return {v for v in variants if v}


def _match_notation_to_legal(
    raw: str, legal_action_strings: Sequence[str],
) -> str | None:
    """Match a notation string against the legal list.

    Case- and whitespace-insensitive. Forgives missing hit ``*`` and missing
    trailing ``Pass`` markers in either direction (model omits them, or model
    adds them where the legal action didn't have them).
    """
    # Build the lookup with canonical forms first, then register tolerance
    # variants without clobbering canonical entries.
    legal_by_notation: dict[str, str] = {}
    for legal in legal_action_strings:
        notation = _normalize_notation(_strip_action_id_prefix(legal))
        legal_by_notation[notation] = legal
    for legal in legal_action_strings:
        notation = _normalize_notation(_strip_action_id_prefix(legal))
        for variant in _tolerance_variants(notation):
            legal_by_notation.setdefault(variant, legal)

    for candidate in _tolerance_variants(_normalize_notation(raw)):
        match = legal_by_notation.get(candidate)
        if match is not None:
            return match
    return None


def parse_response(
    response: str,
    legal_action_strings: Sequence[str],
) -> ParseResult:
    """Trust the model's JSON answer; let the rethink loop fix anything else."""
    return parse_json_action(response, legal_action_strings, matcher=_match_notation_to_legal)
