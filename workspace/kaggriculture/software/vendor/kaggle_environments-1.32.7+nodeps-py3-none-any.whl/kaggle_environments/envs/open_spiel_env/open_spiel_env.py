"""Kaggle environment wrapper for OpenSpiel games."""

import copy
import importlib
import json
import logging
import os
import pathlib
import random
import sys
import warnings
from typing import Any, Callable

import numpy as np
import pyspiel

from kaggle_environments import core, utils
from kaggle_environments.envs.open_spiel_env.games.ant_foraging_arena import ant_foraging_arena_game  # noqa: F401
from kaggle_environments.envs.open_spiel_env.games.bridge_arena import bridge_arena_game  # noqa: F401
from kaggle_environments.envs.open_spiel_env.games.coin_game_arena import coin_game_arena_game  # noqa: F401
from kaggle_environments.envs.open_spiel_env.games.snake import snake_game  # noqa: F401

# open_spiel.python.games.{ant_foraging, pokerkit_wrapper} register their
# games with pyspiel at import time and each pulls in ~1s of Python deps
# (ant_foraging: NumPy grid setup; pokerkit_wrapper: pokerkit). Only three
# entries in GAMES_LIST actually need them, so defer until a matching game
# is built. Everything else — CLI --help, non-poker/non-ant-foraging envs —
# skips the cost.
#
# Some proxy modules under games/*/*_proxy.py also depend on these
# registrations (e.g. python_ant_foraging_proxy calls pyspiel.load_game
# at module top). They are skipped during the auto-import scan and loaded
# lazily by _ensure_python_game_registered when their base game is built.
_PYTHON_GAME_REGISTRARS = {
    "python_ant_foraging": ("open_spiel.python.games.ant_foraging", "python_ant_foraging"),
    "python_pokerkit_wrapper": ("open_spiel.python.games.pokerkit_wrapper", None),
    "python_repeated_pokerkit": ("open_spiel.python.games.pokerkit_wrapper", None),
}


# Proxy modules deferred at auto-import time (see _DEFERRED_PROXY_FILENAMES
# below). Loaded on-demand by _ensure_python_game_registered when their base
# game is built. Each proxy calls pyspiel.load_game at module top, so it
# can't be auto-imported before its base game is registered.
_DEFERRED_PROXY_SHORT_NAMES = {"python_ant_foraging", "quoridor"}


def _ensure_python_game_registered(game_string: str) -> None:
    """Import the module that registers `game_string` with pyspiel, if any.

    Also imports the matching deferred proxy module (if one exists) so that
    `pyspiel.load_game(short_name + "_proxy")` succeeds downstream.
    """
    short_name = game_string.split("(", 1)[0]
    entry = _PYTHON_GAME_REGISTRARS.get(short_name)
    if entry is not None:
        base_module, proxy_short_name = entry
        importlib.import_module(base_module)
        if proxy_short_name is not None:
            importlib.import_module(
                f".games.{proxy_short_name}.{proxy_short_name}_proxy",
                package=__package__,
            )
    elif short_name in _DEFERRED_PROXY_SHORT_NAMES:
        importlib.import_module(
            f".games.{short_name}.{short_name}_proxy",
            package=__package__,
        )


ERROR = "ERROR"
DONE = "DONE"
INACTIVE = "INACTIVE"
ACTIVE = "ACTIVE"
TIMEOUT = "TIMEOUT"
INVALID = "INVALID"

_log = logging.getLogger(__name__)
# Silent by default. Enable at import time via OPEN_SPIEL_ENV_DEBUG, or per-run
# via the framework's debug flag (see interpreter, which bumps the level when
# env.debug is set).
_DEBUG = os.environ.get("OPEN_SPIEL_ENV_DEBUG", "").lower() in ("1", "true", "yes")
_log.setLevel(logging.DEBUG if _DEBUG else logging.WARNING)
_handler = logging.StreamHandler(sys.stdout)
_formatter = logging.Formatter("[%(name)s] %(levelname)s: %(message)s")
_handler.setFormatter(_formatter)
_log.addHandler(_handler)

# --- Import proxy games ---
# Proxies deferred at scan time — either because their base game is a
# deferred python module (see _PYTHON_GAME_REGISTRARS) or because loading
# them at all triggers noisy C++ warnings from OpenSpiel (e.g. quoridor).
# Loaded on-demand from _ensure_python_game_registered when the
# corresponding env is built.
_DEFERRED_PROXY_FILENAMES = {f"{n}_proxy.py" for n in _DEFERRED_PROXY_SHORT_NAMES}

_log.debug("Auto-importing OpenSpiel game proxies...")
GAMES_DIR = pathlib.Path(__file__).parent / "games"
for proxy_file in GAMES_DIR.glob("**/*_proxy.py"):
    if proxy_file.name in _DEFERRED_PROXY_FILENAMES:
        continue
    try:
        relative_path = proxy_file.relative_to(GAMES_DIR.parent)
        module_path = str(relative_path.with_suffix("")).replace(os.path.sep, ".")
        importlib.import_module("." + module_path, package=__package__)
        _log.debug(f"  - Imported: {module_path}")
    except Exception as e:  # pylint: disable=broad-exception-caught
        _log.debug(f"  - FAILED to import proxy from {proxy_file.name}: {e}")

# --- Import custom games ---
_log.debug("Auto-importing custom OpenSpiel games...")
GAMES_DIR = pathlib.Path(__file__).parent / "games"
for game_file in GAMES_DIR.glob("**/*_game.py"):
    try:
        relative_path = proxy_file.relative_to(GAMES_DIR.parent)
        module_path = str(relative_path.with_suffix("")).replace(os.path.sep, ".")
        importlib.import_module("." + module_path, package=__package__)
        _log.debug(f"  - Imported: {module_path}")
    except Exception as e:  # pylint: disable=broad-exception-caught
        _log.debug(f"  - FAILED to import game from {game_file.name}: {e}")


# --- Constants ---
# TODO(jhtschultz): Make this configurable per-game. For instance, in poker, a
# invalid action would likely result in a fold, forfeiting the player's
# contribution to the pot.
DEFAULT_INVALID_ACTION_REWARD = -1

# Can be used by agents to signal an internal error to the environement.
AGENT_ERROR_ACTION = -2

DEFAULT_ACT_TIMEOUT = 60 * 60  # sixty minutes
DEFAULT_RUN_TIMEOUT = 60 * 60 * 48  # thirty hours
# Buffer in addition to max game length to account for timeouts, retrys, etc.
DEFAULT_STEP_BUFFER = 100
# TODO(jhtschultz): Add individual game descriptions.
DEFAULT_DESCRIPTION = """
Kaggle environment wrapper for OpenSpiel games.
For game implementation details see:
https://github.com/google-deepmind/open_spiel/tree/master/open_spiel/games
""".strip()

CONFIGURATION_SPEC_TEMPLATE = {
    "episodeSteps": -1,
    "actTimeout": DEFAULT_ACT_TIMEOUT,
    "runTimeout": DEFAULT_RUN_TIMEOUT,
    "openSpielGameString": {
        "description": "The full game string including parameters.",
        "type": "string",
        "default": "PLACEHOLDER_GAME_STRING",
    },
    "openSpielGameName": {
        "description": "The short_name of the OpenSpiel game to load.",
        "type": "string",
        "default": "PLACEHOLDER_GAME_SHORT_NAME",
    },
    "openSpielGameParameters": {"description": "Game parameters for Open Spiel game.", "type": "object", "default": {}},
    "observationType": {
        "description": "Type of observation string: 'observation' or 'information_state'.",
        "type": "string",
        "default": "observation",
    },
    "useOpenings": {
        "description": "Whether to start from a position in an opening book.",
        "type": "boolean",
        "default": False,
    },
    "useImage": {
        "description": (
            "If true, indicates the observation is intended to be rendered as"
            " an image. Note that currently the agent harness is responsible"
            " for the actual rendering; no image is passed in the observation."
        ),
        "type": "boolean",
        "default": False,
    },
    "includeLegalActions": {
        "description": (
            "If true, include legalActions and legalActionStrings in observations. "
            "Defaults to false since these can be derived from serializedGameAndState."
        ),
        "type": "boolean",
        "default": False,
    },
    "seed": {
        "description": (
            "Integer used to select a starting position (when useOpenings is true)"
            " and to seed chance-node sampling so episodes are reproducible."
        ),
        "type": "number",
    },
    "initialActions": {
        "description": "Actions applied to initial state before play begins to set up starting position.",
        "type": "array",
        "items": {"type": "integer"},
    },
    "loadPresetHands": {
        "description": "Repeated poker only. Load preset hand chance actions from preset_hands.jsonl.",
        "type": "boolean",
        "default": False,
    },
    "presetHands": {
        "description": (
            "Repeated poker only. List of per-hand chance action sequences to use instead of random chance."
        ),
        "type": "array",
        "items": {
            "type": "array",
            "items": {"type": "integer"},
        },
    },
    "metadata": {"description": "Arbitrary metadata.", "type": "object", "default": {}},
    "strictMode": {
        "description": (
            "If true, agents must return only {'submission': int} (no extra fields"
            " like 'thoughts'), and per-agent TIMEOUT/ERROR/INVALID counts as a"
            " loss for the offending agent only — other agents are marked DONE"
            " with a winning reward. The offender keeps its natural ERROR or"
            " TIMEOUT status (matching how every other Kaggle competition"
            " reports per-player failures). If false (default), any agent error"
            " halts and voids the entire episode, matching the lenient"
            " research-mode behavior."
        ),
        "type": "boolean",
        "default": False,
    },
    "savePrompt": {
        "description": ("If disabled, skip logging LLM prompts in the replay file."),
        "type": "boolean",
        "default": True,
    },
    "saveResponse": {
        "description": (
            "If disabled, skip logging raw LLM responses in the replay file."
            " Extracted thoughts (which typically contain everything but the"
            " final move tag) are still logged on the action, so the legal"
            " response is effectively preserved."
        ),
        "type": "boolean",
        "default": True,
    },
    "freeForm": {
        "description": (
            "If true, the core harness allows free-form actions"
            " (get_legal_moves may return None) on turns where the action"
            " space is not enumerable. Defaults to false for OpenSpiel games."
        ),
        "type": "boolean",
        "default": False,
    },
    "includeGenerateReturns": {
        "description": (
            "If true, include a legacy generate_returns field on each action"
            " with per-LLM-call metadata (model, token counts, finish reason,"
            " duration). Useful for cost tracking and visualization pipelines."
        ),
        "type": "boolean",
        "default": False,
    },
    "illegalMoveForfeit": {
        "description": (
            "If true (default), when an LLM harness exhausts its retries"
            " without producing a legal move, it submits an invalid action"
            " so this player forfeits via the env's INVALID path (matching"
            " the game_arena convention). If false, the harness re-raises"
            " the parse failure, which voids the whole episode. Only affects"
            " exhaustion from illegal/unparsable moves; uncaught exceptions"
            " still propagate either way."
        ),
        "type": "boolean",
        "default": True,
    },
}

OBSERVATION_SPEC_TEMPLATE = {
    "properties": {
        "openSpielGameString": {"description": "Full game string including parameters.", "type": "string"},
        "openSpielGameName": {"description": "Short name of the OpenSpiel game.", "type": "string"},
        "observationString": {"description": "String representation of state.", "type": "string"},
        "legalActions": {
            "description": "List of OpenSpiel legal action integers. Only included if includeLegalActions is true.",
            "type": "array",
            "items": {"type": "integer"},
        },
        "legalActionStrings": {
            "description": "List of OpenSpiel legal action strings. Only included if includeLegalActions is true.",
            "type": "array",
            "items": {"type": "string"},
        },
        "currentPlayer": {"description": "ID of player whose turn it is.", "type": "integer"},
        "playerId": {"description": "ID of the agent receiving this observation.", "type": "integer"},
        "isTerminal": {"description": "Boolean indicating game end.", "type": "boolean"},
        "serializedGameAndState": {
            "description": "Enables reconstructing the Game and State objects.",
            "type": "string",
        },
        "remainingOverageTime": 60,
        "step": 0,
    },
    "default": {},
}

ACTION_SPEC_TEMPLATE = {
    "description": "Action object MUST contain a field `submission`, and MAY contain arbitrary additional information.",
    "type": "object",
    "default": {"submission": -1},
}

ENV_SPEC_TEMPLATE = {
    "name": "PLACEHOLDER_NAME",
    "title": "PLACEHOLDER_TITLE",
    "description": DEFAULT_DESCRIPTION,
    "version": "0.1.0",
    "agents": ["PLACEHOLDER_NUM_AGENTS"],
    "configuration": CONFIGURATION_SPEC_TEMPLATE,
    "observation": OBSERVATION_SPEC_TEMPLATE,
    "action": ACTION_SPEC_TEMPLATE,
    "reward": {"type": ["number"], "default": 0.0},
}


def _get_initial_actions(
    configuration: dict[str, Any],
) -> tuple[list[int], dict[str, Any]]:
    initial_actions = configuration.get("initialActions", [])
    if initial_actions:
        if configuration.get("useOpenings"):
            raise ValueError("Cannot set both useOpenings and initialActions.")
        else:
            return initial_actions, {}
    if not configuration.get("useOpenings"):
        return [], {}
    seed = configuration.get("seed", None)
    if seed is None:
        raise ValueError("Must provide seed if useOpenings is True.")
    openings_path = pathlib.Path(
        GAMES_DIR,
        configuration.get("openSpielGameName"),
        "openings.jsonl",
    )
    if not openings_path.is_file():
        raise ValueError(f"No opening file found at {openings_path}")
    with open(openings_path, "r", encoding="utf-8") as f:
        openings = f.readlines()
        opening = json.loads(openings[seed % len(openings)])
        initial_actions = opening.pop("initialActions")
        return initial_actions, opening


# TODO(jhtschultz): General method for handling state setup functions.
def _get_preset_hands(configuration: dict[str, Any]) -> list[list[int]]:
    preset_hands = configuration.get("presetHands")
    if not preset_hands:
        return []
    if configuration.get("useOpenings"):
        raise ValueError("Cannot set both useOpenings and presetHands.")
    if (
        configuration.get("loadPresetHands")
        and "presetHands" in configuration
        and not configuration.get("_presetHandsLoaded")
    ):
        raise ValueError("Cannot set both loadPresetHands and presetHands.")
    if configuration.get("initialActions"):
        raise ValueError("Cannot set both initialActions and presetHands.")
    game_name = configuration.get("openSpielGameName")
    if game_name != "repeated_poker":
        raise ValueError(f"presetHands only supported for repeated_poker, not {game_name}.")
    validated: list[list[int]] = []
    for hand_index, hand in enumerate(preset_hands):
        if not isinstance(hand, list):
            raise ValueError(f"presetHands[{hand_index}] must be a list of integers.")
        if any(not isinstance(action, int) for action in hand):
            raise ValueError(f"presetHands[{hand_index}] must contain only integers.")
        validated.append(list(hand))
    return validated


def _get_image_config(configuration: dict[str, Any]) -> dict[str, Any]:
    use_image = configuration.get("useImage", None)
    if use_image is None:
        raise ValueError("_get_image_config called but useImage missing from env config.")
    if not use_image:
        raise ValueError("_get_image_config called but useImage is False.")
    seed = configuration.get("seed", None)
    if seed is None:
        raise ValueError("Must provide seed if useImage is True.")
    image_config_path = pathlib.Path(
        GAMES_DIR,
        configuration.get("openSpielGameName"),
        "image_config.jsonl",
    )
    if not image_config_path.is_file():
        raise ValueError(f"No image config file found at {image_config_path}")
    with open(image_config_path, "r", encoding="utf-8") as f:
        image_configs = f.readlines()
        image_config = json.loads(image_configs[seed % len(image_configs)])
        return image_config


def _load_preset_hands_from_file(configuration: dict[str, Any]) -> list[list[int]]:
    if configuration.get("openSpielGameName") != "repeated_poker":
        raise ValueError("loadPresetHands only supported for repeated_poker.")
    seed = configuration.get("seed", None)
    if seed is None:
        raise ValueError("Must provide seed if loadPresetHands is True.")
    preset_path = pathlib.Path(
        GAMES_DIR,
        configuration.get("openSpielGameName"),
        "preset_hands.jsonl",
    )
    if not preset_path.is_file():
        raise ValueError(f"No preset hands file found at {preset_path}")
    with open(preset_path, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
    if not lines:
        raise ValueError(f"Preset hands file at {preset_path} is empty.")
    entry = json.loads(lines[seed % len(lines)])
    preset_hands = entry.get("presetHands")
    if not preset_hands:
        raise ValueError("Preset hands entry missing presetHands data.")
    return preset_hands


def _get_preset_chance_action(
    env: core.Environment,
    os_state: pyspiel.State,
    outcomes: tuple[int, ...],
) -> int | None:
    preset_state = env.info.get("presetHandsState")
    if not preset_state:
        return None
    hand_idx = len(os_state.acpc_hand_histories())
    current_hand_index: int = preset_state["current_hand_index"]
    hands: list[tuple[int, ...]] = preset_state["hands"]
    next_index: list[int] = preset_state["next_index"]
    if hand_idx > current_hand_index:
        preset_state["current_hand_index"] = hand_idx
    if hand_idx >= len(hands):
        raise ValueError(f"Ran out of presetHands entries while attempting to start hand {hand_idx}.")
    hand_actions = hands[hand_idx]
    action_pos = next_index[hand_idx]
    if action_pos >= len(hand_actions):
        raise ValueError(f"presetHands[{hand_idx}] does not contain enough chance actions for the hand.")
    next_action = hand_actions[action_pos]
    if next_action not in outcomes:
        raise ValueError(
            f"presetHands[{hand_idx}] specified chance action {next_action} which is not available in the current chance outcomes."
        )
    next_index[hand_idx] = action_pos + 1
    return next_action


# --- Core step logic ---


def interpreter(
    state: list[utils.Struct],
    env: core.Environment,
    logs: list[dict[str, Any]],
) -> list[utils.Struct]:
    """Updates environment using player responses and returns new observations."""
    kaggle_state = state  # Not to be confused with OpenSpiel state.
    del state

    # Surface this module's logs when the run is in debug mode.
    if getattr(env, "debug", False):
        _log.setLevel(logging.DEBUG)

    # TODO(jhtschultz): Test reset behavior. Currently containers are restarted
    # after each episode.
    if env.done:
        return kaggle_state

    # --- Get and maybe initialize game and state on the env object ---
    if not hasattr(env, "os_game"):
        game_string = env.configuration.get("openSpielGameString")
        game_name = env.configuration.get("openSpielGameName")

        # Load base game from string to get its parameters
        base_game = pyspiel.load_game(game_string)
        base_params = base_game.get_parameters()

        # Find user-provided params by comparing config to spec defaults
        config_params = env.configuration.get("openSpielGameParameters", {})
        default_params = env.specification.configuration.openSpielGameParameters.get("default", {})
        user_params = {k: v for k, v in config_params.items() if config_params.get(k) != default_params.get(k)}

        # Deprecated: use openSpielGameParameters.max_num_hands instead
        if env.configuration.get("setNumHands", None):
            warnings.warn(
                "setNumHands is deprecated. Use openSpielGameParameters={'max_num_hands': N} instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            if "repeated_poker" not in game_name:
                raise ValueError(f"setNumHands only supported for repeated_poker, not {game_name}")
            user_params["max_num_hands"] = env.configuration.get("setNumHands")

        # Merge: base params from string, then user params override
        merged_params = {**base_params, **user_params}

        # Load the game with merged parameters
        env.os_game = pyspiel.load_game(game_name, merged_params)

        # Check if a proxy exists for this game and use it instead
        proxy_path = GAMES_DIR / game_name / f"{game_name}_proxy.py"
        if proxy_path.is_file():
            env.os_game = pyspiel.load_game(game_name + "_proxy", env.os_game.get_parameters())

        # Store the resolved game string (after merging parameters)
        env.info["openSpielGameStringResolved"] = str(env.os_game)
    if not hasattr(env, "os_state"):
        env.os_state = env.os_game.new_initial_state()
    if not hasattr(env, "chance_rng"):
        seed = env.configuration.get("seed", None)
        env.chance_rng = np.random.default_rng(seed) if seed is not None else np.random
    if "stateHistory" not in env.info:
        env.info["stateHistory"] = [str(env.os_state)]
    if "actionHistory" not in env.info:
        env.info["actionHistory"] = []
        env.info["moveDurations"] = []
        initial_actions, metadata = _get_initial_actions(env.configuration)
        if env.configuration.get("loadPresetHands", False):
            if env.configuration.get("presetHands"):
                raise ValueError("Cannot provide presetHands when loadPresetHands is True.")
            preset_hands_from_file = _load_preset_hands_from_file(env.configuration)
            env.configuration["presetHands"] = preset_hands_from_file
            env.configuration["_presetHandsLoaded"] = True
        preset_hands = _get_preset_hands(env.configuration)
        env.configuration.pop("_presetHandsLoaded", None)
        if initial_actions:
            env.info["initialActions"] = initial_actions
            env.info["openingMetadata"] = metadata
            for action in initial_actions:
                env.os_state.apply_action(action)
                env.info["actionHistory"].append(str(action))
                env.info["stateHistory"].append(str(env.os_state))
        if preset_hands:
            env.info["presetHands"] = copy.deepcopy(preset_hands)
            env.info["presetHandsState"] = {
                "hands": [tuple(hand) for hand in preset_hands],
                "next_index": [0 for _ in preset_hands],
                "current_hand_index": 0,
            }
    if env.configuration.get("useImage", False):
        env.configuration["imageConfig"] = _get_image_config(env.configuration)

    os_game = env.os_game
    os_state = env.os_state
    num_players = os_game.num_players()

    # TODO(jhtschultz): Test reset behavior.
    is_initial_step = len(env.steps) == 1
    if is_initial_step and os_state.is_terminal():
        env.os_state = os_game.new_initial_state()
        os_state = env.os_state

    # --- Apply agent action ---
    acting_agent = os_state.current_player()
    # Per-player tracking for sequential moves.
    action_submitted: int | None = None
    action_submitted_to_string: str | None = None
    action_applied: int | None = None
    move_duration: float | None = None
    # Per-player tracking for simultaneous moves.
    simul_actions_submitted: list[int | None] = [None] * num_players
    simul_actions_submitted_to_string: list[str | None] = [None] * num_players
    simul_actions_applied: list[int | None] = [None] * num_players
    simul_move_durations: list[float | None] = [None] * num_players
    simul_all_valid = False

    strict_mode = bool(env.configuration.get("strictMode", False))

    if is_initial_step:
        pass
    elif 0 <= acting_agent < num_players:
        if kaggle_state[acting_agent]["status"] != "ACTIVE":
            pass
        elif strict_mode and (
            not isinstance(kaggle_state[acting_agent]["action"], dict)
            or set(kaggle_state[acting_agent]["action"].keys()) != {"submission"}
        ):
            kaggle_state[acting_agent]["status"] = "INVALID"
        else:
            action_submitted = kaggle_state[acting_agent]["action"]["submission"]
            if action_submitted in os_state.legal_actions():
                action_submitted_to_string = os_state.action_to_string(action_submitted)
                os_state.apply_action(action_submitted)
                action_applied = action_submitted
                env.info["actionHistory"].append(str(action_applied))
                env.info["stateHistory"].append(str(os_state))
                # Visualizers (e.g. goTransformer) read actionString off the
                # action dict to render moves. The LLM harness populates this
                # itself; for code-submission agents we populate it here.
                kaggle_state[acting_agent]["action"]["actionString"] = action_submitted_to_string
            elif action_submitted == AGENT_ERROR_ACTION:
                kaggle_state[acting_agent]["status"] = "ERROR"
            else:
                kaggle_state[acting_agent]["status"] = "INVALID"
            try:
                if "duration" in logs[acting_agent]:
                    move_duration = round(logs[acting_agent]["duration"], 3)
                    env.info["moveDurations"].append(move_duration)
                else:
                    env.info["moveDurations"].append(None)
            except Exception:
                pass  # No logs when stepping the env manually.

    elif acting_agent == pyspiel.PlayerId.SIMULTANEOUS:
        # Collect and validate actions from all players. Players with no
        # legal actions (INACTIVE) get kInvalidAction per OpenSpiel convention.
        actions_for_apply: list[int] = [pyspiel.INVALID_ACTION] * num_players
        simul_all_valid = True
        for pid in range(num_players):
            legal = os_state.legal_actions(pid)
            if not legal:
                # Player has no legal actions at this node — skip.
                continue
            if kaggle_state[pid]["status"] != "ACTIVE":
                simul_all_valid = False
                break
            if strict_mode and (
                not isinstance(kaggle_state[pid]["action"], dict)
                or set(kaggle_state[pid]["action"].keys()) != {"submission"}
            ):
                kaggle_state[pid]["status"] = "INVALID"
                simul_all_valid = False
                break
            sub = kaggle_state[pid]["action"]["submission"]
            simul_actions_submitted[pid] = sub
            if sub == AGENT_ERROR_ACTION:
                kaggle_state[pid]["status"] = "ERROR"
                simul_all_valid = False
                break
            elif sub not in legal:
                kaggle_state[pid]["status"] = "INVALID"
                simul_all_valid = False
                break
            # Capture action string BEFORE applying (state will advance).
            simul_actions_submitted_to_string[pid] = os_state.action_to_string(pid, sub)
            actions_for_apply[pid] = sub

        if simul_all_valid:
            os_state.apply_actions(actions_for_apply)
            for pid in range(num_players):
                simul_actions_applied[pid] = simul_actions_submitted[pid]
                # See note above: surface actionString for visualizers.
                if simul_actions_submitted_to_string[pid] is not None:
                    kaggle_state[pid]["action"]["actionString"] = simul_actions_submitted_to_string[pid]
            env.info["actionHistory"].append(str(actions_for_apply))
            env.info["stateHistory"].append(str(os_state))

        # Record move durations for players who submitted actions.
        for pid in range(num_players):
            if simul_actions_submitted[pid] is None:
                continue
            try:
                if "duration" in logs[pid]:
                    simul_move_durations[pid] = round(logs[pid]["duration"], 3)
                    env.info["moveDurations"].append(simul_move_durations[pid])
                else:
                    env.info["moveDurations"].append(None)
            except Exception:
                pass  # No logs when stepping the env manually.
    elif acting_agent == pyspiel.PlayerId.TERMINAL:
        pass
    elif acting_agent == pyspiel.PlayerId.CHANCE:
        raise ValueError("Interpreter should not be called at chance nodes.")
    else:
        raise ValueError(f"Unknown OpenSpiel player ID: {acting_agent}")

    # --- Step chance nodes ---
    while os_state.is_chance_node():
        outcomes, probs = zip(*os_state.chance_outcomes())
        preset_action = _get_preset_chance_action(env, os_state, outcomes)
        if preset_action is not None:
            chance_action = preset_action
        else:
            chance_action = env.chance_rng.choice(outcomes, p=probs)
        os_state.apply_action(chance_action)
        env.info["actionHistory"].append(str(chance_action))
        env.info["stateHistory"].append(str(os_state))

    # --- Update agent states ---
    agent_error = any(kaggle_state[player_id]["status"] in ["TIMEOUT", "ERROR"] for player_id in range(num_players))
    if agent_error:
        _log.info("AGENT ERROR DETECTED")

    invalid_action = any(kaggle_state[player_id]["status"] == "INVALID" for player_id in range(num_players))
    if invalid_action:
        _log.info("INVALID ACTION DETECTED")

    status: str | None = None
    for player_id, agent_state in enumerate(kaggle_state):
        reward = None
        if agent_error and strict_mode:
            # Per-player scoping like every other competition: offender keeps
            # its natural ERROR / TIMEOUT status (core.py will null its reward),
            # others get DONE + winning reward. The kaggleazure open_spiel
            # carveout is gated on UseModelProxy / EnableInternet so non-DONE
            # statuses no longer void the episode in strict-mode competitions.
            if agent_state["status"] in ("TIMEOUT", "ERROR"):
                status = agent_state["status"]
            else:
                reward = -DEFAULT_INVALID_ACTION_REWARD
                status = "DONE"
        elif agent_error:
            # Set all agent statuses to ERROR in order not to score episode. Preserve
            # TIMEOUT which has the same effect.
            if agent_state["status"] == "TIMEOUT":
                status = "TIMEOUT"
            else:
                status = "ERROR"
        elif invalid_action:
            if agent_state["status"] == "INVALID":
                reward = DEFAULT_INVALID_ACTION_REWARD
            else:
                reward = -DEFAULT_INVALID_ACTION_REWARD
            status = "DONE"
        elif os_state.is_terminal():
            status = "DONE"
            reward = os_state.returns()[player_id]
        elif os_state.is_simultaneous_node():
            if os_state.legal_actions(player_id):
                status = "ACTIVE"
            else:
                status = "INACTIVE"
        elif os_state.current_player() == player_id:
            status = "ACTIVE"
            if not os_state.legal_actions(player_id):
                raise ValueError(f"Active agent {player_id} has no legal actions in state {os_state}.")
        else:
            status = "INACTIVE"
        assert status is not None

        info_dict = {}
        if acting_agent == pyspiel.PlayerId.SIMULTANEOUS:
            info_dict["actionSubmitted"] = simul_actions_submitted[player_id]
            info_dict["actionSubmittedToString"] = simul_actions_submitted_to_string[player_id]
            info_dict["actionApplied"] = simul_actions_applied[player_id]
            info_dict["timeTaken"] = simul_move_durations[player_id]
            info_dict["agentSelfReportedStatus"] = (
                kaggle_state[player_id]["action"].get("status") if kaggle_state[player_id]["action"] else "unknown"
            )
        elif acting_agent == player_id:
            info_dict["actionSubmitted"] = action_submitted
            info_dict["actionSubmittedToString"] = action_submitted_to_string
            info_dict["actionApplied"] = action_applied
            info_dict["timeTaken"] = move_duration
            info_dict["agentSelfReportedStatus"] = (
                kaggle_state[acting_agent]["action"].get("status")
                if kaggle_state[acting_agent]["action"]
                else "unknown"
            )

        # Get observation string based on game's observation type
        if env.configuration.get("observationType") == "information_state":
            obs_string = os_state.information_state_string(player_id)
        else:
            obs_string = os_state.observation_string(player_id)

        obs_update_dict = {
            "observationString": obs_string,
            "currentPlayer": os_state.current_player(),
            "playerId": player_id,
            "isTerminal": os_state.is_terminal(),
            "serializedGameAndState": pyspiel.serialize_game_and_state(os_game, os_state),
        }
        if env.configuration.get("includeLegalActions", False):
            obs_update_dict["legalActions"] = os_state.legal_actions(player_id)
            obs_update_dict["legalActionStrings"] = [
                os_state.action_to_string(action) for action in os_state.legal_actions(player_id)
            ]
        if "imageConfig" in env.configuration:
            obs_update_dict["imageConfig"] = env.configuration["imageConfig"]

        # Apply updates
        for k, v in obs_update_dict.items():
            setattr(agent_state.observation, k, v)
        agent_state["reward"] = reward
        agent_state["info"] = info_dict
        agent_state["status"] = status

    return kaggle_state


# --- Rendering ---


def renderer(state: list[utils.Struct], env: core.Environment) -> str:
    """Kaggle environment text renderer."""
    if hasattr(env, "os_state"):
        return str(env.os_state)
    else:
        return "Game state uninitialized."


# TODO(jhtschultz): Use custom player.html that replays from env.info instead
# of player steps. The full game state is stored in env.info, player steps only
# contain player observations.
def _default_html_renderer() -> str:
    """Provides the JavaScript string for the default HTML renderer."""
    return """
function renderer(context) {
    const { parent, environment, step } = context;
    parent.innerHTML = '';  // Clear previous rendering

    const currentStepData = environment.steps[step];
    if (!currentStepData) {
        parent.textContent = "Waiting for step data...";
        return;
    }
    const agentObsIndex = 0
    let obsString = "Observation not available for this step.";
    let title = `Step: ${step}`;

    if (environment.configuration && environment.configuration.openSpielGameName) {
        title = `${environment.configuration.openSpielGameName} - Step: ${step}`;
    }

    // Try to get obs_string from game_master of current step
    if (currentStepData[agentObsIndex] && 
        currentStepData[agentObsIndex].observation && 
        typeof currentStepData[agentObsIndex].observation.observationString === 'string') {
        obsString = currentStepData[agentObsIndex].observation.observationString;
    } 
    // Fallback to initial step if current is unavailable (e.g. very first render call)
    else if (step === 0 && environment.steps[0] && environment.steps[0][agentObsIndex] && 
             environment.steps[0][agentObsIndex].observation &&
             typeof environment.steps[0][agentObsIndex].observation.observationString === 'string') {
        obsString = environment.steps[0][agentObsIndex].observation.observationString;
    }

    const pre = document.createElement("pre");
    pre.style.fontFamily = "monospace";
    pre.style.margin = "10px";
    pre.style.border = "1px solid #ccc";
    pre.style.padding = "10px";
    pre.style.backgroundColor = "#f9f9f9";
    pre.style.whiteSpace = "pre-wrap";
    pre.style.wordBreak = "break-all";

    pre.textContent = `${title}\\n\\n${obsString}`;
    parent.appendChild(pre);
}
"""


def _get_html_renderer_content(
    open_spiel_short_name: str, base_path_for_custom_renderers: pathlib.Path, default_renderer_func: Callable[[], str]
) -> str:
    """Tries to load a custom HTML/JS renderer for the game, falls back to default."""
    # Prefer the built Vite visualizer at games/<name>/visualizer/default/dist/index.html
    dist_index_path = pathlib.Path(
        base_path_for_custom_renderers,
        open_spiel_short_name,
        "visualizer",
        "default",
        "dist",
        "index.html",
    )
    if dist_index_path.is_file():
        try:
            with open(dist_index_path, "r", encoding="utf-8") as f:
                content = f.read()
            _log.debug(f"Using built HTML visualizer for {open_spiel_short_name} from {dist_index_path}")
            return content
        except Exception as e:  # pylint: disable=broad-exception-caught
            _log.debug(e)
    # Fallback to legacy single-file JS renderer at games/<name>/<name>.js
    custom_renderer_js_path = pathlib.Path(
        base_path_for_custom_renderers,
        open_spiel_short_name,
        f"{open_spiel_short_name}.js",
    )
    if custom_renderer_js_path.is_file():
        try:
            with open(custom_renderer_js_path, "r", encoding="utf-8") as f:
                content = f.read()
            _log.debug(f"Using custom HTML renderer for {open_spiel_short_name} from {custom_renderer_js_path}")
            return content
        except Exception as e:  # pylint: disable=broad-exception-caught
            _log.debug(e)
    return default_renderer_func()


# --- Agents ---


_RANDOM_THOUGHT_WORDS = (
    "alpha",
    "beta",
    "gamma",
    "delta",
    "epsilon",
    "zeta",
    "eta",
    "theta",
    "iota",
    "kappa",
    "lambda",
    "mu",
    "nu",
    "xi",
    "omicron",
    "pi",
    "rho",
    "sigma",
    "tau",
    "upsilon",
    "phi",
    "chi",
    "psi",
    "omega",
    "ponder",
    "muse",
    "wonder",
    "consider",
    "reflect",
    "imagine",
    "explore",
    "drift",
    "spark",
    "ripple",
    "echo",
    "shadow",
    "horizon",
    "lantern",
    "cascade",
    "ember",
)


def random_agent(
    observation: dict[str, Any],
    configuration: dict[str, Any],
) -> int:
    """A built-in random agent specifically for OpenSpiel environments."""
    legal_actions = observation.get("legalActions")
    if not legal_actions:
        return None
    action = int(random.choice(legal_actions))
    # strictMode requires the action dict to contain ONLY 'submission'.
    if configuration.get("strictMode", False):
        return {"submission": action}
    thoughts = " ".join(random.choices(_RANDOM_THOUGHT_WORDS, k=8))
    return {"submission": action, "thoughts": thoughts}


AGENT_REGISTRY = {
    "random": random_agent,
}


# --- Build and register environments ---


def _build_env(game_string: str) -> dict[str, Any]:
    _ensure_python_game_registered(game_string)
    game = pyspiel.load_game(game_string)
    short_name = game.get_type().short_name

    proxy_path = GAMES_DIR / short_name / f"{short_name}_proxy.py"
    if proxy_path.is_file():
        game = pyspiel.load_game(short_name + "_proxy", game.get_parameters())

    game_type = game.get_type()
    if game_type.provides_observation_string:
        observation_type = "observation"
    elif game_type.provides_information_state_string:
        observation_type = "information_state"
    else:
        raise ValueError(f"No observation or information state string for game: {game_string}")

    env_spec = copy.deepcopy(ENV_SPEC_TEMPLATE)
    env_spec["name"] = f"open_spiel_{short_name}"
    env_spec["title"] = f"Open Spiel: {short_name}"
    env_spec["agents"] = [game.num_players()]

    env_config = env_spec["configuration"]
    env_config["episodeSteps"] = game.max_history_length() + DEFAULT_STEP_BUFFER
    env_config["openSpielGameString"]["default"] = str(game)
    env_config["openSpielGameName"]["default"] = short_name
    env_config["openSpielGameParameters"]["default"] = game.get_parameters()
    env_config["observationType"]["default"] = observation_type

    env_obs = env_spec["observation"]
    env_obs["properties"]["openSpielGameString"]["default"] = str(game)
    env_obs["properties"]["openSpielGameName"]["default"] = short_name

    # Building html_renderer_callable is a bit convoluted but other approaches
    # fail for a variety of reasons. Returning a simple lambda function
    # doesn't work because of late-binding -- the last env registered will
    # overwrite all previous renderers.
    js_string_content = _get_html_renderer_content(
        open_spiel_short_name=short_name,
        base_path_for_custom_renderers=GAMES_DIR,
        default_renderer_func=_default_html_renderer,
    )

    def create_html_renderer_closure(captured_content):
        def html_renderer_callable_no_args():
            return captured_content

        return html_renderer_callable_no_args

    html_renderer_callable = create_html_renderer_closure(js_string_content)

    return {
        "specification": env_spec,
        "interpreter": interpreter,
        "renderer": renderer,
        "html_renderer": html_renderer_callable,
        "agents": AGENT_REGISTRY,
    }


# Game short_names whose _build_env call is deferred until first use.
# quoridor prints a duplicate "known issues" warning from OpenSpiel's C++
# every time pyspiel.load_game("quoridor") runs; deferring keeps CLI
# commands like --help / list silent.
_LAZY_GAMES = {"quoridor"}


def _make_lazy_env_loader(game_string: str):
    """Return a zero-arg loader that materializes an env dict on demand."""

    def _load():
        return _build_env(game_string)

    return _load


def _register_game_envs(games_list: list[str]) -> dict[str, Any]:
    skipped_games = []
    registered_envs = {}
    lazy_count = 0
    for game_string in games_list:
        short_name = game_string.split("(", 1)[0]
        if short_name in _LAZY_GAMES:
            LAZY_ENV_LOADERS[f"open_spiel_{short_name}"] = _make_lazy_env_loader(game_string)
            lazy_count += 1
            continue
        try:
            env_config = _build_env(game_string)
            if env_config is None:
                continue
            env_name = env_config["specification"]["name"]
            if env_name in registered_envs:
                raise ValueError(f"Attempting to overwrite existing env: {env_name}")
            registered_envs[env_name] = env_config
        except Exception as e:  # pylint: disable=broad-exception-caught
            _log.debug(e)
            skipped_games.append(game_string)

    _log.info(f"Successfully loaded OpenSpiel environments: {len(registered_envs) + lazy_count}.")
    for env_name in registered_envs:
        _log.debug(f"   {env_name}")
    _log.info(f"OpenSpiel games skipped: {len(skipped_games)}.")
    for game_string in skipped_games:
        _log.debug(f"   {game_string}")

    return registered_envs


DEFAULT_UNIVERSAL_POKER_GAME_STRING = (
    "universal_poker("
    "betting=nolimit,"
    "bettingAbstraction=fullgame,"
    "blind=2 1,"
    "firstPlayer=2 1 1 1,"
    "numBoardCards=0 3 1 1,"
    "numHoleCards=2,"
    "numPlayers=2,"
    "numRanks=13,"
    "numRounds=4,"
    "numSuits=4,"
    "stack=200 200,"
    "calcOddsNumSims=1000000)"
)

DEFAULT_REPEATED_POKER_GAME_STRING = (
    "repeated_poker("
    "max_num_hands=100,"
    "reset_stacks=True,"
    "rotate_dealer=True,"
    f"universal_poker_game_string={DEFAULT_UNIVERSAL_POKER_GAME_STRING})"
)

DEFAULT_REPEATED_POKERKIT_GAME_STRING = (
    "python_repeated_pokerkit(bet_size_schedule=,blind_schedule=,"
    "bring_in_schedule=,first_button_player=-1,max_num_hands=100,"
    "pokerkit_game_params=python_pokerkit_wrapper(blinds=1 2,num_players=2,"
    "stack_sizes=200 200,variant=NoLimitTexasHoldem),reset_stacks=True,"
    "rotate_dealer=True)"
)

GAMES_LIST = [
    "amazons",
    "ant_foraging_arena",
    "backgammon",
    "bargaining",
    "python_ant_foraging",
    "breakthrough",
    "bridge_arena",
    "capture_the_flag(horizon=300)",
    "checkers",
    "chess",
    "clobber",
    "coin_game",
    "coin_game_arena",
    "connect_four",
    "dark_hex",
    "dots_and_boxes(num_rows=8,num_cols=8)",
    "gin_rummy",
    "go(board_size=9)",
    "go_fish",
    "goofspiel(num_cards=4,points_order=descending,returns_type=total_points)",
    "havannah(board_size=8)",
    "hearts",
    "hex",
    "hive",
    "lines_of_action",
    "mancala",
    "markov_soccer",
    "matching_pennies_3p",
    "negotiation",
    "nine_mens_morris",
    "oshi_zumo",
    "othello",
    "quoridor",
    "repeated_game(stage_game=matrix_pd(),num_repetitions=100)",
    "shogi",
    "tic_tac_toe",
    "ultimate_tic_tac_toe",
    "snake",
    "y",
    DEFAULT_UNIVERSAL_POKER_GAME_STRING,
    DEFAULT_REPEATED_POKER_GAME_STRING,
    DEFAULT_REPEATED_POKERKIT_GAME_STRING,
]

LAZY_ENV_LOADERS: dict[str, Callable[[], Any]] = {}
ENV_REGISTRY = _register_game_envs(GAMES_LIST)
