"""v48: v44 floor plus two real fast-climber continuations."""

import base64
import json
import sys
import types
import zlib


def _v48_package(name):
    module = sys.modules.get(name)
    if module is None:
        module = types.ModuleType(name)
        module.__file__ = "<bundled-package:" + name + ">"
        module.__package__ = name
        module.__path__ = []
        sys.modules[name] = module
    return module


def _v48_load(name, source):
    parent, _, child = name.rpartition(".")
    if parent:
        _v48_package(parent)
    module = types.ModuleType(name)
    module.__file__ = "<bundled:" + name + ">"
    module.__package__ = parent
    sys.modules[name] = module
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    if parent:
        setattr(sys.modules[parent], child, module)
    return module


_V48_MODULES = json.loads(zlib.decompress(base64.b85decode(
(
    'c-rl~33nSuk}mpJ%JRKu011FVN?w{R_zW%6Z5>Od9wpztJroX91d3#hKmd&bM6q@C-'
    '(SX(nGu;;1%R@8HhQLQqAIt_B{J48KHjUw%W|=*dhhr5M$7qnRgA8RtNHR~R2BJhe0lHS-'
    'uZHVm5oN{>(zQ$j7C{`wU{qgSw5T1SNW=(&#E^wem0&jZr;pZ9=>{&4YH4K?w#k$t77@)-a&Ty<{mtLb8pzm-'
    'rT#)XOjva<Ik&n`L0;e?@w=Llj1yE7K>?qGg{22<@lzRkFlTj!JAoT{(%DgW`5?L!avojSeUM_%313w|Iq4pvU0Y9LcNP()p~Oe-'
    'oLrm$@=YVzBK=Ccd}_QbM0r{Y_IKGTNdV%XZTgUNl`4|4_o#Wni@hY@LgPqE6~{9%<gsWz2E!OXjLrDfbyxC%QyIc$7fZse2;V2o'
    'zJE>nJtmc-xo{s-Bq@(ib-~6-dq-'
    '$X(P+erdU3sW$C?{y_vl>@65zci>qQrE0L8Ie6aaxe&kcra%pCBQJ8<tR@waAEZPlEZMItG<D!>k&&;yrrnT#3zA#;V-'
    '^uc9yk0I%jqX*k%CoCtGA}0`_|)7i`DL-p7V9(fg=S)AtL1!}U6-p%vvsm}v-x#7yMRHznavlA`3$-'
    '(q4RQe17oHMFuiTFse*0AKd$oCCA@nxdv)~u`QeYxkIaI%X#U^ad-'
    'eL{@UK4}ot*p)mif)S7e~*Jf8#%&J^z*d`s?xWbNcJ(FMlzA*vhYuUmU(ZrZ-'
    'OyPfm_sbNOG64*AcYk4|1cd;aX-j!v+iS@)MG$3Ol4^!4b+zl{!md-'
    'me+Ic@!?$A5(lExUd7%hAzGdgw>+m*eACNAwT}WA^`Fp8x)O^w*<jfBEG#ww3s_gKWRocjM-'
    'dJjfpPzV#2WUtN&8g>w7u8TNXR?e)Hi<^i5Qa!>7yz*EsA&5eF2XUV=XANJz#|BjANemXh<^03!8EBMRNPot-YFAtwSd;K?j)~BU'
    '~6F!=)ug;2P>wP|57achC`Fgq<^m~1K;#bR?19@62^WL;_KAq<)s>bKC_%JROtE~0<W>Fk1m-'
    'A&O`#<m+|85^dC!YIKhnkx&&v6I#%IdtFm8+sf&)ZostqNb!eMEIxOh);5TvS!-'
    'Y@RPCqpJKzVf(zyr{`wG{zdliVYaXO{pd&6!s3QTbu#-`yA!-_c;#!>)UuC1`SIt|@?thZdd-'
    'y25CTtg=|I28SK~`0Rnzi)kwIy5X4mHITgtF3uJXl#X+vg~rkvy}L*W+7;=KIOvvdKPG>5%3Zw5)S3q<JSCtg(`V}=-'
    '+Z3C;K2|c}&q&^!!L0qLi)rZ@uGSz)8d;*nDhgj=$=u5)Jg4d_i^bq>w5j??51mE&L`1r|gyhSly;padREW_WxUGh~Zx@_C6VO~J'
    'JvRbuhQgjtv+>8c#z;|skBHOdr-1x3nd@%RJq;=|V<m}uuWJs{t<N55OXt_amMU!pY5e?<kU+%-'
    '?AnjWkrRytfgueyaIK@Wh%ZZs$T?Yq9FU%mZ%ISd}<!~4@X}O7@&7c)MT3g4?=};X(D(Vl#VmbeJ>>E!v>^gI4;{Md<;w6<cvv^_'
    'd_Mc9UUp{>K{P5|KArp&vRjy36>&wy{o#I0=Hmp~6R+upsct&VM>SX*E*zb#FY51B#b;8e}8?)_c_uJAukN%p2f8G^02bo~skdia'
    'M=1ak9nv$K2UYjMIl;c&4d$atWSs&GLyJu+jRn=-cN{5GM_TKO)^JQ7M6Q|n|1yW}fR}+{P*m5v0!67g;%(wK1hTXj167Lg-'
    'pI3mnOlXh(j9c{Q16oz30t&%xuF5HXpBMl>N^AgeAra-mf>>m)Z$}7snt5G!#ldN@3k7WGhfcOOH|B^bxmmEn-'
    '0;QH%yP)!GeN^z*$*@VH^(>%^-'
    '8RcY=NkP;XP;T!aud`n320CPqDe7>fA7*hMg{F)heHj3)g)oYr+2LWUIB|yxTY!IXs}f`x^&g=HkW-'
    '0Cu;nc#7LYJ=q(!)sR|HtxY4F*#$8D!-G~odonPMK9S1>7coBnAfKP!4BMOM>FexOX+GR6(nUEdfD_#Beb>ogu_Y-p?9Y7q-'
    's~$uyPh9E{q^XlE_5c_yI7mOVI+>%m&>Ba#%9TuhAcvZUH%r@p=X8ZF`LfE??47J+(T~Kt<1ZrY>kL2tj+}Z3V#G)znM`Osx)7~?'
    't+KCrll3TvV(`eZ6{T{**ITz6W(ZIwmm^>AZlWR^Hxn#GeOb#OT`D6{RLOTn|rW$hAr0}+ZzctC4WfVcrmSM6ZgWKd${3XpNTSUI'
    'Hlo<fR;^HvZ=kHE&_YO6tO$@^h5AIHv(Zk9aXF4dJIBjAa)tr`1<#gqe${n&xP>y^cZI46VgQ(U9d24`t+0J7>xW4`{p+z`KC%w<'
    'hFw^>)`sf(`BIm)9H6+)q$Ry$qxHW*L`!3%9%A`a-mNn{1eiE^uCS-EiWwneO**^eZ#hvtGRFP6J|-nz3_-whCSWj)*@Q-'
    'NX0&G;W~DtGRTb>DXrb+cFBQvYPUOTzgNY^gOB$cR{#4tM@<KwTOLSIeL0`Q#^>>9`L~-'
    '@>#LSyih4)`%=rt61UHTI9%#DU2&{Gs`ir-'
    '+YaubOuK!c`C}5)fh~!LV4}3FP`(=xJhS}<ZMuushS7y_;A{p|?5cn%#9p9THa%PUc(}`8<#bSEnL`kbof={&Ura4iDRr`<Om7Si'
    ';^2>W>AqCGYSY;rDk$i~r0mKU?_8{x``ff+TKC()#Po9}t&aY8|aXl-6GG^%x^j<~63c?;Vb1o^8d15a>9ObEbFg%EMPjGz-'
    'I=1yO9WUpgr!_>ZC8!)cCBkfIUAt%2y;!#5-HVlhedNhY^lD$7LfK*VfKD7JqMTYu^m|hl)5!?vR7JZYJaI%z;{jV5+dO1*ASQ-Z'
    'o9dCS5Zj?v;_u{oO`pd_@C(h?nKOyR;I`jsIu*swi>3KxSo!5Bf1j7r+#E}&_j7JGN4sfQS_5cDr>KN2D^z8qRW`!I#Vm)L4UdiO'
    '2lYu+LQw2SA|W0QJvybsm8xB-'
    '@~zVyhfN`mA=nDRNpwOEgV+jGA|D<7q#DyAs65!Qmgv94p@wms!xp0j5XV`b6J})+trE{095QUM`F!ygIF^~VN}>b5k4~{LZOnAJ'
    'vt^OLQ#)2{sqJ-nosE^&Gm>;h=I)*>&GlX10*ah1{sObnhjPbP^QF0S`EA=)Yy0yxo|@ZYG%0z7#SOguWvA~mE$Q+!k@g)_Cg*0!'
    '==HQX2lAIb;T1@}Jk#aHWm7>X5XVcBpH(gB21JrBHRRice;ydd^S&>(=Zo#>V!(t!vD_3mBduZH$<APo|4}Ze_WrQLl?|iYj;7l3'
    'E+f+7Ne!W?x1JUQb2{czb1KafnCAN(GRuvN!RzI^(5%s`Vmi%=_k|HHy~d0w|DUt*<$MmZE+{rZ5Jt<|oGgsMN5#AmD_{n-'
    '%6%$^lK!Ac+39qC<ANA&zk#emRjJ;bK5$IL%)g4bp)|*6i<v!aK9y(JYV4E-EL7+QHO)DDr|%M+KeH7MNVOEO_oTjZ%44s%3dW-'
    'KHG-aERZEAhl+1c*l!@ROjls&)!1>uF`(%}AhIpe=a42+Z0jDUAq!R}QQvCqys9E_?6=BBisy-QH{mn`>Sko-QWzk}b-'
    'u8@8VoC(P!I_}1M#3DaC#vxrw*~cc-'
    ';FL%P55T)y41GRReM1U5EjNxB?vk8?;dUf(hW3=h_;J_!k|S=n%&fL6?%~}2>!XB32U&NMpHah8Yd|A0*#i_`NiJC35h`i((%FUv'
    'R=Lb$AMN0Kc|y*Qxnk%Bwzap*Z|x}ttAkyipd%i7DLZ)6Q9~m9yY@!sSf;qELub3{yt*5Db|2h5ZV%iot_?e6Z9~;xu~8!Y5CM}0'
    'F#?EmC)qD(*;cpz8o=#ddAPw+H+_$Bu~)1pMqfD3YLePu%GKx&NL?nq3T9;VmA(bP#{QA1HF90@BQVQT(zL-'
    '#QH^R$HK(b{CzQ6&9C$2MCk5U`O=&rbAyqBoIixM@wS-TTJY6eBj$6w{e`V7SddjRt{=mk4W{|k*(5j38{&JAA#Z_y6RYw8h>U-'
    'Re94VDSoWv=tM3?%l^HM6bn1oWBhZ6`QC(gSAkTs7|AQF5FX&D<2q&*lAo@T)0`44B13zqT;ONjc@E~dcj1o7S8u;z_<n=Gu0xSl'
    '&FQ^uN*xbUa<KIOK4}1%e8B3fWYa!@lGgEDb^u@QX4-{HbW-'
    'y=FqBE|{Zsa3USkG>Tr?U^k>?=6DWDkk1BD;~?AoP}&8_aI&E5j76%6|Z3=iJIjpw~PmIHzeQ^4O5!WjQg7A~>8u6=!2yUFPTmMm'
    '84Hea_w-$N`?+kXPMzd*9!Ni!}3w)tQ2{zT5k*18pU|ZtNNUZ)xk^!T4$^54>)krL+y!Z}cx_p8i~exp-'
    '|IQa*kP{ZN=?4UE6t$mHwPSi;iq$63xJBX(<<UyuBi;_L`*Eg68U=!V_N)PN6~%#phJw6$55+0NoD%-'
    '$_HPO=4WdR9;OhLR&SVm*k1ARX73GI5fe7N+G5qAdP7dq!jj*Eet4`sXO{);4ZBuG$u7)gOFM!@Uc4Ugd6KxO=J_`j*NJue$NJcI'
    '6t3T;~-j{&gR~d%<M=V8#Wbb5rjciY@}#*r_$q4g=|ioSO%RdVWV-qwK_gm?4FY?bonIG&0K>1ziWCj2KC%DCc3Bm;LxvJQH!5Z7'
    'if%&g{M>-'
    '8SD0Kge;kH%<I6hbR9BSt0EUBFhOAZ_t_~Kh{h?kaeACVOd@2LZ@o?he1i<C#MST9W?X7IoQrd>{d=Z!dYGw&fVc^J_)o<hiGjxU'
    'zg4DD|7!l&vR>l8=J9QSXWN)8eagHU>aq=cf}=Ghy1Oa@f#QmHE6|Mz!$)N`e-'
    'gx%Mp3$A2i4AG3yr8Gogn26v>b<@?AJC&GO&@`Cij{G1~Ede?;7CFeE?vPr(jzqiR$zO6`Z&E0WbFIM+BF6fna{x@FI9ij_KZbFX'
    '3<ZrQWar*7<>mcZ=nVx%hCXQ(T$*&F14^fQd5OBV0-'
    '(j1D)@IpYCF3Y9)YmA``5ZACYr_Y>^**i0;Yx00PT!pQn^K@RV*cB8tx2)cTz2v?K3SQw+B#m&`j#m(aMgW_E%?d|vJYA!wRAr7e'
    'ja#^JRjc{<UGK}xe6Z%>q~oOFf%##Oefxbsbqa4Y0=eOnLkQP690>kSSWST0*#8ovtfApRV{If9{YTSnTV_G(`IKZ8-'
    'vT0jid%CkW~#$2Vic1L61$6Lx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx'
    '{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX1a@Jx{GGIi)OluX'
    '1a@Jx{GGIi)OluX8PwuGwtv5w~frkHsic^aPRA{9<Hn9!?SYsu$aBi7B}XWm_4$wKF6Ts=~nr<-'
    'OgRAXk&+*yIyA6&VJ1=E|%qZJw<1#YPFu+xJW0CIeNdp*W1hT3%H6wb8F5VL=ga!P(aiHPca>l9G%6x*UNHcWQ;d6XJ8-'
    '|EsE=x#ViAk2;^Weq=2T46kq1a9EWzkoKyG|{20$6<jTl+Gd`bxUl;2F-5L#RU}h3@&~WIDuw9w8nU-fL5SUA~y2__hBU7S{u2`O'
    '%d06MDwtF+XpS^ucQ!}cj^HufsEnT#x4GIy%t}(W&f}vOvPvgZZe^#yFpiL|53O}vDbI%_RPL=e{W<c12^WU7!XQ=6=)@DVC0bh7'
    '@#>)bfBCvO{GKPfNK|&AS`v@Y<XcFD}acB&y@W<;VP{m>j_G+M;=7Y?r;U1ls8RM`xv%s|VF!bY`1Iy0O%W;`cgWW<7s+MRj@}>D'
    ')Gs%@%nO}<nV^7Kzc$J!(X42=T<U1pr&S2mLNGfaeH9EU0E8IZ&a#g|#g&}lr-'
    '@Y^b8g9Vs_R`ETFm`6O{_yCwmnYAj9*ur}etdkAp_Tf@;mNN@uSYKrPYz$al7V3^1go|GO$TDA`i9kd4F57b*58+Ch3oge$IESgL'
    'BICfiMX!TBT@ewtbb|d4exWb>d5xKYbWBxTHp3v3;TWDLcjM|xA3iRLC3bW_V#@<d*O$ChaXbTihM}}6YaQ2I5QQ#iAU6g|9EN;e'
    'ms)3ITWrXt3KLKeMD*=ZNOb?PfWtz{(kV$4WqZ=d9D4v{Qht12QRwUF?X%KezX$4SNj$6L7QUqoB|zqbPl~kk7OHv2ZE2iVzgPq2'
    'I>V)BYdCWTjcy@bNc2pZ}Zh^nd-N#V(Rim(E{=00GvhGTl#=p4-'
    '5%0N8J9({vS$eETgxx?ho{w$7fwmoY$0$9rWxxbj6$lPg%|PC2GJ@)s)WeH`Ia+6W2pC9=ufXje3ali`trG0Bowd*Ke%cXA5R+6M'
    'Ry%)PpMmbRO3NG%NTZVOowS6aJaam*(m$|A7t(G<6TDjcBBz=!5KgGuHclamBkXT2Qn5_g%DQUYg6_yBxR9!8HdWnrDs?hi#XAgm'
    '3+7`3ap{oL-)oBD~vL<j9E|)9Jv#tzd=Q4~#%k-aesm!!?w=(CoeW_w{^LkkMjRh-ibUxxA)I<_1~0lNEnom*ys2mg_4%5*@m4&9'
    'yWe+rP<#WVqBbPzuo-`rFyFgziUOLF6Cod|zD5jvd$&IRwcr8~&*@tR0*?IS8{-s6}{a54apHe*pfc9s3<%#RsD4`?it5#3`B-'
    'qchvVjk^<WEGI%JL%;kAHDTdb$eG>dE4rJ%LN@8=yPH_@=qucL{?HN(1}lFJTRI_+4OFSy&0SU_5GJjK+U()8`Fwg%=ZO^?y0s2l'
    '%wcT$)-'
    'UUA;JU=#5CnR)J0qVg%UlBkOd^o~9(g6W(9I7wPBx(hn&ekT?l6+Q1!o{xom63lxFIKQ2u9CJQYaB<Jce^4pnwa{%1bmfur3HQ&='
    'kbAE=%Alc|eY<zMr)in1P8wm;ale8%CGLK;J~L4h6f^SHw5_`_6E&X9f0^FQ=ucYE^qikOEr_e$kwr$S9=C`eXe|rHx-'
    'o$zPRMhEnCTV!p0eitWisRpu?dtLps-yV8-6<A%UPG;kl#Au4IdC#vE-_I8B@=vyCV=Xi!(5^koX%bPZK-Pj6L66&~D$>>=2s|)H'
    'R{O8yOfHucS_6MJh^#y%n4<g_VS@Wvv)26aG3Vs%_9qQdS65V^9cobx{>Z^+a6fn!6qixzUG(K`QlH0|-l-'
    'IuguCDA{ah3VGRWY}8G`B;RNI?>`11{L=dyoy*7Gr9sR~0M1)a%TW^~I%0HrR_?Jn(;%O$E+1XtuSELHZ-'
    '?ZVRlB<Ul@5;9~fBTo!oDk~%O@BOqs#0X>)M4(}0exgv6HQfiJ0!sSuBQUGPLHV7&Sq{pyuD^es(wHd;#U}}|vdBkanCrmi6jjR`'
    '@K+&kXUOHKq?Z$fZ(A)O5ex_;nQb|GSmG;wigRSw^wri(8tk!Q2ZYboyA%wt?Q5mz~Y7ezxW)Ls56b)AJb#vGb@Mnv9Xor|CA*jQ'
    'w_<(+pShpQd1?^LsMdc+&tqhYoVW~D#gG9(9T<+Qy(|6i%!*}p}KHwgbY-'
    'W>K!Y7Ts;UoOpiX{!l6P3wIhfB6KsaW20L{|l1POUi9`QC*Qh+thaQq;gsfUf-'
    '`9%wNU&z(mz0%~|=wD|Veb||mg8tY+TfD7eIH}q3C?l1~uzAP^=@GzhjVw!NIL5J(BR<H}zMzO6bl9CFImLrsN84lBtv=qU$y*br'
    '>s`Y4Du#3c2{c4aLel0n%UPovRmYc=>tpi4}U}R{xF3iZ5#Ud}44ms@^2Y+_Y0YU&ukdl~9FjSfYkv<fYt`TX>l@Heipr%nz;B)j'
    '@s#>ljq1{|HZ?YDg1-L1oUscC>K%^n8ZUGBn<*!D+vbGGMw_NWtxNMm1-'
    'IfFPzKrto07*`r6828$u<g?P^sQlO7IvK*gAHTG@C2}=!?`BcFIldQj-f-vT%S|(M8qvO6^~rsz65^P;24%fEwYeIvUcnv7eWV#Z'
    'V9>w$2;^Re<G2ah{cjUE6Obng|h|fDYv0SHzSzHYVbX*!hA8B&kTiFjV}i(e3K5sYcvvO=egNA0J%|4Cl5^%vsHIK>*6Uh3o|z*&'
    'Ok+Ae$u%TN6*Q;hbv)(Gx8^ikMyBGJ^KroV~$DN1-E#HlT-pg*b1Eq;RQ;}6B|`-c}FzV(U-'
    'ByDmMBr6|jTvOAtBbnYV6$7`|o4O)XMr3fhx^?wJw2pj+J50mTBvTdimL`8nCs=@S5oWNqeRJ%%8fSh$r_ukSAT#(5^M*kSu)|G?'
    '~MBb32^KBaEinU6me_pN;Frakd)QeM~{62FAGziE1n1FwA#N`xEQTd83c9~LFvF@CcoN}b(|oEtQ}HIorUJ~ddmZ{cJ_9B;n5y@x'
    'UUbAf7aUdB^sZzv&Z4zp^J8z!2Li(%Aqa3%y1YgK~sg!b6j$TVhqt?V6whXyRP<6I-'
    '&<kqc|{IRTZ>bzW5TnnwHqzwWL3|25riZQtzh_*1M0F2gP)1~7??SOEMJ!d(X*2mK#pV4;$++hjobL{@lvNdF2uYps2`xeR?`UNZ'
    'fzAzN*?ORa%qgB<&Yix2ig52B)a%9Fw_)*_jWr)yh1-'
    'ddA#aTXn2g)d*hZ@DF#wRgwJ2aEz2V=d^VT@5RY~TsL<81&AIU~D)x_j+<M?&5RA61<LzW#jw;&l6A`@LgYh)1>s$I4SKy2gkn_-'
    'mGMQ;~jk`hF7JEj#T>XFKUvPq=yw&h<eZ=V4DD3Jf!Byn65YZT!}^_gDX8y~ArdpjGBYlt)0W0^Ub(m2?#63V>HOi1mG8k(a`4My'
    'O|IkJqq0G=)IRh~<JPm?+X;L8r+{NyX&zcoy?Ti${%i)VQGBrfHI27j2&g697#+?P0_7iH1NbTIEYEe^^HFBI*8I@0%Mjg`yY7h1'
    '?r%_}t+B-'
    '0eHfu=l|b3S)l)cgzFDLnHxunB5s{WW6bxi}peiGeL2NNSu=sHE^BQpek&=O`@%$nTIAshV=Z^FRmT(rp43T&5pZtoA2KKXe70PE'
    'g5S<d$KvyM4jn&>`pr;-Hsy~jwZnEX-NqD?k1=Q)h}n3+A&g|&>h=B23UIb@z!u6jvpk67%Mx+cp0SX%GnsRH}`)0{n_)MMhc1L<'
    '@3YeUZ;UaYCz8@1SKiG?*N~YF*-'
    '|t<c5KPgb8!7+itV+V+1ouoHSEMW<F9SJY_owD4^S4LA_7g1Uf+6%Co;jbXo3xDWaqfnk=hCmQ-Pf2qbH1IbxWqA>u9Z3V>(0I3g'
    'Id&sS$6sJtO&BS2iNLSa79+QzsJ>BU<cXh}s`I%?9m*&>0MDu3#N`hpms<-esKwrjnH-'
    '|s)_A$vP2X5;y!Sf&ynfcYI<YQfX8S^+t`Fd_?9qZllbpvKdAWn}y5e7<n<%<gJDECrje;05AhPst&d3rzA=J~qrWIL>kb_lS$EZ'
    'pfjO-'
    'X6|wtj{Lmd%cnw2`unb=x!Nj9Z2Rd2s|6LuVUbP7&sCpT>~j;!H<Wpjz;JJl5`~9|0dxb`Y4qk;M;zU4=1>AMqZiVlo>c%iYL~Aa'
    '_`$XV*$7@)?^pxb9RAOzZ}0Di4}04_2c2MN9<T?=gohtcc6Uv?BD+Fa0IPzQJ=X%qJ%~Demwd8x2M01UcF=|+PIGpT+G+~+u_M?q'
    'gStwPmZ`MubeLdJ~~fNjt*bQkwr*lKD9;kRY$K!PY-{#?YrG4d~aVIAHV+P+0o_>gtO`4$%~_tS0i${v18v2VvQY62?)<F+-'
    'E1xu-a1RzIp)1vqM;M=#%%K$B}huXx&u-CdaFhx$)1-i#1(9E%gh(0R5EA`0ap!UcE;n6^MH<8dV1a%I4Rzrv(%Q1gU3S1HF#-'
    '3Ceq4j~ck)vwRA3VA(?M1?*Ih={kFJ50IC~H_8M6#Bwz{FA%J&LT>4R*&j1(_~R7k9=$Y%A*3IZ-'
    '&PC*6}%A!=SF)+JviPM0lovCj)RpomzQKe&gu2&BmDbQ4R1sEm=QK+9WG@8lQNB)nfxX@EGRJg2><?6F9_8@Yj(B_$c=|Z18y7`V'
    ';+B`|27QHLv3oZQjfE_5o@y+Z}T%hdn3^1&Ip@zX=Co+|46>_(zzWE20ZSBz=>A*^r@qoI7i_XdmmwYpMdagYSJNHB^q_yuWiQa0'
    '_(MHZB<<$Ce}2u30zUP2eH04zAe!XzwzrCXUeHA&Ec68S7y*7BS?%U`Ay5hQt%+4NOgc>F_6O{H*%l<YigjIc*iaz+zxbUu|){XR'
    'km>~ngLzzSiC+n086p$Tl;d1_dxJk#YO;Q*g&j_)qcwUr)CUYGlq=5w?jJzIO55AF)hc4$$W_@y+l?k<&8zP;HtOB&cPnr18laAW'
    '#t@z%J>~hdvX%8hxQn%uNT(^4<lRz>3oenLeq+a#FdA_olHSipr6?S-'
    'DUyKnLVv+E7DN3r*9$gX|{9(!VmMJhzx!8ebK99Sb`<B;S~}lDJX%Lcxm|#QXR`1pGLi}cFcxp54vcpx@xNSHul`Y!9nxDZm=e5U'
    'p(96XM19O6B|ayp4bAYa8aVe#>rPxa6kSkMR2J;(Sv_=@?y&{cmF76){PFIWv{H9`wGO|1CNw|$5Imm+s9R2&HxAv*Fn4?Q>7~E$'
    'cCp2rUv?O(!uWadP6}o7%x|xeAC!a9#v0sLh2xWCr2XMrLi3O5Z4tlTx;zs_Cl|F4=6~r?}}oQ?9-c<&!@RyVyj|$-'
    'b4{`K<ibkhqFd!dyhavJ@RS^3z|6%%9$r|v0(XwD#6>hdRdLcVGHUe4`gDbmar26)i*AEAw0MEOjWUxPt`^HNz+A3p%wKF4yT!C-'
    '~(~HeuRI2BAuC>V84|G>5fuHHPZ{x7w>#~Ma3QJqtPShcr4qA89r{*osfoh!^5<pWg9#cw;-@rU3IVcag?rRs8~B3W&&PR6-'
    'VJSS;<@(iN0%AxoDbq2Vc8!whbj2d7iblK~s#N#wCaAOE<K?SZvikQ>`63p`8l35t)~+(6G_MZ-UZx;O!1*UQ7@EA@>$pek^y+CK'
    'AWe3PxM8)E2CLL{^HFIKuPrk%s!o$pu55g_HImNe1dO`RX*ycs`nR#Us=JgNFg@Z(@yzjOk6@s18HWYDm~~IQH(*n1N`B7v*c68?'
    'H*^o_B{1bm-RBpzm{r1Q6>3mokJ$oz6L;8yu2ZO!ZMe7#H}kO)L}WlyuP*@5nfMiO~_|%-6yrvI|$RQlayfV~ygXc$2c#8*-'
    '>VR#ogZx2?*pEm$XHegSwNdV{Zp?zA|O+8jzC*`%g>WeSH%I{Jdg?S$;t*c=pmSuB5|3E_#@f80(Ag4~kuCE87sxRpTBmd^EAYnM'
    '7&L8*^<OM3tg0)wZSr-AujN0J-GC=J+Q@VmV~0q9@ApwW37(0^1TFzx~UM?A-kFu;EYPnjzjU@AAO(PX|zj#u#$gL-'
    '{}Lu3RxMePLaTKwrvBagP%K>Z3zs(n3Bzk-s%RvQGrWhxZ$cgX$>J|?s293;{_C-'
    '^*}ifU~WdYQ_o7Y~j&t1mUORDy)&VVUDO2zBsqImvmo_d!(9F$`+k7Lz~r^O*D_Ro{@5HT*i1+`imsp!IEs)AojKh;@eeGiTI(1?'
    'Wx`eQ590B}9805zz*W6VBBm!W-(YmgU6-#NPm|navzl5(JHhapPd6$g}gc=>gp-'
    'UH1q)WgYA*@Ja{#DWY^$mcN<#WZUyaF(V5)IMtq+MgOzMma-TZ>$B>n!i*9X4&T%>^9Z<g+4Uu0XaTSj1%^+oA`cycY=ka;8^TEw'
    'G?W=O2F6R@<y(LyZDE;L5K0L%{R>J#?gMy2{{&mm3WgmmlYSvwrU09$e+y)$5Fx353v8yKjc@z6L}%(p07w0u@tOJxpsBwrLR0;W'
    'Zi&&<_zl~kG^tOJL)a0gDe)vkYWjk3NcBiTcQ{D@LvWDblRg*e=nj$S4w2}OL?j~Mor0pRYd4|K8szsRSwZk67&&wbT4de8bl(Nx'
    '9#shdgD_ir+%5AK;Y0GN016GDCa8vsL<-?pJTQv4V#QexWH#Tn(&bsylmuQ%*t8tag8|i)p;pHhN|TekPv!-'
    'oo9B~B_P_SBDu<*MtGR<Ya60KAR~U@whbZtuz_x_$2|Ow>WWTyB^v-'
    '8!d25B{^T3c5m}tbRrp(M6jLiQHEXJR2o}_5l6Ovu5zuDDQF@d1P5w9FG6gE^<f`_YD^E1GsF5l~?1Tr<!=T*H@M_0Ja(WpkSGe_'
    'ggIqZGyMd8Uooo&*)SQxpPd_#O!9f5{2n_sJE)<Vm_FXzkhAFxZENw$-'
    'A_y~4vt$&9|wTL;dQ3C_5TkdTDeiEHv&L?Gs3MN_TPv88pP9do+!9)|59Ff564neA6MA~&lb3f^>=3OfgTMe889H+KkQI2mw0@je'
    'p<2ky2QzUDb+`@U9K#t6^pXiXU$}0{p<=FvTAWPk5M#@EgRe=vfC^t##K9cqW0H?$GuZmS7x;s{$hEI0YZ`yqpr*gM%Ad9<<Y*t&'
    '=rM_{q-%<BXbWwJq^U!f)Xa~LqK}fak7&NB39&R<D*rr}1377e|&d)2nSK`Z0oi2R?vZ_GX3{ZIsNIKY_xSZq-'
    '<T(n*3D=&ub^z}pyZqm2pQ9AqjNpX^eu7l;&CT6}J~kAmg*i|_QM1XhrG76aEPC2yC&=>`r@Hj!7&&sZzieoGYhRy+2@S70M-'
    'q2nk@VFiLHsRUH9W6B68D2n)E%p+q(sCFFV6ufE!}gK<XH`fOX`P8t!wYss7-'
    'SmbTv^cynhFt97Kieksr8Oh;vJy6&2sfwsdeSV{B^jqP;Fx<IB-_UaeBM-'
    '2MCSu8kB^*^5Z<@5uAvUuxcm!ytJwBL8^k5(f<lga<P`T!NTnNY?w3ffZ17cv(0#X@ssjO5;naSC)XN#EhJz+s|>J)$Ru-'
    '6xCwWJ2-'
    'QXHx<|q3bY=vY$(Wj(9S1qh9lg&k1^2ZL6S4GH^jhwf?LqQ*+J%a^)sgOotnl7iG}7ol?_r1TqNG~V+^EL_?%OhbGGM>k}lQF;I2'
    '?Pkq3ida*<TA%ZK04?a(gQg$!e^Qa70Ugh5Qp$aV%gIC6jbqFW5j+b(mq<8|Gm1FH*{Zf%{wH({H?A+w!iiEAKspU!6-'
    '1!$Nta46<nI*3_99|B({V0g7vMV-pke1-'
    'g20OT$|THU&BAdh+*$!g&o=(?%3p#hLz?EYilRKUhK`w>BHj6gY(FK@gN2{NT9m=_>X{NV@<ydq2^Fe6!9v(JMwyLHTCCwrPxjv?'
    '1`ZK4=kO~Pb$EMB6t$5^|Ttq|WV8g+J)Eyp{Zb(CvSCqpe`tv?7Gdk$ZbNyj6LiFn?Q3}HAOO2--aErSCh)KMSQ1^3t;(CqF&vz5'
    '8G4ap<lv(dDeU92u!h_s~Kd@<Sreh!C$R+@vqxJr!ntnNHQg~g&_B1;;9SNJi+3k4X@GC*gzk07kt7?98G$^r{7qR4%Hi?hHH;qB'
    '&x-8_y+*GA8U!HA`^eDd$>3U3V$S{u0jFo1hLU0mkOo<-E$rn|30!1YP-'
    'upk&aJZeNU1~}FbP-!612JV5ukT>FlZ-)#X>TI#Qv}dkF({2ZfM|T@h{e;Ib-zmMm$kiJnc*oe+9>}q(WH&+OE)UD@hB0ISyMewd'
    ')D2+uhg=<O)HFbwP1kV6v+)gUCNTexZsMV7zSj>}6kOx`8Jov~>lpV@8^F1_@pg<GjXWa)&RWLh%<^?i@oe;{SoQ%ct5i4@?{cws'
    'ooEpfUcP+c!a$FRRCX;3J8f~>Y^E%S3X(>g{v!aVWls04aH3NQhHH*mI;_<m>VRY3opi`mh=U;ITb-'
    ')aDjYVD6~TzP$#Oa2nagMd;BH5N+1r9;Zvm7|pw>yS?5gR)B!p{5!@e!Pb<MR2zD9J&n3|Nu=bp5f>sN7!DG7i78!zJ<@?yBYtC7'
    '>MV{Q9(oL844K6$Es(@Fl3h5Z*VpLVC^JI?CoXg_UVOy`TsVpU=y`9|e*)Bm5XWmDaO;@Ai#m*rWBZdD+$E=t4xcWEJT8jx=%xO('
    '^kvw}8^@#1o2vjr|tAGBhvcYXufXHcFKFKuxUOY6f01nI}$|Mu{gXD3HV?9ojmr`#HIfB}lq%EHuv*uj6>!gD{-'
    'E8o~YU%i}{F@;j?;ecm+xOEDduY3xb)S=;~+nYXfCobfiFMb<gA_IxR?c#~v-Hlz-'
    '?wbTRLHa9pCI8g4rJEsrP2UjpEY=1sS;%WSLmU^=IxoR~xxgPU#4F0rx)Gb5p;jj;zhHoE>F1FL@-'
    '7@;(3ZBE4De@@nr_gf@k@ERNA!1~esx0RE@_Av*m>1H>%v!@3M4(o1z8`6zdOl$8Sy?@efL9TB?<Q5sXeDQ%Z#l$Y`QbKk;c2v>B'
    'Fbx-`7Y{4c!wNN^0ftT8erby7yI>7d&y=cMYGp#N)Hc(fSqvKT;IgK6jB#kRo|jTuQ0u#q-'
    'Rr)|z4=ZDBM&0ab;ZuXl@KWafnTTuiMREkd+*4H=S@bZ5WMv6<BNeeJS?Y8JhX)q6+&np3VMxkKP6_Y_Bon(TwU{;;0+`&XgQBR`'
    'K5&}KX*1*F~ZP3jXDC=Dti5n#@K>?0Au?qjM)BNj@_)o4U9)dwM6fLK~ea>#2=p~<0MrY;|f#g?{>5CHr~*|1EEV*5?0k3`3CJL6'
    'CFc^gJ!I3}!|P3HJ5*a_;cm*5JwM4x#=ud`~Id+kIf6zJH}z4`LMDOyiYQSWO0H3X%?QmKTfIKvwQqP&~|#Fm#2L=?6Ij^=vZJuK'
    'bb`y>$%VR#7GonUwrm{x$VzGd`f0Or0GMNK7q5m4Uly9jkUVY~KI<`B5$90l=Kx;Y22T{DtRn<ubo*~PABC&PYh-Npmc{H54HXcS'
    'u`r4&t`hLwj&XJvUwVns~rK^W*DT;nrN;n7yuny{;SYWw;hF$^Y@_I4BsopA<~mqxIe!>lBLBk6E4Kt32y%#k9a$QQSuMD~%r5l+'
    'YGs<;9;08UWD6&a7yCdP?OD<TVstrBJj5q1%6YVv)A`nFA`lx++q8(a%t(rP`$io8?ppgra_>j1vDcNxo|qdJY={x`xC0g{)DXz@'
    'q9Ia&@Bn?`(~$6?w~zdi0cqm{b2DGa@`UIFCd2DE*3JqLvV?YndHIheG7M0=-3xSu^o+`KT7om|k&s*-'
    'bBm+fW1I&@)KNW?SuThF%h@+A9u@6n$ghb__cbgh!MYn62Awx~7a0hpJ!`57F4_2T7IRCXwjy!@;Jy~$aDc~If|%cVzH>0X#^y)b'
    '=V&ZiU8wz&z*30><~W{Tby*>wrWEmB^fr}-dGawCtwI25gvg-plOrb~391}RMr&1EmzjM@;tYfct|N|fo)bY>O1vug{)iPJjDDPr'
    '^0z0<Y5`<1=xb$zR=dW#$wn=WUU{Q@>xODDCsB|5-P&UG4dK3Mk@oFVDN2fSdtG!+!iTCsDU>{4&Urv6-'
    '#+hmft$U5Ww&_tfkz!V@yJP5{pi`;af<=LB0(>Cea40XhJG{9w30lr0eN4O<Xk`^;1`WBk3^XZ89l)Z}h*wS*?dnvr=^z$t*El`F'
    'Bu5Z9YVc3cf0(Q5T^KzR9K_F`JL@w*XGiBK&%Dz>Gxq}K*^L@FT&p>b9<>P?vb~y;sK>V?@*}SYQ4tcpU*G(7G<}gfAX79&!#d*M'
    'td@~1yI|73n3A9T*na$_hH4BvsvGvcCY0U6xYcq!ve@*g;T)UjS400Y_=T&xP<WuwP%-'
    'ofkO_HRpGH)KRmzo*ukMq?fEPh^6HnR#og?Ua^umH=Dxanx^ffA)y6@6>zebTlks~v2Z?HY^rSJ+;V*ONPkWKc4fr)|VPzujH)A4'
    'he0<S8oX=meK-mc|kkwx(@vmkOmD-'
    'H9e~Z@kc8L?%#XQN(|*FXd<IcJvK}uE$mlewDuyk{9HY1cg{JLooqO8eNbHfdX|gFo5cHO+A<Ce#M{%Y<pYz7&L|tz`zXPyYbjkW'
    '_w7a1|e!d$KJmE@%O*k7_7H%-'
    '^|z~V*Q{E%X(Iv&ykHK{V$mI$Ao0Wo*HN<n!&+kHu&vZ;F*1E;D<+f!_m5DMsYNQ)nUUQ1g=cWD>Mf}v>X_D%!-'
    '_^Sk`p;s^84ubC`h97yV0xI#xDElKrNWnH6XE3y>#lKOG!tPJt>$rUJvF5rZ5Ggdw^Ymn-LxfbleAbYdqM2Se8kfuKo2lI&7m<kL'
    '4Z#4E_Ex#<KPAP~d>76P&jo3Udw&a7H<N=G|*9G{QoLA&PF98oCDUvr=7p-'
    'b86%x42u>{Y>IhU5>^Vr9v)se@=4Q1}fbowQCD`E*(2lbbH>)`@o%JwyH9e5TSjnu<mSD$j2?Riu$^>GHr2yM)|!rh)}qwi}Zc8`'
    'zs$AXMzC64(S+fttQ&5Nn$BuuNp19Z${1gSdqi9r1dvN*Ncln?I$Bctj^k;(8cw`|0s3#_)I8{EY6vnEs4^;o$tg>BIH$^u)C4>W'
    '26kd;J6?hR84BF)qHTO-IpBq@(zrGe<l>{Ou>(I{-'
    '2e6a#^E^xHecOuhhusFWMU3|4P)fQeH~^H3>poyKHL{H^o~GDm`U5go|YGM{*InO&`sAu6X+&^fG-'
    '!}F)uLc+tTWZnb*95wWY34^rr#kYO?YQ8WV0MeVu_uuV(Yb{A1MrS}X?HgOs8unq#=$LMXdR_|ukG-'
    'BN35xU4&K2w~AFVD8g#gA(IEMsf&1V<+yOCAFyD-S_^<bMkO~h1!?^~i+PlS6DF(0ud)=jH3?Ew!0R*|#y`8k01ijVxp8}vq(hTt'
    'vd^DEat-%mSyu~wHo_Al8BfM4wOMVsa($;UPZ2VeHL+TbU^&%ZXb2c(Vz?Mo@5chA;0($hx-Ii})<)2kgA9!GeGnz@qw__uVqBPA'
    '2D!kfN^mhVT{7ZU&+=DCB5Ta5zu1YWV~F>Hirw6yB#vAbd1(-6YIeAX90Ft8W}f;GxuSu${oT6&QW!Y%;t05>J-'
    '1!c4=RQL~tF+f{^)aaQ3#W)5kCU7rEzg?}87y}pwIx=GA0=eT2G33eM@l-S$#b_3YF-W|n3W7-'
    ';B6e6?gG1@HVel~S1z4_`WKlW)we?#7o?0i-Rx6iwyon;yaB|$~65+yjQ+6Z>iL1^h-'
    'Jd%E9C595WtZ`MIJ36}fEb0bi0QCp(OonYUTihHtvE()kZ`N9^opY=F>0%${YitMP5vcI1!PPYG!qiGnjmch_gAu<`1*mIiF6>Q*'
    'xWVYm|Jb|`pwMu4BnclW3bI_o;(wbKA?`q2?tn#k_904Kq2HkIae!=%;oX0@bg|soiAt4wQDvzr$~2>6gAl7C)ON2yJ_d8XLt}lN'
    '_$j=L6byv_Y_t@xI`HAW(n#r2!gpzguuXBB!e%Zct^%qLTaT99`}MZ?_^zg8qyx_pcOmtC7s5?Rv|*1PFc-XYirH8_>y)CXa*RmM'
    'zHCQKQciSk-T}|msJVkq|_~-{K*8ZVtv30gk+e2e_@Oa9n83kO=W99W{YL)(5-'
    'I|Wvt^S_d1`8ZCndYyjw@x<vOduQx@5rc7s(8V}APD+3$acv!}h)B;ZhpGqf3NXhk@}?Er8{dePNm2Z>QX*bbM-wizK#pvr|mH(E'
    'vg!HL8*m|QLiY!oO_6E-'
    'edJc~M^7PYRy9g!yz_(_DiSmY~5G6I^wb@n)iUb8J#%yVC~4?0iXzHm%sJFOeUZ4vBwpaddMhEt@vru8&ny#M^|B3j4uMTxh@XGX'
    'MAJ3;zg{7iadGpX@g`pPiQ)iolr?g}mdn`3>is;xckb&uSXp4MT|pYq=H-'
    '844r&70KnFc55@sLa4fDe_R+8|Gh(HfFWHlJF$yywz}AFx_t|xnRJFY?G9+HYa0rFON`Dk&huh5z}v1t+RQ)G&fZFkHSmBRk1n^q'
    '+u%#U*^+uP1Jn@Z3Ma4ugjL#!n$3!ZR}r?cgNQauYAp#T8Y$gqgDQ{XeF~J!AA++Bc%}Vs|(G{I9^j?mM0{@PV#*!uEAw6?1aFY*'
    'qxxqXz&<pY{<+I)>L-'
    '_*8QO#KZ&3{(av?gYP=DA*NgdryGGNahHIb^xD{XsjS+j#vtWj(+CDgrI6)a9C!gH!)T!Atculyt&coV23@~h7(%@WBz{)WD)j0%'
    '0A#-_Ugdkul=VXh4bNk{2NJh)@Y^{v=hlmpHvXc{2YRzM8wI<zRFUx+PVdNaT2uv}qjm-'
    '^w#ER(x0z6j~$YvqgG9ZY68u{|s(_epondMb>4Jrcj-'
    '=9v7Up{>K{P5`!;qH(zi5)yi*A0{bESb~n=cA*a>`2XEe#w`hU^Aab1x=sID-'
    '8{X%VJVG3BpVVnhp!J;FArBzmz^4ubS)2a(rn78OVc<lWB{N1v*K>h=05IjE~Z9YKfb(eULh!QPR+K1O;Z4*b!Yni0deeKo<TOx?'
    '}G&&JAPrN}gJz{otEjg>vTE8u7W}J5mhJ&@)EBFIlF_2iup{<M<S_Gnx06VPdch^Tqw4;jr(wWPwC(Qk!QEEZ&0@gVc7EW4^R57|'
    '=14l$?#}iyv7&g`1{uQeex(SGSo{bKj!kD||T{u3~20Mxss&#Vp!yi?430@^g1665<(h1{Fuh*pFjOg2p@C&IIu+W{Vkt19DLW*}'
    'o0{_4;>6jUFTbSI<Qb@TbR+z}$JGh)8+RagRKvhL4w5ixEa4VdA782Ep`Zwpsg1F2=?{q&VZW7#m#%Z3~Yf-'
    'fV2w+5887SD#WgsHV<s*$9CJ39<j|FeW}d2s6{xJYXxH;^9$GRG=sisnv%#t{dLVyszMvz~>+2^V6GQd-'
    'FUae@Th4p~k72h6KEZS-fbvoL!aUT*Z38XT8xZj3^EAG2C`68Mk0w+63kT=iy)*dWpx<Gc!ymQ(4%+M5s0WiUmQaPQ&nHxSfNpX{'
    'VF{xJ0Dn(_o|lz3*V3>97>nN?jm|8HVHLqLAL~fo~wL|22AyIO`QmaRxArhOSf@IK7`wjUZxH;S!Z>`HVgE(5qtAON_UfS&X+=(~'
    '1+vQ?usy5caUxL~T?-9K_n@#C}tUhNA9nQhTBJ`<nP9I)<`|{bAcGdBQ<FN`h?yLd?RP&DS>zif`+PShx0u-'
    'UBQTE1Qt41M6<XB6*v+x~W|0fuvC{9@GdP4?>Y+hgAiJl^6AoTt9c~f%PoB2;J!8xo9P#$Xrt;xz2fQxAO1?#Mq>)pDrupe#ip}s'
    '))hBcb2Z?bp$q;6PnRwQ(GsHfn5x4Vr((7w^KuBj{8m0+WPwc#m>_oLG&fTubF>w5BLMh<Ua-HQ&0PEOZQW!^y}=1eAV}QkM?`tf'
    'zURe8u^gqEO&q_EAWjki!r*K0{+6Xx-'
    '1vw5|Pc3yLpb5XxjH#c1*X3`O&>vuLym`Hw|+>p02S1$f_OL9Jy!B=H2;%nRe{J46e(!0ja-'
    'M5M+tYqiBKASrv$b0TT55`01~Zg7si4`V|IdXma*5CUXr!Kei+c!TC;}Z72f=Fw`8LLnz0bvvmHPo6{lpPq_J`-'
    'ROMQh$LujCS4{%5ENSU@~nkyT}oe;cd|1uMtAH%t@mNUHnal^*FNiHx!JvE+Fe=<fdXg12f%8Q;K2bhc%9fRPo6L~dlTzgO0&ah`'
    'jUADT-IKdp1@QR$?6lDC{7TS_9asAtmt_IOS@iB7zscSJp{kWjNFTtl}nKlr$k{MpT0ZBSp<AI@r9klcUfp!&5v7bAFq-OHam<mg'
    '<KRI5w;|IWpOZdh**bPNenZBdJ*ry%wC7Q;=U=i>&G7e{#!81>LZE|t7YzKf827)ZEBD?FV|CS04+V#6bV=EecKtMf@zaJGMiS+O'
    'aYbzrLM+UW7Efz?9u1!1$|v_hcvYH{VSU5ZvvD|FWRf4fMD|?I7erF``r(r9jEDL$;&#`u<*aWUDIq?PPL6E!=pHQD%DOkuQc-'
    '3htPV*-eM<d=sJK?5-'
    'zrqtfmz7)qy}T2^IC)@mYh}DMzRVvK&%ayiaN|ui5XEV;x}dB)6I?q`Cz6dT{G~h%pM+=E^a`EJVsd3Q@#`BMrBrtu>lW4lx-'
    'u=gPL<pU9XkshMxUsXzVO*d@i&0Md`iiizb-C>kxAx7#)t-Ah9eU*?_ESz`gc`Peq`eGjrYvxsAd&utiT>f-l}w6V$gLJ|t?ejt-'
    'xus^|912^`A`s*U%?#1^iPX-soY*B%s>!Co@lQW<#=n-O^1s`TjytX=vHHo-RP!p;%D;GRwccPTlbOCe{;=DU&1OI2DoalTY2NIW'
    'zx7#3f|H_8NfgS|EgBqbi1~=`40nSj24KI;ykqC^=toQk@1T5j6rXz);Xq1ko3c`4q&i7Q~A74XkDBjI_<jLdi;SLpr*u}x^pMX|'
    '|n=SNj4<Nxf3_pzwrf1iBwp+GR__wQ8bhnNg*>D|ZH@J#_Y<hLlkgC)C0j`0%;bVb@v5N+De{CPUYRQw#&Y||4b_7$e(#k8OVG*@'
    'MtH4H*#~)_(#UrI5;aT!MCEfm@%2TcZJBL?8>so}xV3{nThEtrMQ<{-'
    'zJlbyqMwjfaWBppvAEx~rMQ#ujll^aP0p7v`LPG>cFu{@U!=UC%J2eBmz9g@<AT0-5kJNYIZ6!9OCK;ej(k@Q5J}!wi+6@-'
    'y<m{=>`8qpN*x}>()m4eSYGnxjWIZly*q#fU&3qNZh_eHRZ4K~uq;o?C!Lw7)C*4>Fjt<1^A`Xus(B%{%5-'
    '4)_x<IYFd1srG?hrlC{w#C!-)g0-'
    '*7cl$<b;T=uwdq<Imyo@r9VP{5%Lr;ONz{;uzNQf{vthYdWWg(Z}g&@79OQ9`7RpVP(Nqm4@bBNA^E}7(&M6>wqjqtw#?ovF9aEj'
    '804j)_XSW0@yU7&-'
    'Ea!LOe?EPe`R<~EZ`^z7^=M=I;ydB@?zJnNTWfsL^qLpZ>K`YqdXx|T&2I4M1cKZgA`du<m3}C6NG5IELseNF3Dc`QCO%_APLsj-'
    '@~%ufHST2Q-|&HOFo-CHJ|hXux?Oeig&&9;M;8qRUBhXo_i9qia5cpZZ#EO3-$@#f_`R_Nv}dyv=#I=z<*2JFBh^o*gTAm-hw#!K'
    '?D|!Z4eDp&C9_3)v0r5#ru?~Xe+q-'
    'B9BkW`W`qC0CXK5ZtZTEOp2UP?uvL(w4VrPKDZkkgThb}VVJ1(ZQIIItj5{F&4l%H_!QkuJQ<&J<7~V;oLa0CEBw%pr3URhzH_#R'
    'KHup|i4~J+6=d?RR2DcMRcwgshS8M?r6I5if!44SXeh&x{}J}ejV453pgnTD@KF(#B5^M9%F_o^M>E!)z}jH2?E-'
    'KA*j=6Eqi}$`vr1scuKwUXYugMqtmW<M_iH?vB6T9R8tqWkXq{GDwf$f~O{sn2RoZT^gfY9ccZgSSC4*=;Zyu)8A|u%rG4^*GXXC'
    '~hx#02*LFIx){mlI|3Xldi1=Gv!c+&+a1re^y5#qmSgg-'
    '#&IbTmLHVk^O8y=~mELJdm<;+Nqz_pm$omFX3zAA~<E`ZuQNfl(hl2NM?17z~^p7(f8BeMp@12i(&tWl4xuo6NRS@`phpAZZ6<EK'
    'wSsTvg51|(N{1xPq$)61I?(UNq54~?&ys@fGBam>V|xgQk?jfHw~F=T_!Ks{d5j=h>23jtPEV}W9FQ8X4X+pbuGMA|SvjN>x}sG*'
    '{{Oye3&ip6w(gKS52SvN5@YW|#{fKg7^R8~lLn`+p2b=)o%;Ri~K#9A&s%$-YUb>-3m<SV{nobfV@yOha_qAl*Qa-rKqKAAW7468'
    'S5++z+C3f_13q5^=jJ1u7g-'
    'IM7?W<_qXnHrb$YCb8_6O=gn0{%CbATj#j*W(CVPLXPh6=3wY%e=y!iXgalL7WLWL|?*X0aqyHzEL{JW;RalsT<B0-'
    '~a<jJ|n)G#)}?RQkld?6IJ)rwLIKt^-Dlk&Rh=HCl+49X3bJF1-'
    ')oshjW#%URk+hEFJ9MPOyKYr?tkf)Dh4*7Ly>svGrM_XhnK?tD6_MR8LGrluYVF!VbEZvVP7|7E^1PNWY0Dq*GrGsTEzJ$2ioN#q'
    'zaTSu+LomC_$sQ=y%HjJT7jX5!-E?6qstNy+W_!$6+9FbPR;?$wQzf`E-'
    '`gf~<JZft1e+A&OU=TuI7py0xZwA)riNOm8&0=4#zEiGkRTgzmpbtbdK4oTR~f(@{(4J~z6Z(~dgx_9cTPIfypTC8PGn$vbQsnrc'
    'LwKcrT?V`{VRJ%PWSZ-'
    '2GSKxjaTTk>(OsLfys7qhw^&@&5atxT@&)kio({^2xDNT+jVMX!y6i6K&`y8d(3O;qK_MAd^BtrA}+o`Xv{0jYT%zV|)mSoVvRES'
    'b<VorlE+DQyb`H7Nn;d>P$NvZ|GhR>A(vio&&tU0*DGw@NCJv+}9Ib>cw_m)cEjuc?sOagBEq6E*LY`s8JAvo(_LpCluAkee8tgF'
    '7c**u#9syt)|#qSHHVsvvxkX3YJhl?U3-'
    'Y;y5MGeL=mOGN%`%n;HUCyh5RT+q^YsOjhHrzP1^4^gAi|C<R2e;^nba=RNPW7f4#!hFpSa=elr~-'
    '=K;^O1QjWasNgvO41*bX_u06B&Kp6&2iJAYEN6g78#vYc8a?G~GuD#<Z}IK{$*M<G*eaT1eEaL8!^aOd1C7>k?OoxEZUXPgKh2`^'
    'diHtAh;28m({V7MV7q-LKv*sU1LElNYuK&)LV^3?HZ+~QtJxDzq{+lm-'
    '=;<cn<!}PJ|w0<B?Z75X)^}Bs{sU=BV?s)qDc04`f#8S4jTF-'
    '*`qmn7ElSl0{1}E1nB1)ltucl>PsGDADt2b?jrNM^mr^s89YY({_a*A&XPhq4I-{~Y;XrV!^2YCH9l4`t8WS*-'
    'f&SK)iTFUo!5N*>i+YWgQdOx7;rc0O@cABc4oW5f?qwQV4Q&v~$IBnWX@vLbN>aekGjK)#DPH;G*-'
    'ji!&(T|B(rg#U;(*PNtVk(%Q8=-8%?p^)uFov-=Kod@ehlIX?@eI}ji!0&Mh+&blnrtlLv6lT1Z`VXTI-'
    'b3NR?B&a`FArQQR2%U0GHK5JJb7URkgg0IW$talD#59*;s<2=uDsLZc{(<S_M?^!6saC1+^V*mR(`D6R_G5ly(ZjeBhTiESdh~fm'
    '^0p%8B1!Rua~{UWSym(p%6=CK*EN4qUY2V+h0R?I?jq+-'
    'sd6t{RVvOCw^Ou(L^YPwD7lnP^u<XA_TfdeGe))?cpSK5aK?3ao`XT;ax(xoPi&=I_l43+b<brR$a}R&@jp2EKOqYSv&>QKop`gw'
    '4p%P&aL%A11j@LB6(VqU|!*p@02$3)<uaaH~Nj8w$6l9cR)nSq#^*%AV~MTwFK2T+|ZmeD&4{R;AgPVi<|NoA!wqHcfh6o%q6ZFT'
    ';B<7#UOP#2pAc6-|Jy0>SICB+}kO<%elrYBhc}NeHZGRYKM067|;OPB!3%-$q$zy-OnBi;cOSLtBP$N9knUy$It@_2fKZa&~`d$5'
    ')1EFuqr8;xO<mQ~C0O`2dxmE&60o&vnI#$l5jPcjfOg<hhm;p$b_0S2O;7ZQK1V?-jf2J%s-cgC=cmP5-LV#2Iu-'
    'o5s(L>m&w~PU_ZfjLo)F5REhiR8@1eI`1=kwFY3J8w_*_bZd8LX=kI~44ylB!TSCB^s}GQHL`dYg>^ydMvX}3j1O8G?-5!_t&+-'
    '7*RBJDyp6AgAgnf@w>HfEG$#x=kpgyEbTR9M&6|bknu#`7Hs5KlCKa&m!a9i2lA+;7tyySvfH@VxK-bHBF_QUnTfpFs7V~L2b~iw'
    '^vzIM901sk^;a1S3^3|elx69UypUpXY>H5NIV)&`N#&vm)sYcI@oBmMmq?<1H8{|Ufg3eW#OC|CbQ%Oo-'
    '{P=P20(K_Gh`IE|e=(1`_{ciEQ>+UBuw=8`kbrBmk1i1Xiq%uVB0@fOm%<qF5nP7#rI9(y8RZ=J3E1C1euUC}(IqP}W`E%i$+Fki'
    'bI3Wox}0B7I?uByL)k$fu+(R~ncdIczBSEW%!<j|x288pEn>>C_1OZ)TvNpF7+_{@It)ig0Cg_iF`M0|5Dj)o*zD^W0e;OFWFo~g'
    'gt8FjB9$@DV4SG_3<JU&)$mnCafS7=t2w~(u}}fZIkbVBF&2=dlv47#HY{d4>n34HbVM;}QV!V)E7LE8aZ>i*E>1Xp2Bk(eQ;r?F'
    'Bkt5!&@VIycKG?SyuiG<Hq-CyH`8&EUzv5jf^ce|Q@ES}CbPMz43#r8UramBr)$1gn2(*UER{AJ$NCAlS035G^W6B6=7~*%{N*zZ'
    'r;`hBl~S0maolDjgd?|5B8qqFB*6x3R(WcYsUAcpiX_7}H#ztBl72F3NiwUwtc=HIG%e4TIRxla8@x|3&;!kI)uyDzKOVk18ofMu'
    '_VkD|8gp@->D-'
    'o%(N$uqO9cPq`1jXGuaFypn=R*f+&A}b^5txFUM?&7yE2D#HW3fZHd#(kD|h_z^|RyO4xf)?i)YXsWSqy`;HKVosfvNn{S0(YB`W'
    'qK8X>o5!K}XjUc9Ff>H>S;JQ5{v$hyG3%@!;QglUn5`?4stFf)H<j>-'
    '6P^uAcl6G@c6&W;SBxyi1I9Gr}R#JMDFkU{xxhbO;1w0{6yIxj!KX)MfshC+to9@>_mSb?n}IwBrgl?K9`g6aIa3wHi&YIs-'
    '3LT)H*RZa?Vn8R<tJ_{q^5#}QO8>4c~zlNQx*Xtp_?C>KFXH0av3zs)uUrDxerlp(-oyk7<8`-'
    '8@Zgr+ZJOPGfHuH@{l6NKCNRT_8DAS}Emq`5<bF+j!+uAEk#s|;WKxZ(-2=6wYaNIp~p8+lAVR>3;sFR^GoJv6L-'
    'KPBzl+=6AW<(AP@jk_bYMGewV6ua1E<zlVA#xXw8cP~7C(>p&7QHH_7)qscGKYm(19VZCmA7U44%}(AoKL3!G-'
    'nfe6J@lK*vt%!m;ffu3sG&ppTqpreMQ-'
    'e6)m=&aho%n3gv9SRcrEXKUrk%(}(x_sXL@GlQ$KuN#t#D*Qk)4LzS3({~MoL9R)eV9^7!smlb*MAxb<r7Mf<N;?LkdI0N2^M2Q7'
    '%b}DU~!V^cF88K8?(;UIV@GKd|)Dv@K&J^$^6Lb|cKg@TOV|aV9&X*J0+ycWESMVCZ{_K#hNbcm*4%10k#JOQNK{-'
    'V{mzlZ+(5jxC3ZAHHWUaj*a;FX%6$c{QbQDD?nGW8aLh+t&l1o^1yIFrc{PpPMZ!WvEFPuD0kK<yzu=05B)i#DE0(Xnm7SqS_yV_'
    '1uC-Up;n7LzG`AOGYs|(<QuI2=vfQ;8AV&WPW$XrgeSbXq+70hi@kggVHwaf0QT!y_%={On|)01B7ZLRzwzZM2)Ooo6w{CWw_sJO'
    'w(`MP3=-Yk2z!bD1Cg-f2D-MIUpn%nj;i4w9AMs#_cofVfkG_rK!4cyOQ7@nxDx3~nk&<?wPH&MBO5<QAbq)&CfuFHsU?LB_nT-M'
    'X4y>I@M=-'
    '*iYF{2HtSCX4h4>wu7fB$}>2WI*S_cORtWI060NZx8*T7Prz)$5bPzy5f10tc=mU%WVae*9bb?Ah~QgGYZoK7Q^VwROs8Wf==^G$'
    'Vu0EBFw;Wl~G;%D7PYEKDgH6inSTj<JkO`NjP9`*2+5jK0f3Z697Au7q7{%epWiQx#B?s61IjP|@M9uzoKZL2@tK`6JV&lsi&0NT'
    'mV<Tlki5RWl7eNEjS(;eOM1psPF*_i;Lf_x?A%zC@Z5NK}dYJBB|BcDQou@+UD6A(!iE;rGi7tTp!((2imFbkbCeTnA43V8?vPtT'
    '=+YEp#Iz>>B(N0Z_Khp*-'
    '{hwCSuz$T>s_rw>BejM7}LENJ>JCK{XW+0TiEasnX+!1$GTqQitSvoO8#xHtTJZx|xvS+Qznp~({BPvlrjFDQeGPE2>sV@HDo{N('
    '@`K!_W?dVPFyBvTHv@>%vR<k*A`Q;XlO*Ots=Im5)tl^maSb$4U>DjZX)++JerLAjcbkixcwcB}mut2;=2O}r|R8^29%<3IY*XMX'
    'fn<@PsDPGCj?UOc^lBj@9m9dgGFiqbJ{sNU8CNCZSAcDYtm#NiQoAHO_$J$ich^HC}fhu$?mp8WpX(_cofULL=eh1=WhAfb%exPe'
    '&Lq-dW|TFF$YDA$iroF|OJDoi+>L>{A}n$Wmpe|^P#xLkkwu}k&WPjNKiV}{6$+7^tFe<$(AD3|f3l!ynl`HX|C*5--L>xa$+r{+'
    'OucZ?JBi6ksrr!azXoR`IP!T?=1Qww~-csXChZba}8-'
    'Dm`L<`TAGGaZDPX%pgb<Q>T4b{8V8Z;hdkUY=rMY14D*tk(+ZKTwN|Au|t{Pqw@=1>%Cm-'
    'N$YWN5iS%3ag$X=Yndz0M#z(#JE?bb4%qj!4x-q-qQN4#Bmcm+#hnCe@z+%R92eZbAgJ3P<t3C^s?-'
    'v=oYXRq)8Ae4K$jJ=b%+G&0WlLw9t?$!z_~7TK~Sj0;GHpUCp$e!_80jnUXXYD=;B>_}b~x@N`D5G<^B;!s;xg<`G$;p1=EHQod5'
    'OETsW-IWlQtz_~=-P*&H_xB&Jlpv%)@7^axLnvn=Kqvu|NR`C`Sck7dE-w)T&d7G_F)!MLe$ctys8viA>z%;+1#I-'
    'Kn_5e!Cj4nXbRN_~zi_cThYEFeapt`4f5NUxpE6mN|V`7#x1h*sl$!o(ltbwo;>w;v1uZdxB$u+2NgB#Md!#B&8EuliHt|`8Dwrq'
    ';@Om%JX%{H_#k~M8fT~s^585LTq&nB49CT3a6^Bc_QWEK2$y00OESt(6Pp<1%yaucbHb&dZ7GO0P@1d$1Jn;O&I5gPSWQXGNQpVW'
    'fZ^I!k7&vngttWyrxogXF-Pih+xs^hvgm|xstC=x1rTe48Adft&F)TyRpaxk*yAa>44g83;^k=>nSNvy}|OZgAo#%YyLc93hh;gG'
    'jGxGQmd?I6pUbEXr%3RIHPMxdW<ds8a7*mt1OyNjdF^XcL;AM|_s-'
    '^AW|++xD3IP@$F^BP*8C9mFsK_PYseA%^KN`w`ym%FG!2r&)Zju3iWRv>J518C^2aQW*qsQptBloMd4I6n?on0|)H!a6KM=Jk=;C'
    'RuCi!~SNbmF-uGK|S%*vQ?)Wm~+PYx*|)BHR{;QnN|>bP#5qYyZYNBXs1&&MrhT{{eJWSAwkg6r~kSe3*;wzohR|Ri41i2cHE2D?'
    ')@#dWRy!nsA)X#uytxxNmJ6=2)w1j?5<YR5UPf)E(JQ~q6t+>ttKVD)7VG`($bh5;#%9M`_qa3v>iyK`a=UlN14225jJvI(0+t{)'
    'Te7`5%_T|WT<mVR)=oNuQ)Tk+K1d>TWIU~Lrpmg%UF~04sJvX6$QX64>FO5!hNpFdpB7ZBc1zBR^OwHcVV0_XV9QP5`QHHDeQm?w'
    'L?3#{cHxFlz}vA=coGLj52@`fK<Mnf);4m<;1@1FoiWp4}$oRbfi^)yX6+Rlf?rNh)n?<5i4#3ImNI-'
    'D0$Df*xl5v30?Lj5|PUy7}|y``C&*r>ZibdzA}sc()swR%j?DbeL?OC)%dcQtii3oUt#%pImhJJ;AM-'
    'B)x`(1L;TE5inG;bSZeaSk$0Lu^uu~VHw2_+_nnZ>rN<lKsQ;<B(-'
    '<fNt5Wm65f_=928#Ekk?6t6s=k?^WD_1Wm8`}&d#BeFV?VQ|KDkIkXUk%dmzxl;$*|tgkt>sI=RXu|c_R)ot?vY0qP8HOBG|I<TD'
    'loW;MZ#`Vs>Y8h#~LVRJOP(S764r<om$T?dDC=H2R(Qoh^x;Fg3k<IXTtwKN&k(k9#L<<TMC!$jgYN?zmN**Te82v;*64vyhIZ!Q'
    'W!Vop$VM#}-Vd?~~zV(Prq-nzR!QM3vqCZ>SWhNRr-QLB%Iwa40|AqOtiRF^EJ!sgE614JM*SH)7xQI|`TEdGif$cf=vJ@rjmfO|'
    '<gDJJ8|v^|u<y&S*XCj%r7~4P1{@$X?Gtum<)sDR3wF&}eQ#3Rc5_in9$Qb_DT3ENjXpnf`Vp{cVSp?ZG4d0&Dt4JM!JBXhsfaHe'
    'X&5M(rlH+v~kRCfJSXmQ==x89^sb3D=1c?zGsEI7Z6Rkz$<F4E5SDWTx|r2JJ<?97Ftan6TTHk5iB}%xO5Uw-RPZpyBjp2`jn%SS'
    'S432lc8baRN!D%o0)k)Tg{y+i4gn(+-'
    '!eZ!O{Es`Mx7O4mW@`Vtqitz02k7rfP48w|6Ne{B08877^cQ?jQd$X&gwg$2RJnIUSHYO~7-'
    'G(=ewCBo3<*M_(~#1I<BBc=a&Qw?N@9m9heMr2|_Sq$32Dd|Nh%#3UN-iD*1q7VHXmITGDBAo21P^d#5fhQYIwM#DS;4v{RK~G6|'
    '&VX`+p_T0DZoj!pED;4-'
    'Dit_xnlw@X&TjmeW|PVP#>w<Gh;DAI5bN&kv3fGF!+kPvDxtWyV81`GwHiv|X0>vD07`2^u2rj@psu9?{|fg}IW`>X<$R)KnXBUJ'
    'tXK*gjbtg=2vLtAyz||zKsaI+WN0t_7<zPj#J)PrkMLH9&Q25eBP+C(>bpfVu@x<kv!hsBPKfYwn=~l;spk=-'
    'UNW5tg>7vO2~m<(G6sJP3}l~ajsBm2DWj1@Yuqms>{=auiWFCeE@bZupw`riA72WzCMiHmjaDc{-'
    'yY>A;VgVBS+WiWCm9)8Ba7|=bn}B^+u|NWsG9~+(QjA&%%O_^tX+@>aGU1)$DN@-$3YvPkP(6-'
    '1u3rdP5DD@%7RF5Q1d;yc%VvxI>EDTYO{Jt)#f|5IeSA=<GNL<p}O%u*zf^0?MMY}ys%%J%fhF<0H*Sce7eBEOw1uel(@ie(=5!^'
    'Svf8L;R60RIvgWlSId0-j^H;q)&(&&vT9Dj^!~!i3b3L=w{T9!`Eq$9n*&RL8O7?lC}!Duwk&Y{omHXg#fp%T6SH>|&%rw4#rv-Y'
    'L5l~C0IH}~O$l^%S7CurW|akacu>R-BZ-E5`Wf7dxI;mHoz1Vc;>g^9JURBGkoD><=8INn5)(Yj<looT3T<&ZXB_D4V>Dqm-Y9)-'
    '>}~)-'
    'C=|ZBIpgbQKL9UUoCS%Hcs3H^LE7ORTBz}IZ+0!HZIourh;lYdkV<0>{k1pr*B$r<(na|zopu4|p}VOTuj7M_&2Pv+vss|_ew92~'
    'DKn<raaL%e-6BcHVRoLE(_#X0^pYLSDGnc~41f^9or4p=fJ3w5!-}AW3~joU&RSoSXj_@~W-'
    'GvdTEdth`hGGgIre*6o)=)!guri}q+YDc(Ap-'
    'u>C*ZjIh*Eg^i0W<?7O}16LY)7)7*TJ#dDi>vZD{PXwB^t*ucx==`anb<mL_b5^cg8(td(Rp<oi=4coPr#L&jhZ)^Oo0r*QOj=1I'
    'Iq2J1uk&yF2AWHP70XViwNTPy<zrfe4_WucU(9mDa3{X7_-'
    'IKt1<(=_EnAqypMx~?#Aw{)@x{0ax%|)}3MCwRPCaAh^C*L*dx>6~eVu%-'
    '!%4t*Sq<M_Vj$NlGKDjO1Jv{p}OjJi#C#DGP#1NA31nt_yA8I#+CIT{1==8DiYSaz>RDbC%*>)3)!!UV)*+&gA1n#%+d_f&Id%@&'
    '7Y`Q@J;U=A*+uK-'
    'CY|jmb4%eHzW6}w%h@{~vyDDiNdzw*DF4aCm4QpmXlLI4FkBdrLC7YF=oXmAh{){R1SWlGoTQl=StJg3~fiqcpdL+s{yO^=c+pR-'
    '_tL<!TtZBX*s(X6gNiIbb)A&Oz&*+!TvV8TtrAO%=7b$a#aGUJ}ySKen!Z9(J$}pELfNWY;g+<s)yW|bBhRd$HEYC@R3T`cD(i{Y'
    'YGu~b!H2&Bxg1e+Zp{$&V0Usn6pk^}B!W*$<HFK1P|81nj!JVd^6BC=KW^W{txFkI>c|tnAqYc}!L58W9U*ZW%B*3gsdU;D`Uiqw'
    'k1~XqzMK?H?hCBH|T_J?_z%tvwZU^3jbx6>)^`x}H-'
    'PYnrTQdOL%4+uMSzT5_(sR~{&{0HDJ^k7#)~JSHbv9gsARtqeF%bJn0UH!7%K&Yh88**sj>=;?7RwbX`<B_obiJx9XqZyfS^O{{M'
    'czbQWoHG3tDuOzDlaY}N_=%aCzCMf7sq+E%JQ@M`$D#7W5zjuZc#!^z!k-'
    '@pGh;a(D<k%r4n6A1{draANiRvl3#|UAiQlTl3D)W!`F(Fy+`TE+QC=|p2}6NzbPO3+#kNn_E!Fa$;IGfxviA7t<PVwFD0~W<MOv'
    'fQ%Q+Nht~vQuMOAZMyRnwUvl|=NQr(;cw{x=RN{)ijbN4b5)6o{v<NwgLTHjzq)UCEPr`*?ie3qav_Zn_+C{?*YL~_b%ybe-'
    '$`Xmmc$(^4R9s+9KA*{;@#62)CRw9^7>MBVnCHM6#<3$7Zi44E&Q}Ia)jNM~v#ht4EG_L11lPnqt%(h4l$-'
    'eDI<>jNHVB$nghtqI*SE68;@2l6ZDK)hu>zmTlTM5CRZ<l%oi2S+$zW@xLz^ga3uD*LSILBw0!anSAN;3blHHIJ9-=T+-'
    '9cRu<Q7bc8p$G%WKv1jRE*0O3F&pfOLJ2CMg};MjyA#Yes<`5CkTaSC@4$;;1hO`P1X*vITXwRXQ$%9%u)wWS}+8eQDsbf6`X?zc'
    ';BOmG~zxT$QWX3rk7793Cw=qU}gQm4KMlCz}1t!TX|`?OCN#UI`_HwEEe@g&`KEUYM-'
    '}1!2*nn5`cp3OYY{A>^`5}w47UabxJx|7|3^fe<H>nY~$t34XoWXGBYs5;wRhN)w)`t*qmd1!%|Ieuw9N0mE*ALWCwOGLc}fFIWW'
    'l#ZlMFjQ!})ly_-Rtyo68x81?cgF$RS?DuzL@qX?>I>LRcf{X{Jc{b}`Y+mFv>-'
    'XM(AkEub>C>!Q#AVJ|}=+C7&M9X3p2dI%_VJgpt+6o<=nWNQCC^^F&5`|j@o?V*;6#|&(@yN)e0Qi3A!P)F3E^W;q73j(X5Q&uN-'
    'Zv*YfHkD?$ElbCf+@d8zlu_fBy<K$YX)*6V({RUIsh412Y8bxfQY^uOL_F+fd~)?k%`;Mn)AiTXBZoNxA$$Ll*?K@5WJP@CFZ4qf'
    'QTqzuL{LV0UW0rYs#;D+cp`jOu#UwT9WVEbxS3|mvtl2>*Rijz?tQO#&45LD)F0Tb@d{wS;Gd`AJ|V85IPx24H>tm(<%o2w9aT4)'
    'JmtbpX}w6swNN8h*9q2AmdNTR35Cr;Fxd<K!vby{EMqNr(!PE-NPc?Jr$3fUlg;|XJRaE?}GjLUf(q?+U{e?r8`6*NY0*%$Q3AQY'
    'T`u5u2kwUV^Mdr)TgUUUmP8-'
    'fd&=6wXE$f8C0yJ1tZk&;0obMYXUuWHFlde?J4_phG~$_miY`bid^RJ3s$fql90<$r?L%EUNzv|WJ{O`7bU)Pm+QnrszUe@7{(yU'
    '5X1`2&rL6LM7+8vuaxhmcD+RQ#kpvb-$ug+9whElJLxg2od|;PH-'
    '0Y+*Kpc+i(n#kOqmSaR2wLP=0)@M%t&En4w`gMQ$;Doa?rb96?B(&D0K|*mk8)ekf7kChPf-'
    '1yX|WT;3D8vmx#&m7)GWdM>XeuODs6*(sSqS+e@F;M4%*RKASP0(?cFNZL-D^GBspU@{{p_Q_sXE(jEjmojj5ww2tkgcGS|-'
    '=g3vvW#sA(I&HovQ1DLhZ~Q@Du|Z<T4{0Y?@VmY58AUK5!F=U&Ce$UO4RZA*Mx8c-@q8s-n2rYm98-'
    ';`oovZmGh;HSccM=gNLga``O*(nBC?2Q0ETkS(*O=Sm<zApo)A{-'
    'pYpYm9sCbjMDCHw?Lb*Vay3DwQz{^|AW1wLi`{d9*)uWM>G!>JxGU+KNp<2<p1wkP&qm{SO?Q+$6ijW9E|jx$n)==Gv;@Tv`1k)i'
    '0zZ^U#wqQogL1A*c=`}C2XS81UX~pL#gexLCBAwyLrkC?()oevYLZ<R(@7VynC6rB`D_JQIB6wKp-Blz=fN~5uPe@sDss{J<O0AR'
    '{R*zZm*0E`UsBGxNIUUX)OX&Bj@0+x|2b&w=fjg1M<=gFFAh(BJ$j9>8z9t|YuRA3t-'
    'bv|Hb!@)zKQ96jVA7~YKbQNi1jCMN#IU&ya^;gL`-i}cL8f<_JYkgX8!+dZsykXmcu(kB;L#*Rs511oN<1~nA#O@C(5LY>0-'
    'y16dPhT!}yYLe<4*Bp<A149eHz3FnG3}7y?Gu7#61yLf8mK2ZJ6)WXkfIi(6zt{j!Nq14{TuWh_mm9~CJ_Rc_)S32Q<n!4xvkV|J'
    '1PiQ^|J18b0<lrg+Q_#m4rC9mW&FnNd1bP7}TlyghChf(5EH=qrvOMf<9o&XKoDRn80Hh%B&*8Q=$O}EbYDe~<EnLauyNr=2ATk-'
    '`I)AYy}ZZ~F55{k?JLg|y}62rS9fomRY4x2lP^QEWKLFC!2fTZ5m*+r3U>;|(szkLf0ynU;1Rlfu(xkeao&VRIB1{j$LX;TImI?u'
    'NnShxu{4lX>BO@kA}=JvUoy!KvBV(I{W`cIR^$;y9mYA&2PPRqp!BLeLimgumb*EXrSK5d@cM_+7i|EOe9B0ba=DWLvIS(Jcygyz'
    'hMC%=U`GoW{<BvVgX_AWq<VtXrS7;zIsD-HHLVTm9>eX##HDiTMe4EB5dxR?&EA3Xj(Dxw@I277TE()(+$_pL0TuET*g;PKjSZvw'
    'uB#Wv8de75~I(w_fku;lVKO<MQ<0CS`K1X>bB!M3*IiBn<kX{$3MZM@`$K`k$SZ=t{cB4!HuUTvfhTv4^5B06nyjJy0A)gCU~C>r'
    '4(Xp;En1IygXBw<&>Y136cyiKME-FeWIYAfg#SJGhtIBqv#GjL!UP{By}FySesd0<J98$XF+Mg2Ev(8HeL;uTzW<1AvOxSWa?R$F'
    '>_iho7Qx|EH@!UaiH`LWfHyYo%jjcmD|Rh(b@x?r;hJ5rbu({fxI@+MnyY2tEL3Bf4=1rJ$3v;Yw#T}zlBEQypF$!4RJ(t65s8f!'
    '9lFmYII_jXo|2DNjoqW4bs{2!}(7B`z4%`S>(!LKG2&-LnQL2Qyb>QDbai2yTF'
)
)).decode("utf-8"))
_V48_MODULE_ORDER = ['scripts.v21_route_memory_search', 'v19_terminal', 'scripts.v19_terminal', 'scripts.v22_market_impact', 'scripts.v22_weed_repair', 'v23.state_encoder', 'v23.simulator', 'v23.policy_library', 'v23.planner', 'v24.market_maker', 'v44.gold_floor', 'v48.fast_route_router']
for _v48_name in _V48_MODULE_ORDER:
    _v48_load(_v48_name, _V48_MODULES[_v48_name])

_V48_ROUTES = json.loads(zlib.decompress(base64.b85decode(
(
    'c-'
    'ri}U5{kfktFzE_#6+6udL+0mB<*Wpc0Fq$O+6g5(Kf`jalrD7EsSVGzR<Mw^*6+b=};|+|P+*k<yb&$;^mz&pjXR=H_Pq>x+N=w}'
    '1cn|NX!J=NJFmzx=N+{{82_|BrwB`^SHN@!i|M{`HHe)ffN$=fC~ye|-'
    'GG$AA8hpa1@U{o60U_b*@k;m7~>(|6y0_~ys2fB0hc#qm#vw;%s^_q6(#FaGrI`@<JE|M=y1|9Uul^YIt|a(MsY+b>pc7C(OZ`~B'
    '(1Z@+!_m$&af{)fN*>2Ub&mk)mW|5i7Hd-wI9fBf$H7cK++moJWozy9#)o4@_={SSZo;^}(m*#})7!Tg|f4i?|=haca)|K_KUv-'
    '!i1pXTH0<6l128|eGDUmwm7eDg6M|I@cWoF~`&xc~CY#NR&a+aC_!fBNgi=aEnO`fdJ5FP}&L`t-Ylk3uH6^Gsx-'
    '&&xqSTb$q12%gu;r%(Cxai!^v5A^bJwQ2tAhac^?M5Z^st(OmOPH*Gkz&iF{Qk>uTlJpauCKEo1{_~gd;<uw#2>9;KOZm-ip~G7-'
    'LCah0`hlKbfAexMu7W+j<<?K)L2o}g-'
    'lynd%|3hi2y1%3S?4V{mCi5q_8;s+KD>W_`1*&R{>$O}AKtxx_rHI7C8Hw)CtYJ`aovS6d_MEk8ydNJFMF$V7P7FSawvk6`FSH>{'
    'X_13HFxnNTZeu87<sV7Gaq~i82#wL<dlIkH+;x9-'
    '+%aye#rB;@DF+Z$L&e?*Tef?V*aZK{^htr$J|yObK5K^J#9Sn{qPXqEWhgc@%h%dd|~{aS^|=VME(?R7gPAxAHIKk{KMh<@BbUPF'
    '2KW`-q_VplDTuffIqIYPW%!3AL3v1*=_8HrKP0LyS)qfF1eIScbmGt!KokbI(N%~>#BF}dDl}XacI4Z&LnoS>M23c=>WRg-'
    'q+{S;>WEy?1c(q7BAUU1)HEr-'
    'Q|Ni>D}d6sv`pImaj~jbI&*6iB3dSkJ9wp>qQ`?n8FKb;Q3a$b?4k+0}<Hn6h4H<*gk!pS8*ZSv94*k4_-'
    'INE)2|0vJ01%c^5Y>7<By4nkju7*?Be#XpF0P@z>3;<to9r@BKTx#xB=yxQJ`_9Qq*rlnh<H{7arnG#q%jZH$j0*Df1OdH}E78-'
    '`rf@C6#rLhe|9Ld-k%<z~5CI+$P&uXDq0KhtpFUKjJZxcl{oqje{rzxm}4N{I}=oWXycpH5E%c`G*~O9U%dBfEVj-PDzu-'
    'D}O&vL^O%6~F!dzYdnKK9$9OS;jX{eg5DSQ#)6b<ea{IZLgZDCims*u1@$?CVh3+WzcEqO78(BU|`p8_%cZNdOG#~&KqG-'
    '+Pqz}{3xeZK%?8*UZF`vrw$c^6Lc=<&!NwF-UJ2;^zuh=6BIsYd0*|*OZX+wxW3mw?6Jq!wDXT7$KH-W;VUyI?bjPj1bx-'
    'K$o+7D{^%Y#ee;n@`F{7I7>nm#Z)W~ebntu<t~B4y^~noP;q<4Sw^XYM#A`qOg<0^$IbaEgzIm^!cX~d%&;LmB>G+Fi5=vpu`IF8'
    'uAHp^&lWM{)@mUI282FCmU(0_rcnsF)&&y@JY>`e)#7E!*EpPBr89#<UX9VRk3h*PJDAEIN;7`C@SGXX%K76wBI5J7(R0z$ALx3}'
    'qy!+XYAK5+2mAJX%lMexgHVW0L9QCN2aljiK<h~|7WHqfQRgIx!JaY+6IHbYDrtwhi5;w#^3H_*1hrm(TF%8U`AzBiS@EmN23KIg'
    '36)P<{mknGMCp7K&;lszn=^=ZTB~m3WoYSXONeVB63HMcA@8g8g^dx#PVRTTQL0I>B2$xZv*Z%pxCHSOOGr4(7>rIC7L=p?FOBwv'
    'w#VdWxMs_`XIXnyyhJTT9Z1DTr)qsohkw}7BE5N!Ml=C`cZ~=nHyuvEti_1<fmE%55;9iX?PMKuxd`!^3`Jx!@&`n0(mOKRGhR)K'
    '6-sh7ZAo4}|k!$n^Jr_dg7u67k!jHRji+E7YqL5~Tx3*QcrcD8E@YM?feJNyrIp|&`U{8+O%~P-'
    'c7o;86p~WGbz2Wyeyui5SK@br~G1v)o`SbIUi9*BW5is0dh)zy=&O8sVbIyQZ2R&l4BV~IJ<F;jCO+w>}=|HhBD4sKM!60z-'
    'brw<b*z(O<E9w%+;%`9%(mkQZno3fxJfo|>R<^{z*&z9Xot8Y5(U78dp|ng6K9-OdP-uGZ@thcRVg-z+ei5@3eOTiBtmEu5(Ej-t'
    'KOYoQ5CJlr;d4((7y>0@?VX9V6wy9}S<OQphG3ziB+6^0qD0n|1#&y#BDR4|1O-'
    'tE7VpXuqHIph*F0!+lrJQWUbamdFj^M%4&2+2d!tAqq2HqyiW6OeHzsNY&~lPo@4euAZ<7YxPM3H;fhZ@IXIl}v3FM*6*!(?-'
    '%9Gtn<7aSbbR>_$RxJcr3jVI7?4B^hK#`))<_9H`7&WvWIxfHSTfGKDK}OYTbpc;zzro};lS0dg@KN3kB%)zR&gpD{h-'
    'QL}i^Z&s2Ca}!p(vjo2r?p#D|^CTkHJhspaTR#;DbFnQ0a@oh2r47oz7&yBLdMFB`}q^Bd2~2w8k#EP7dH#n7q86k}REA3R^OSYP'
    '2LO#nvf!VH(ev=vZ845%gWMh~@y#x9QD_bjNWim%_sW3JQXH%{IN}gY&QS$yBX9C!gSPI!8P!@ok@mnzwctb_0JA{?JYd_Nnv>1w'
    '&)9az544ECE$X^ml@UL}Ui=hpqZv+;AW$1c3|97dnTlPkuR1m;Wat6;;BuS&=rYB4JxckLdMY$EXOrw`n^hg7l;J^Phb4?vF6Qtg'
    'S=*C1@J-#XL@8r&>J*%Cr`|Eo-yJ)}(k8MTRuUD*b*h>wv%w3n0I!U<#avXS4Zbs!^GY_ySZ90jqt0bG6ei#}IMCKB|P|&X<Bikw'
    '&VW76-~=g{PrIA!=bZ_G##on6yH<O@__L@<!K-LsWU@e{GGDg-VsK=|c<pAq0%=w-'
    '}c!O(g)ua9bY2Vt&@8P7vOGEt8*ha#{Ps&0_ssf$YLkAuo06%YFJCw}V9!oIUAUgl;*=(;Yws(G3ZHkIbXhTCv3*5nV<sV@A=3%4'
    'ri`Ym)f_JAlAivl5)%4)<TZm>!LawwlV=)$76yT;?vOOu`ykLs%t2WGi>J`wGFl^KmQO)@kPH!O1E(K%Iy_WedcL)=Bkp&OA8rMh'
    'LsW6rG=f=$IyLQ7osA<Mo)Wb}JC89R?zS&5-Hz`LG5v03BrHTw|ELL4Kq(E4HtVGlBU-'
    '(|lQU2fn+HLuxD_`GRwJd0%m0bm6liO1cA{`!iN@NBhWNL^U+ZbI>sq*&vhju;aC0vU}O<$+u1^LQqL!%!Z=&mR!|j&e`DQ+F|{T'
    '^fn4=UyLb$U`P7M0}(_Fb6}JZw*p%8;2^U4EU&k67En9YG=e0eIX#b(9cbte0qBI9Hj{%&Z|VAN&ALxaWV%MJ9Bw=?wkF*B5D5nb'
    'S;f{I7xe&7fMeI2oiD{E_!}7wUfIz|`!6h!3Zq$1o>-dVxLs6aVzt0gmxw^-2!rIckf1W&vrkE|=;|UU$@w$F(cA)nJfgtIm-PLI'
    'A71{Jc!Xm2(T<L<1d<qjM9(sEMypA7IS7TzbE_{;0X)(5V~1#DR)*qCz#S{K2@{FPRawcep-'
    '87{KBk;T>*>H77*|nIfxj7h@s=a`wDubTcPBUuDor7N?nqy4<()X&qT1;eqJx*WsJBBjBfa|LshfjmW#x%(Huc-'
    '$)PhrTnJ<KMlI!R?m5U#i_KKH+Ge*Rvr~{hb(;#22eYKV1uN5M;joKGnD-'
    '(<X{0OcgjyHDhIz?EH14EC(`*c}y2qqy2G`C*Ty4zLFo{66heA|O3_5os}8pXpaa=~Bkg;dx-'
    'DOyZC)FOkGCKs$t9fXK6!D|sgPy2$RLy>U6n4(Y=YHXAxvKeal3Bv%B4Cp+Gw`h;+O9K7~PKPmEE-'
    'QUmX4a%_1po%j>hp&Thpa5$HP~`?jHOD-_i<W0x|YODgjcd_4Yi}{1h=$_L5h@j+&I#zVvg%L)b8~dNpACj&p;ADpADDT-PJixW!'
    'Ox|70oU`_83Ls*L>6t;03hC8Vw+vp;OhC^$;qk{24EE)?sfZftpxUuJzZhb5^)@b#^<Yebk4e0uD2s9?Edo&Y~1CoNSGFdR-zWv_'
    'n|>2%E2T?p4*oRZEICRw-'
    '`VvC^>aBOo_T9V!M8#C#OO+ZIa$#5JBYdkN_nAIIbp;CGzG<uj0o;>8H^6!3z3nocbFV{J1EzSe36E<SGT1v-1Th-'
    '_{L(hYqJ`_pRS@l|OVCeJb)E*|CP96enW-bB&p=Xcb6y-'
    '1MJ1DGGk@sLVSc=`ilEFbPRk`h68x<kaud(V$(iyf@GPOtH8#H^9LjFJiMU*5g{GoX+N=U6zM^@+EV;i|l`oe{-'
    '}kMkWzNcyG1>z`)_{3~`K-I0JoOV3*7*bqgSO7kFzdxl<jssjUzjP``q({#i3h83N;LK-T@bkqk%O30?`%a~WoD0_lew-'
    '`Ykgl0p5SREK(FwLZPG}hMQvP@=K;`l3%kH;(!w)gQce}PhU=;AP2BpT!d@B8C#<=M?l$^qLQb(pQ8VX4;U%wq1LID17d0EJ1dlB'
    'hpaua3`npKLq|cbe7%LY085vBt_{r;urb;<br9dI;lW$v&m3MD!c;9*Le>CAs`Tz6EA5MFqNZ#yika)j8KZS^Q)k;82=TGC*4v<('
    '{)E(Jtik6FCgN*q~F)0i9#={f?y7QrP3+_0sA|GLbticCI=&gm8F7HPC<AcpB<#DuQ(rn4*VHHQu_4D-'
    'giEGiIbJUn^>RO$)|LeAAYWLP@r#UE-u~@})Q};iZCPKhZ7d?%TmSO~6S&&eLxn#`kM+-p1q!c!NM~$HQv3(S(QM8-'
    '6L1l$M0{KJDx=EB;fGN8a5a^ziZOy{&N)wnse_Ag#(Y)y-'
    '7(3uuy0Q*bSaPgNbrOj%5#w_LKBw*@SmGGt=ME85>UJFUt|DupAPdR=5~x>SG@1#+1L?u*{f4Wn&WIJg<D1?1%U&bXEly<S)GXuF'
    '604t2@!oDoq3Q{$>Ixo!)0V{n04HfY{IKH$NK=(JYF5AtN?`j8U6xP8J`jh*3Z<Zw^~?Rb;(qKhfar4Gy*eVt%X4*MtB<_{%VQ$B'
    '?#-vxs;8Bdg0VM{;~3gY=6QSvlqol%t}SGtJEOMDT)#0}h#Io;**^OLH>`sp+2W|*j=DtZ_a%*2Cf2BDan1-'
    'Z4+sBQYDM>!Uh#z;4*15Y(b0k+gC>gFINyOxF~Z+BoIs>+TW!P`1DsoMb&dFj=FD|udaDqoJE75!QH2qVP;o!{CDxHWOpbg%?8tt'
    'InW9M9HXj_}AdZ0#ONq<zDseRz(z1x3wD)5f)U%`%}U2>>1Q?HjU|&1x0|3^D?g>#r-'
    'E7lnSY)c1KhH%2Uz?jgp7x~cP`yCtRz)XjU0V@CK<o%D$Ri>YOo?qt@uCGQ9ca~?E@KCY3|Pv%^J0EJ-MD3^tCyOGOyYANZD2C}q'
    '`jIRy0#w{aM%BuoNrdUH%_MgkY0H{{R4$sTSxQxM}U$h`%&x%3D40a@2V-22-{bV>TTuZQctF&tAD>vlARjN-'
    'yN*iv4Qs&@{IGLf*dQ^#tCvU@K3D^A!z!K*N8MIWtJ_nocO!kB*DAkB#2w1Munnl%ArS^-Tl-ha_&JWoL5l^DfAiAq1KQO+D$m%6'
    '+Q9M2Xd3@&r`aP>|K!9bd5v#2UY7t}8Rd91*KS`FlLkt3IwMz^#khnVwa#WcUW#mU;Ch-)y{_FiXZ77zqVSq==C}Uo-'
    '20e(emCF&ci^-33hU`!o{-P)MQee+Zi<ArmWP*3poN7MsDfmPO1HHL@xN<J*`y{ZyjDy~;zNL-'
    'veHo6F2Pat=meMl<x%_n)w4UH23N>)+*&=GypqP`7EqG6*Ges-gBj%{=!gf(yf}+>J^ZLDozB)@@Or3SLdf5HkHOThONWk=G&zmG'
    'W9UdZB9G=6AvMP*-NpZzYx#-'
    'YxIuw{0)zU;n{J6CsjY(5Qn39R3z4L4aPeEvhr??GWc{NHV!NRLpX*$z&HKvG^mwe;Gz(HeCF$PEuGRg-'
    '69(iHdMg!ikKoHldiG!m$ql`3B$G*Drm%{*;>Q?$Iqci;56GkDrI8`0gszeHGidp5b%QW+4x@5ghX~!W)6dH=%o()z|x&4QOFdlK'
    'x(Z8^W&b8;5Dt_Twc+jr4A}MAy8gIz%S{c)EFr}VRxAa<4VI5oLfvV5mc^Tum!K#;aWTFt$-'
    '(Z8*x~486Mc?xq2xVjC+f$W`rGPA>CS~s^&2keVElJgg@fet9RaB>Vn3HH4CD#)3fqHIGaUHx(@J|~J4RHhW6w+ea3C>8h1iIFnn'
    '1x_0cyZ@3X)S9|2aL_hB(XeAqyk8z&KTKi;ej4eE5c<1B%X>DwT*%j3>!Mr!eC9<4nNlEe5b%a3Kq`81P@~hQOgH<FrxH~21E-'
    '$V5A<a!5|FQi}V}We#^#7ldDEiD2ksV`mXlfp|PS_Ey$X1IYH?`Q<l2aiLHenT9(PV97gGqjjt=}2V3L0z9kl)HNecrKi?MH$kv~'
    '88`&Thl;f<quCfV`Y!YvH49BTCg72}15z#t*4e0VzRhWG;GMMh6L+Ip#T>++mY)yg4+em)YeqE(YYeB9NDG3SMeF1{<Z3)Y2V-'
    'Z<8sdV<>q*p7cdQD@^Nw#sWqis-OlAe^xg+VRw)nL(3=zsK-pJz#%!Zpk^A<X5`?+39H%t#8sJs1FZ;KDLjG<T6dIC~OJT_5IhWu'
    'uuj?mX$ANRG4=S=e%R6q<`A@7O#<b;uw}#O!*Q!j{|pw`<cW@#>)MU8mIzW<8_KjM^!ap2K+BK(UdErxll&C@^IJ6GmQ}w$XD9t5'
    'qH2o2L@N#%AG~cT~cuYH8}&oEv$fk^?FuffaPu$TRgBZ$#!-`zSd4X@dhbrS*Xp+l8zcGxJK1sJe1G-'
    'InV82;nsP*)F(R=6{0??6G;6fKuLGMXtKNu5~l|SHumj@rl@tWtoVX3Pct%=yalP!yKfa_GK6B_^pwTay=nQOX><5ZKwX1jl`^sZ'
    'W$A@@(e4P<&LdmwDExQu5(mI@~2Ghg1FIOvH1FWS%#xZW+r<y@~;{BF94znhD})u)6&rsKUzt`;`%t-'
    'TmAcetjH%>i*~q@x_Ofh1=jEt>!`QrR2$b=-'
    ';cFlbSs9p+zKXPWysbux@ie!Ri(h1i@wM6!_&e@BSewe!Nf+`PkggV5Rbej8F=rTY$&K74r(z<lZ})*T5{=mI}I?A$u*R-'
    'N3gqG+r%hAaB}VI5@+(ddAog0qm#0N<cSAAHc@t)B;_@>(dr5u<1Gl;wH=ZdzTGP<w2lWmQ0-'
    'X9V@X*;5kvxpUAv+m(R|?Nbay|%rSe>H&Ffjq$(NqXp#8cOEJDH8Qr}XoTb~4ki$$?&M8(rhS>z&eF|mg(txDY&d0NbpZxvD1&WQ'
    'v)CJZd_Mj)w*3FND2*o5;lDsi$yexuYW11|C{>Rrg`F6h@rHorR9mfh_(74u@3Lajx$Cy|7sUw~$DhLV1sfgsKzRT&{YYXAp-Qo3'
    'xC)|*PMt|VCVuegUL8cx7bD(fh_SfInOTd=C0X1GitEw6RZte^V6!uSOvbn4)>0||V0n2n<H!g|}1=g^%MqS`AzFIXpwBIB;$0x#'
    'Ut4GAr(jB;}V$=;fppS;jC^1%mA?O+%b&lbe_U$N|K+)Xh_;Pb1Lq|!o?sV~g81u(1ft1q&oLlsSF=VzU%wZTlSxOiyO{wa^YP1O'
    '>UCbjmP8uOI61#wv38%nv0*3o)mIIU!oG{f!&9;`_nlLprsk#0~|a(@g}2(Zy|7EX_-K=s)6HkF8%S-'
    'oBqwfth@_SlxxW~d_zOiZ&mzh&LrK2g`1Hewtdc~^jvWl0CAmQ!GhD`zL$84#gho%zPkA(y41x=02px`eg{-'
    'WkN@d8=d&h=A93o&`~NGGFIs-zs=dC2v;0G~Lw6<8WNjQQ@xI!C3_t-'
    's`x2O<`^&_mjJ>+m}qqLM}#ObgfW?LHKoRvdB~s8qo!4Pk&L@x=}|IhU|sH`oWQ)snrf!ySQR$t&8S{<CW=A<43+~Lz`rCp>ISn$'
    'w^J7JkN3^>{xc+ihT#jgfNL3aY5*7PZjzzlE)@azs4@&w?s;80#)M|)`z#BZoM4bP;%?Yw7aP%2nsF=7h#FUzEOgCGz6NA!Z2*)l'
    '`eG$L#JJuA9~>Ijl9aHsMWD~8kT)z`m&yXhN0POBzszPBnr#Wseq?-'
    'hHK@zOBCg!NhQBxOI|OuknCH3`K}8a75LM#^ra0c8~|)V(EiPMVk5|2$T~62I2zg!5-0=F5AQ#GTd?u&rfML2XHgMf$+~TO3pS-'
    '6<I&i`1s%u{<>)3|ue4pN*tT-3A@0pPH`T&t*;!r6al8{8+hy}(9pwfkUxp%rN(hsLJ1*I?V2Lke+)FnR-'
    'K+&+`As5o5=9d=F;l#$ib%Jk?6w_U^K1p2w<<Uj;@r57UDmt*r*4_!5ZDJNV|``aE#rwMoEo-jJanVIYD|etLuEYSG<Z*S35iIJi'
    '@{t`CcUSH*=t>6wdy+eu;uXHBgDCcEK8E4tMejI09Q7p(0w-yQ&SZ&h)N3!B}%9qlU_muRF`w^-'
    'hwq~v$1?5X5<gZ;_x*WuOaGZT^>1{#m*MFjyYM4HYwFq!!4z;iOe;Sdot;8RaHSh)9cu$p@A#KC#<oUoH0H=t)Ou(8n~s!4UD%TQ'
    '_gq#!6;zE_-F|sE8PSlPt{s(^~|;Gv;?2YH~O?PKQIq<;swEGq@9kq=9y=Ki8VRLB@f&D9pALcnqN%M)e{lQfml}u-'
    'TzoJ>UyauRRrG)j3we|;gvjR$#Ojy;GgGZ*6jM)Nlq7Iu)%vj_!i#aYnYY%{73RE+3A-'
    'Il<%oz8GV6KD?h@#=Fr#18(nCSHardfDM#jZTkcFWM(T8x97`W&nIwFP7<d_({qB9B$3q1J^O#gKtQw`v87nNd{RN9*si)#3grvf'
    'MiI?@SB6g;GfJlT|!0nnmqC!jANPA*ak&Gg^iZ)0aNfH_WYA5&CFBh$^i=24duB1H{n<91F2oXTcUi*D?mUT*Gnu&52%@EwtkrT@'
    'gG35<GSuH)uFmTUN^>(WKQo!ZNz9OJpvbz#-DvO0~lxo|uVaj%rOZl;d-0_i7n70DQk9pgoxHrZVdD^GzH_d~bj-Wmj6P7`pFb2('
    '<8L7v4+!Z78UHRwJCB+#30_`xTS2O`pIs#!<LkLW+BYHYx*>RmOMtuQzkHc>|x>5)xg~ieYv((ArW8|7_gY7La&sQ-k;FE-'
    '$o%t6oDT!kpF42XR5t511V!TmY&}eJm0;bFHKaidm@BG_z+66bJ#+uP4`Ao|FDtWVSUPq_vSS1{=)`*xkZn}t#5b~nbccGV(?czH'
    '6G-{YglHX;m#e$>cIr8SIlqDz1UmasbRdx)_*&cymhSg#iipoqp=xUrDSI`LaCtmb2@|-'
    'd72nH+}HAX8~1Z?u9F2AqxWI8u85Le5HUoS(advS^+cEH4tFtmc`7$t?ap7tFaEqO4XpJ@WT>`f_tO@l<pwqyl6H@k_3X*VA4u%?'
    '$>_*Y%F=HY3aiwJK0xH!~)FeqH(hK~T;GGNBK3K!stsJ$`S_|bM4b{}q<AfU^urZ==B+GaAdb?W(&vuyg-kab44XFuq){g+x@7jv'
    'M24qkJqDiwG(_xkonP4=$CrQoAuH~ZKJ84kb*dh{^kqwSdv5HJ#^uwZ5Zp$&p#U~MzUL@IN3v|KOcuxSUpp;iaaJg}NM8!JL)6y@'
    'VJHxp#r=DYunWV>Gjf{R($9lQFplZJ<oGm_J~OnzE*5gtaXuQdZ^|7Zty9$&;&M<%^~ZOsVheI#0+4Fdot@h<m^HI%LEn#(G>rNk'
    's!GVi>>sO$3*2Rc`r!B%N>M=1!>OaIzipCHqGG?rjk<K@^a&$x|X7{}}*@zcaaZ-'
    '%JZ<gHOi>k3Q9(D}NLZ6vjlm(ZbpCtk!_coDpl$U2lu)G14R-'
    '=d(JJ*71qmUaWPhDMJS<y)!cVpgUIiENK@Vd0d(V@e3k?}_pqK^Tc#){xZl0eC8CIg8XUVGfYtzpQalj|@_6WK*BVucR1>uW`54h'
    'jyT2@y1K)YD364;Fp}8`#k7}ls=$|A(+9XB5a@8%cOIJQD3cNj)vcy?;BGCl=l#UB<9cSqxP|X&F|2R5Q!`6YIU*jb+$8zNe;xit'
    '2HQIl>K6JVePf$@4civx78hqnC5gEA~1aRUT2Dro8!NJJCE0gV)POGeKE{_9eAtscvpDq*`t1w$Xe}-'
    'SeJ7F&K1UDf=!lIR{G(FxMB}Zidiki(F8tG>nSXtHGRzKbZfmVFKtFiUBeYQr1mCDl3adi7(DV7UwEOdbM;F=cg&HbpR0Q$UEv5R'
    '<my@Ye{}JMp>{l2)fb5YCBabpgIt+qCPR-R@Sp@-aQn-_tgAQIV~EZ1!{i7_tODEg%3fHL#40mvGr4LQ+fZOWw6uApPiJVGF~sib'
    'X*?*yU!Y#rch25Q9GhwvXLv0gnY)q`@C;cqZ|;@w<dG4fu0E%%X|-'
    '#cbS9dcvkYLJasZsbcml9ByMF4)t0C(460<J6O4FNIqTv<3ch?N`=-|fjPGPAAXyP-'
    '@o5wrpvDHYt$|$6(nSN0RlIQGnwKjZ<vOY$}h+lXmvZu{>K95PF{3azcREr=!bZR-'
    '(@J>};YKt;mZAXk|U4_}T(Ce2;cDbcSvRqn*mq%$#X}1`A7gcwAM+b?_gQ5ZUK`#(MXat}wcYHQqxp4+OKh@rNes(s7A5{eDqDO*'
    'Bfs7ncTC@QD9?qhPsZ{>hYyKmHKN=m}|B?JyJ)cS5k*_<AJ?3MZ5joMu)iVk|+!gW_MNiwajaO}~=Nj~K#TR}^acz<GsZI|)H`j>'
    'A=kn<A8R7>x>k6EJDFH0W`RdNEte2051|5>yu+4;R1IrcF>TO#VdosJG`yR01WD}vj#YY^rcJA1~vUWWpm(4-'
    '3`9&*{Q^)#DsS{4ub4uq!w&KPdUrl17V~bvWb=d=r*tk+gpJfloa<9_)B@9|!i=hUWQBs{iEdHn^phqlNO(_z~5-xwo<2b)-'
    'qZ(o!YMfy)Pml97{MyE-%ng(s3(`}*+MxBw^X5!X?}m-D_-'
    'k1*ux(daizLuLW6d4Qtx{5Z2MKb~*pX#gEP*t8CkY?D^Pn4}>_g00X|5E(k@#+FDTbqVx9Uq@^c+>a0H)j;TVc%?ol}|r19)kKA8'
    'qw4XUE0y&@@G*Qjc+-0Y?)_smcfF*_E0Km3c391QM-TPicf84F1F{1i$o9Xa)Tz1C=pQwZxr#iF=A4f;R@l3&%L5#cpcKnoO_4S{'
    'yUfhg@#KroCOJ=HGbZvC}fmp^Y?-BFzPcNMz4_)op+90Nhu$T@`2-'
    '6~Uo%o*<M{oLK!*zky9umdqSqR%cQr7fh02DdF<qs?IA7eFRj{MK@!8qb4}ll-ZFwYB$@qc#s^<p#LgxqfMDG>cA=$&G=C`(SMaW'
    '5(v%`RW9NtA9dl;!nSG=4h6qyK+<ocF)&6HRK)AUkl!?8{DH%Pb>ScD>$qb8lSHI&UgM!=9u_rTUIZMnpJZgV6n=ZKKGZLhsmQ<;'
    'H)O|wM|KK*s+0{-l8-)^-mWg6i>-@$$qdob38&s2O03#GlD4gQw=!7Qg}<nSin?RgMiZ@R&$$!$n#ZAIemKSVlq2&y-'
    'Xfe6!!})R-'
    'J?xbTtBtQn<fvBL7U*cEPja=yST?InEAK@1^uq*GA9?sYg6vzf$NaT9K}6{2ifK=usR~+Lt7*Sht9WiX?{ZBma29XNIng{GjPDX-'
    '28JWXf&)`InyA7&wR$L%wb$#MAkR!NkWU)VF^3>BpKOBA!rs9HgF734d(OftTx_jYRXeGwzgk5Q_!U;PBPK!S@IalSWRaO_;Sw|)'
    '#ih(M4zsDa|v6K0*JJ-'
    '1;TkaiU^he!#y;MZ()L&Zi&Waucl<YOy*6U703In8F8kIq=0T~Dr^UzlTrUj`;glcSjuX)dI`3=ooOmd+kVi8_vkzQ7f9PTw8R6t'
    'LPqar(vU?f5dK|fyU4BV!)(>xlAFTU_%Q%$*pqm9@#UWUIgPA$<84g(cUdcNH{fGUdaR!j;5qvI+LYV%ikSxUpa4&E{%=Yeve>>_'
    '-AFT!cko+hQ8x6mFAYh+oFf<eXXP)`1rnQpHwH#f;If{+=+V#;M)TIv9e$YsG^JDi0jKmd`pwRf*0UB;CaF2Pev_2%<755j&wu~h'
    'Pyhb&fBf=fY(}HQ>v!LO_~ys2e~^ISRkQC4UF;3+0p6c}{Px>-'
    'e|h_9I{tJxe8)sV&%eNKsX`6V|DbdZ7T@rPAK$(I=BJOd`NNMn6~P$j3-|x|ftL>KpUA<_liTGf#ooY|&l_V`)Kuj=k3uH6^Gsx-'
    'ha~8;9*xrUcFgA-6RqC##<!(=VA%9F9!~r6l;$^W2PzWdm)wz(n&mRBElRF8UdnHF3u($shzpi#Q_ai4xC-'
    '`((uE?4+eCHavpL75MR5hEQr*BxB~7i7fs?K=G>^FSnaopfXyoQ)@&TQ8S|Y($JDHO%mVvoT`+157Zul5^u*5STe29SWIs=na2F~'
    '2@Au-4FK?5hNGQ@&p-_KUj*U|UGLwsW-'
    '??j(NTAYdmL@IxIeOXsiNYiM7OmG`b_Y3&rI_tzAvHv0CZDW2|T1xu7+q;nOl1pi3N0H}j<Zd}|UG?rg?|SMa4y||5nZ!<3JtYV_'
    '9Y9yx`}$m3{J1rTy->lXyH>CXn$%H;n8H<GM+Dd{Uzs%Lo^QYtortO)rRlfVi$F>-'
    'g%{Gm^R060&bh+|BCy>ld<c)Refm7F;zGD%UDJbR%(HXs!och#yKrflcX8u_G22&LGd0}RmQ#0&SFzO=T|gx6eE$xwF(O4$yXShU'
    'B@A6<5*L+lV9_DayLJnMA@?q=viB}b|LM#Nb5XT6F3d?cjYoO7(>=OP@6pdS9JtrTd@k;O{o!cc$>(o=`GZm-'
    '!!Ktj*)cnvo(S>|nsy)OwEXwRW8vX<xu{!nwXBIj25mKi{!|wGWf?n-?1&&C=M-'
    'oH_|;Uqw|~qPnh8hhcLi99EuaJpOtkTg*84keghgrdc1>yt)QxUydxa(yojO#EXNZt-_ZbT^v!_3To1pMH%lm3?wrZ}|OtHMzv6&'
    '><4<lIkkZ9MYlKMBH^;PqR_u~ZmqkAO#%||K$0o{jU^qzaYnfXuA0s2WC(|kLHW}soy+NFE$0-'
    'cBfK>7=?bt*<ijyxYlO0bP$EeP=6v(lyo(kEc_r67s<UQSblZMj~J<3Nt2M``_%K}RvGnKddlfj*6cG>C)N44`6LmZI9?mKUdI!P'
    'OQ|xFDN8e6sR5GO)?98)xkMBXcK;jc+%3wj>#7;`2Auli4zzp$D9<f*$iT6RtlfLEC$>NmkQpSk=g?XM{xsK6@@lzBzN(>7%53OF'
    '#TRYPB?D8)D9sRbzTGnkVq>N*#`CM>CXQRB;9wd90=T1mTyaC(#z8?uI1;_QZ?bpBJC3(|_Zd0=)Qg^On||3=)c*7u8={q|+u=D|'
    '|E<J~TVn&rfW<uc~%sQ%e!TD<3nFZ@wsK5?M(B>s-'
    'Z~jA48+*+JeRH+7|5W4RI@{UXbB5{g)1>yU}y0C*A#TF&WX)PPR*#406U6k&QP4?W$l$8xF8@RNbgZ{A3;cuMYY^Sp3tGtE5YB?5'
    'C9Z=-'
    'zyq>xa$xd1BN?#`_Oy2Djkj^me2#~amjyzzWxw&@R#OqV8UDJ!K{9?;%^6M&aR>fq5WuXId#hq{G9OamanA`o|5^u>LMB~PfK4oV'
    '`0S)pgK)DBsabtjLmk0>2pVKsQ`Ko})<8u-'
    'aVkYAh@MSCTb`N>>dR+)XlIQKq>>pNjnJmYKwj?P;ljoZtMm}+Kq9@Xmh9+GZym%gqI)Xxld=&7h^aPc!(h7~>fYZTB&!GT_!L8k'
    'cNMR$7kn4C#&>DXW^zQk(lTI>FH3N7O0!`|c(rbmek1V{qY>@)BP{T{u)U}*i2(^$WJD%q7dzBYw|w+UdOD{nZaBz~qSCCmR~?K{'
    '+MR0t<J&*&PbSDum_J<Q1_{coL1Y5u#jVRk6|sq%nf8!S&YyF)plr5I=x*J-'
    'E(j#J=;6)3C6!+ejZ8k3|UaqWoe`y>(Si{7AZJ0eul4X(2|A`}i*V25IgyeYz3quI*Paj4>R-'
    '=RozJ@QzMUD=bUIMInT52|~LP|7?M6un5<LVum|`o1mm)q2AiMyYYrFQZE2n+e`7HFOn5i_iiY>AIlbgFmc;uMb)unLG6YtkecY*'
    'zIb}!yNFG+`ZJ?FWtJu^VPRsyz%NAkA5w*umI$FfR29-'
    '$6F475uGR*gs$O|i<dwik(FXpHF;>IsX$FvFdgF);n6avGy)j9w(s)MkEB_20iu;dN`S3AE?LB4DsQ<Vj}=E`LMwQD8h7x%!4(m0'
    'q`5R0Sqgw-'
    '=yXRG!5%lqQDLIB9<VzHH3~0OqeKYQIeIJkQ7o}z8Xn7ymeJ#kSTTl(sl=VPDZ>|og1&w76j0jmy(vBXhG_;X>}4IEO|Xu8G-'
    'TyrfEgg`WU}Jp4a@KtQuu6AuU<5LGJBlugk-LhWTwnlOEdN^X1q^l&?G(ES;(5UId07+2@2=tfIK+x+22jdY6Mho1N}XcbQj&HsS'
    '&<MCMHD{D7g^efP1!+Hc|_#BlSFVoTPdPAqcMG!k3lf=!Qc&ieCIM3}oTFnt<Q4&a+o$i@zKg$W~0AQhE7Nhi~B$SYSNl9;u#9(<'
    'SWbDsee^{gvC&OKWXR>)lR@p{!qWD8RBjFInx}dMK|*8#cg4Zk^m?3ZVL{lhSF$r-'
    'SkqLo4WFZGsfw(^aa#&iY9tJ~A=9C=;!c{e+S1WV>FY79{s|=0?CiH4q_Bp~+1x&P(3GesOTO$8S^1@aQG*4q%cElWA{(auQ{4rO'
    ';ll#CwTkB9|*|McHEDuQMWw>tsF8xLsYn-^x5is7GNhKp_$3e_-5%JU5VFkLdDEOt69AwOx~Q3U$}N7Mea-'
    '?8Yc=FZ+0%Ss{Lv!Y@1QaJS2hD_9R5DSlU5r)l$3L)e>Q%ii}}|C-T+Er4)m*0P_>APuo>jq_h-nI1IpfOILDz1yV~$KKZ|1>z0d'
    '*;1Ub#0ZBd1qRL^>P%RNP^F@7u-@!)Mk%fYV~erFq(xR~TVmuQJ5;16F-'
    '~ebrEjv*M4o>rS*TZcfO>1F^iPrs5axDRes=ccjVdKF6uXuViBuFZ{}8zsf2^87DUzBgU~yb@OKm9a-j-*2dCh8z4~~l7oX?-'
    'I6&GEhGA0=dM(7)I#u7$(AVhlx<Y+C67J(+n3l`L@bFu#cg?P{^NV}oVUl>#G)U35sMrT5NsiQKa5g@m>#CUF8gnqeNV13-'
    'q!ohr($G3mI+}WtnHZ$pMnn_ccK~Q83>9yM>_Dm%9yc~*2FSPSw4b7y;MRApW63j2lmVzvlv@#Rkcmj|v4^lRtA2oWJ@MtlMWg`Y'
    'n*j#W!vJCAGbMfC=ZbP+X1XY@Ox%O_$3DtExsRN&|LRzL&*}-'
    '}}C<*9b0Sud?Y>u7@BPke13WdE;h7xG^$RP$*Rv+BJI#xK`^<>c1GX}nq8j&oe@i&;CowaB-'
    'E+%>^vzIpJe4|!Xd)qZkzu=5BLa^4Bo{{WU%GO{Y`Ub3fnbAZXq(fkp-GaBBjEqASv3MPmGmtMaNo34uR__t1f*ZtOrYw0Emb2D-'
    '*x?Dj)4)fKTCQ2V8!`>QZq+tdXWMC&JCpT%D#^Zk|K}IIk;RH$71z!~A>{-'
    'x8zT_;fuosDqB;XOx2>rh7O`g9ew{h+YgR%95a?}p6w0ZyoeRB>N}gC2ZZ>-'
    '?4>G2%44MeGTm~DO8=$aBrlGSs*>a#}IYrqDav*it(>$Y_RFX70TFUw^!^wXtPqK2&^DOTMQiOz^D>vP%dqpNEoWs*66ezlwu7Ep'
    'LLBHK%@%L~5q!^DXkbVhKNxFM&tu}PvH}$g%d!lJO0GIQce`yRPg#s~hM>MFGJ0a!&sA>>fu&z%YsnkLaVJ5SvDploN!bo*e$0j&'
    '1q^arl$gT@I|E00?ZN>LBDaZZY8L!9%z^TdY)0Bzb4D;)Br400;TE%oM9BDby^CN<jv26z4yzppN_2wP<yuRm^VmOO*h_w&OcoiF'
    '@@!qsjVBAXMUc+P5+XSPw3ci0jTVS*`m=y(jK}TF+L^;}V$7+HC<4ejK?iJWP$eBiwC|y83HRloDw6}nAB3$3$o!|$Y9tVAfoL5#'
    'aC^c%y?7xxgtf@of6Q|ja$eG&-'
    'QhmQw%k>Z?9kCo_uL93Ew>BWaelr@+DLoHRvth7`)>IszXS51m?;FE5GrIdR9S$&Cx(Bi1O~&onQtYKtJB{PKp$iz(JtGQ@^)-'
    ';I*U6l0%1?zMX=H1ZGPmBVuNnnYz)3jbq7j}q;Q5gn&8cla;k{4h{1pkcFg4d*52CEO)wNE7phj)JkgCJ~vLk;(_QbZF&F`djMbC'
    'HAYqBKtH;>6%2V&OTZ%^f1W8<@ARbo_n8*F&7%a~EKMBaH3jMiIjpQbQ-'
    'kOK`ClfmgFHfVJ0<LNatJy6rFJ4d;mR;T!yOKl=$3Z}@eJ760d2QR!+V0FbE0nr};P6{PL9*xxZRO$&`P-n~Zm9XyI_-Zyf^41Ff'
    'AX=`A^^(v#ix)y%BBHmK9&72=9J0np69h)UpmH(@KM{3#wZwI7wZ`u^-'
    'f$kd*=nP#m)GJ}1(%9V`@r<)+hsDh8v>m8mCJ?pj}Si12(7%JkIxVyP1YNwD$p`ISE6i)5Y-'
    'j%L7|YA7PxrWyoQFzd%31_S~g8qgS@`N7%hg9Vb+*640TnheB7ZyarGr=c@rR~Zu=4(r2o<*b>BSSrmrd*86EH~#s37iz*(>FDp`'
    'K8h)$my&@oeWYs=vc9%oR*V=Feqjg<A5Vco2E3HN&|V2t&;)pZ<$Rr6*b<_tNQGp+xacl8~VFxYE~ajCe8r)q<C60mOy26`eJAYH'
    'D%CZz!$c{)W*N#*kx4&X;XW+MFLws?yZuVycOj0vv(A!2t4BuwspCcGOa`%Pl`EY_OgM{8W<ZnAxy^io8u%PuXO$B+%>mEj#?Oek'
    ')8ln-'
    'L1&NdlmxB1vhf?=4f5apC0fn~ZTs^#0wsLmdTE;!g>`ZZM=6yPOCp<9}CL!6_B474o*^3aRt<eet)y!%WDLFG_q&O9pJx{%%!hY1'
    'Dw+2yfZ8!~zig+r`hBiK(zCL};+6Ts0SU09Ye25w{wsh%hK_Fw{_0cg1az22(brO-'
    '8yu?JxLE)BfNOUS2w1RL3<HE#L*fDaPe?)|tVLJJy1--72U-'
    '1fZ1op)cOEd;4s>1$hF)A#I(|Ey4xPS?8)0rcAc9ug$vG1(s1zyG`xHwjcS)-3PZZnZFnehYmS37IJJ<FwUV7G<@`x<jwMN82q-'
    '9Z@C+S7O;pnKr@<66-6F%aNDik9U9uD8mU%iVRUYE=J052_+#YY{viH$(#$DfTl)NGcG?{dP`reu@N1L46o?z1|~-'
    '65!o3uF;lmqV1`cfM03t;F$-'
    'p8?nBMCrZ($5h@OW|v6v>my=H6MD!_5SDoW(!q8B*FW4etDoVc3|hLj75BW8;Ig}HMy1K3_uJEWFwUB|w=r-'
    'D>}6oIqam4T@j=?|cZD`}W!zTbcfLOS#H0@MO)+nW3V#73BsK~!u=QX4<>XX+K8QzB>W2cp4{7W(hPr%TJ(nCL>i@!_i^>&>*{0J'
    'mUQ=piW!lvg?X-PWQRn&nBoWlo32h>kh!##dC#i8^_lHXz6VrlC+L-7*TTGHBp6ApU4hU|jbi<FtK_Nz?;mC-tWbQsu8COPkwY5B'
    'zUATY-=oXQEBgaVxIH3`f9_#Srn{vp6*hilVlr)aEu%!=3^B+@wYRynkR+FwjzJ%-%84t0-'
    'SN>aY=oQC7*NMgNI(|B6vGKRdxG0B63GEu<c5MW+gD8MJsm3SVH-rW68?sjA6&HBuRfK3ICV)F`W<7VDF>F_J`&Bi4Ces4UzTQ6H'
    '76kT0Q1QflBtr6&`yq_$e-pP$-'
    'V&^&@N6%Ba+1QeVAQXmJ8oQN~H4G6L5{zi*O2wgsy0ds*mPo@J#(M7@Y%|AxnUC4SEm_u27A#aQz`{zxly=Qm@@lD%x#4ZSiiO?F'
    'Fl2!-}$-Iu&_KA<nijrX|3H>f2`f*f9S-'
    'GUocsB;XAz=`$Nk)SsMfU$DX=b1|52UL7u6f<p4WFY2BaFf^Y(<L)Y2$J{+MtOhX`ZlL0xVIQ3Sx&&3*O}|gV)C1Jk~SP2<Y%`gL'
    'q!62l18)wMmG>XxAxenjm`KhddYstmpL8h$C~P4owwn4)pt(Aw%QLsO&mr*LIbx?JA8lp5nZ00NFiFbR!ARbw&MU&q9xJq1zH@#)'
    'XPEKoNqVP81@MXFW9~=*p#{SgIJ)Y?v|!p70^{4ziWKrd(F+K)bi#Ni}M<!UUj1Ymq#d8iW&c%0&FYva3j>hvFryp;55+;6R0<Bb'
    'aL`K12`t(#8|5Apl<j1*n`4q{u%F(?{6j1n?zSfF=&w^40jvk(jb~MYstJ6hQi26p@6r!57(87-'
    'E|*sm<V3FA@`(__Dy{O3oL{bWs0Nlg^vYHAwbqSW88*r=>%j9g2jYp@<@*^>0$@>@vHxreBraZA(vN!JP@LS&9#x)yv85ak=WuUP'
    'gpd+%-'
    'T5N7ky~LL3KzCaQeeU8oCve9|W{${#9=oGCqlJlG#$4;hUPE3>oW2z5_0sg%j>6U=<m0X>T34dLKHa#(y+@@jac_uf7@hmZe!K{|'
    'Rk9TkD&fu?K5D|I;@!`+o2EArF2x+HLG#j;3%dn=h8geFm5*70`+e#h)VxwZ+%^xR^;VFtp<PHLM{eUp}>6xYlrPF99Gh!CIbL{z'
    'jgjJyrPyJQTHn)DIZe8<OAG|R}%afonI!)IYP;6ntCos<{9)jAvN-t><<n0&@AA2$b(?en3{e1#bxku<rUWiEAcIy%0>(-'
    'P5$hdVfTsQ&dFmr#rK-liT({+u`R6pquT#fRmcDA~Ictv+Cr3!bquw|H2rF<y`ct3s#<C=ZazmFmW<T5j;5-4a-'
    ';2qwQ)y&}dS!0?OenOxDM-~F+-m@g;k;r)kiElYxgvXtkp&Xmgl1Qs{F?%x439$z4Z7Z=lCo6)tP&R_5*z)I6Ls(js;8e-'
    't?v87;4LZ8MXD}_6TLxcE*;7u$G)rK?oz)!4Q%LOuK*`G3*BKXBT(5K<~6txHt2vs~nxD>NZkkijW?wiVZX_u|n<LZ_U*Ty9zr4d'
    'Y<5e7&gUR9xwo<b}HA@uCQ4vseo%df_F09X<iGfhTxO*j<skrrB#HH?sCO4k{xC2*r7lw-yA$yMN7r{)YjWf3s5awA!>T7;)EBdX'
    'dvjGrr%Az8>p8qI1U{BN)KXWy`7-KwLcD6=6V#jgT81T~qh5<A^S-%jlMH6<;F)UPnr0`#__-'
    '%~8(rderS0<jObl&ZhNVFYv;)Vk2eOkNvNNue$FIG2^;(L5;O#H~j6Bx^ujKkiu(Io#bJ1gy9!zqo*UwFGIfUOkng=>b`^Yegz<#'
    '_2Q7j_0d=fXOL2tWaA17@a+r)?`LAbz{=mEcPp-'
    '?I>(bBD2c85i^b?C3n?vyVJ&u5hXCq>pwDi8Zq7Qw=L~;K9nWb*PA35+_y1YFSX~8QQ0WwG0orF)obrL<nksNG#;^$T7rWUh)=4-'
    'ABcQ3l6+utiqaT{n|O^9oD-Dvh}n)_T9Q=(JPX;2W|NPZW;3bJC=B|W>)<f8G#L3|Tuo!s(An5lG0Mf(U$JEU3cP}H8e7boc$}oE'
    'VW)6~X1%^bhUp6R>Vg=o^K@vgW=UVr*eVyn7|Y99ajDQYueykbv@q2$)GFk~(V5EstinvnpT4R|&kul;VZ9yVcx6s@h{=F*nG&$v'
    'V0d>7OHAlKkU6`BsVOCNh?J8w7b7J=v-'
    'zrHd13}w#Oe6d_||JiYPw}au)|j*aEvxbrAsJBLh7py@y9`?ZU{$7n^&byq9i@WVWOl#za&qheM-qQ87Uj9Y;bc@F7h<oss&?EO6'
    'Ve2Ux!{qC<_JYaj<uBkjUxvH>u3Jz_;M<3kc6jM{rvE?~*J?FAGoB>HKz`kbmpe8+oQJO*xD%5t{#X^Yb^3^Tt)>+-'
    'Ygpd|AlO6M+Rz^yfB~_1dACvpXUem#(H4_Ox!ur);Yx_1@}cplni@jGigsjXAD}|Iut;(r*Fr!6M&JES_fS7JjK-IlZ9Q^67t@Zi'
    'Yg<BD{Ie(nIz^+{fS3B243XWe<9fnm>!5IQpQl3Fy0V4@^$gVrr2$=|pLPB{0+EmJF0SLun5q>)n&lqw=DZpv?Mth8P7hr8XOmOd'
    'k6nC&*vTQf5{q!;E!3L-'
    '~W&^JEFqXi?*R?Ebbq=FBXDs){c9xDQVQ(nn8M86pBVghgYW4@@aY=cJoJXWiGD?c{nvAS4A!!GAPe6K;F-'
    'S4q>uN+L)Dv<`JR2(?V+C(*P(f<8NBgRoGSsnz+6iAD=Y>_+vj)8c$8LlmN_l^yG%22ar)9Kt(>E}1O~Rk0x2nu>#X{zah05xEyQ'
    ';;>#!3IF-MP&R}|ja7w{VkckG2B6!<hNxGuxd+ceNZZeK0Jm8dEuoNmQ!Io9m(`asC8=YJd7Z=qwuS1DiwLL(z+PUbs?%gM3@|Mu'
    '0mCH>40`vrcLa=l#u*@7_<_r=kvCnCM6fYErT{7$?7I>rL+ub8A7aQ0Nz+I13$3MMh`Lmjic8x5jC)?ettM>>oUB=TidOsFjGaMp'
    'cqXby(W)W-2ikTDg!kk!k0ahSg>B$@6qec}qJ!N{xahdl-'
    '#Dc_D1Rk*R7a~z+HfLUBbp`f#LyG(F?t8Ww5Y;?(0%qB<<3m@e(XypZnyI?N_z3dF)ibhq3POXS4A9sOm5YKNjApT&|OG&91|-'
    'zuSU+$0Ea|;G|CqWx#83AO{w5mQkUHNa*M7wE;xOWh@@s*eB3tQe|XN{JHZ&}inbU@RmOq`|5SAia_Nb+FKgq-f6b-'
    'vvNS^JF;nEdl}@M<R@Ye|ugNe1^;97;{6!Q4f4N3qww01YoaKW7zLrM%T#ylb8s~gNlbolnav4?YB90kHk5#NFE=Pw7)k;Tm?h`R'
    'hIlY9rgbM&5l3F8N%~^`MSmncxzwy=61r4V1G$Qmkhrf<fh(upMc*~~|x$c+8J2-qu&V|cO2-'
    'DdHnQgd$;Sw?(E@kJ&fnkZff#X<M+fu_@l)4!wMHOIk^fx2j?O-'
    '%K_yF62BVw3KXA@(LdcOJyy_)@Fnu1^SoYvcpwccCsrt=d3;HZs7G#<{MLCM`BeuLzPbI$AUDxjwjyh!7&XDuA^Yz6~n(3fu(%=|'
    'rtZ~)U`Kw1vBph7{2VP|wyaHav%vjD&4Q51fE-WkU_DZzs|OpN&}tn=XEA&<(%b2Dn3L0Lu+>8-'
    'H?JkX<Vn*lrYioPI~>X~Jg0aWf;Cp@DfH@F|ZuvE(4HCXF3(3@b6G!D9OdUb~k+Yl`GM6YRN;;#jk?vrep_WW~;w?<wpL`fJ77{l'
    'kBXgg)g_z<8=x<TkdZ39g+ttdT7i74MvwzP`)R#O#7Mq5W~(I2_IpAHS5X&?9nlAEQi)zf((wiDa{$=yIoEO(;q1UOu3cM+AVWhC'
    '_>&k06gW1^B4`>yWS*;uih6k}!Ro}z)HFllsDh-yyscBImi2~j?00Fk^RYa&UcIqYTzwl7TwNb>fq8^yD2V1On%o}sd*`MSnvF0?'
    'S40di=DLDxdcEa{4*FeeeIQ|Zv9f3FS^KFOk>|La@OC9V(ahe)`{8YXrHREBBhaOs||&||$Fj?*Pv$4HY_F|TbxuspbtfLlEuwT}'
    'S!htn^3v`o5YM9KHT7IHdDGlr%VBdv&GzW27bHP|hn7AHm|YGM-'
    '`j)=wtJ)K5d0_>8o_9JmOu%I|}n=O=NgeV6WR&1k5%5%=~c=xlCU`4lw9dCa3TVAD_Uj&ZZ$4e?H2YSehLbMB-Qi8C^;p`OVNny8'
    'H^!hEDR6%Zy?JI)|+wa4y(nW(>Kv1VF@id@~6?50P1rxfNH7yvJ{fg;^Y!WBDA_ijsHrg#%)=3|=KS`ay5)haHZV;1W0XbB#1iK<'
    '&%2@(J3UPQ`I9`|XPQdfuJh+aW{ISV6)=9E^4_LtGv$iA<tbBjXllzyWEMp^7Pcko?uQs2vM+)N?2*&!Uq;zkFiYcl7)gGf6(5bw'
    'lY<qCmhXmIGT5*-c>2rNw%8F5`^>{BSeU5E^`?S0ZsOyE+86SB9J34c;?^@Y+d+42p36|XwuGhWB%TpdPGH-=UUJn&HTH-bF8jHb'
    '|9byoe(HDD%sihgb35M|@%M_>vTIt)zeA@%UofLXzm^&+_B;&GAO|xHx{HruB%jF(qq;~&JW3IrMK$^u8t{j~t0n29KQUuZhxq1S'
    'DS)3&{KHA^l1ivgwG~y^h=>Nmbz@JB(rQ4BF{ya7`+L3?I;%$truetH3e*euILuBIm*}nStY#+b(muLIw-+%s(U%r|>X>1P;&Wt-'
    'LPVi#)_y!aB_opAf{r25o-hO(HKOGL=fdcj!x;g&>J968dDC~pMIaqwdAAWrI{+pjZ&gKt4%7P{v=!-'
    'bb^8+t+Yd#T$o+q~p;YGUP%jb>tve$}hokt-'
    'P+<7K4(L;>yOnR_1y(uTOHq8}3Z!*2{Z5d5eWO^G9N6ex+70M0?6+!d`+&bb0%r(il?;9`WH@k&&r(w9Sm+EiL%fYw`_DP$XVvO0'
    'uJ>#=^2b@QoD_ERO>%DG`44ib0p)nDQ&u*T2LnAk@Vg1kyD@w(@crqu_Wdn1U5^{?NZul5^umGBD{17nu(SbF1MDasne&wgkPTCW'
    'k)Z#I>Rma>`>EojBhllva$X7`lK>VIs0z!I#%qiS1rtmg3^po+W+(RlCMZZ9F{u}GWAF=--'
    '<1UkaSXxT@yxY5w?~+StripuA+3IXL%EGJ++q<4Ri9_pMbSANrRZj_mP6yD{_P#!s7C&yyVJ}p$ODPp>f+lsL)ZV=6>xclm<;Ogh'
    '<EhzzCpr;TJxbGWuNQ%oVhS&$f#+N0)}3>Q4MbqOQ}_@bWBc@ZUd4rQ$GWEFK6u?6d!iC;=h8Co;>HC-SXaX{H7sh9OBWQc;*{t!'
    'Xn}L5`*(Pa5nr^fe?tYmX6Wit1gsklEZD%kYnKfsJ%Cs44MVQ#tf^W(i&Ge%b;mAxsHdlcJukXRH|+K^4F~RZF`tXOUw=4Sck=n0'
    'U;dz!$neXVtI2;Z_cUp~Y$k%0tI-p6o`i?r<)UuQ)v_iAxo_1B`cql#mu2k8vmk;*$9~SQrrO=Zg_cDwNt!{YwI0Y8Pyz-fc#Na<'
    '{>~d=QQEv+(=leG(QR$7(4?YMhl;@oIv4ck&}S@k8K3?LZi2$+_<Ap<$!ovSE6K69BT)Ft%t`z81`|PFH7{~M9H2kCM^4{-'
    'q*A`$eJIA_x!0SS{}dfOU+8Ka#*}A_zKkI~nOaRCUi;}U%z`hdONMi=*Sm_97)a0%y`F?p*mM3QYU5RzR1<a~eD@ZEg7&57188=r'
    'lhGF}2kQ%?rkD@;^zN-kOd35g{IY_-'
    '2i(A)u=WCj3$p9OCo7L5lLS+R(5yHFI3vlspZ)lxdm<~(Pkizrz;K4(VY<V5RL;b=wJTwG&){~<xz3BBj$^`VZrC&)sxgJ@V@Igd'
    '6;~Ma+p0Sv!dEy%g|QTrOX_BDRh-bY=Ps!S+2Kah{zcE#6zk}<Z0sk5(exyGFky6UiM&o!ZlcwZFCQKA@0+*ui&7NEcp`~~)};)7'
    'Y%q^WMt0loCx(XsLbFl##o!sfzg^S1h6J-#fOR#fUbANIq=X|&7GGR;a;Y5mX#)3ZRKP4-'
    'F?T*DXy1HMjCSZIlO4k)NYn9i_dlQX0Ff^$>JeLK#dCdxet!*kDEzp~!ieYBEM{pocx$)Gc$xy-'
    ';5!xs`claLa?rg>z@8klo2Op?Z&k!U{(grSXvyOnR_wz9w<t6$=mmQ1h3Mp@=gjl)j6TG0pnzb9nQ$+*o^0=7+%{n<x}<R(Ec2C~'
    '6%CbyeVs*=JhptZ){43WviMujfOJo&v8H_8bpA)pB}Ub6IP_k>w5^gCb;9;5&g49_RB#9Dy*yP04O#*EX|CuX@$4Bw_0Pxn`P8~G'
    'z4q3VPe~Z-Bx4=4=i-vx<IR}>m*7-hB{J)^Qc)tSr-'
    'P<q8`wlp5S3tott=tR=G1)6gGNXBLel7E+oS=bWl`_Iy$!iH6_Usd4d4irzcEoOfR-ySAsu}03!cSZrwj2h2bV81;_Z03Tcp*M|9'
    'cXZC%cu#&*0MNNFIf)S_rTTqWMEaSl1s#sL^)W{Gdb<qlVT)$K@xC6POcpXSMrpu%qnUTlLh)l!d)j|Cw|PL^Km*T-'
    '4`zz%he`^YlQF5oyDexR7@(cpg2n4Rvtw=s=|}1{aEh_jWpy0gnhoW0b&D;*Om9InWxr<T^QkUt#j{dP-'
    ')w5=vpYb!3w=edV0dD0pES&zR^KF}DD#fz)%VBF)D`YMBWZB$aaM3AU#IdTLqeb?-'
    'IjgMX#Zv1)Ba`2=sKQ^#%3lUh&LF2io%FTx+%nZmwefx_H_fQ>rk!@J)J@)VIUz#q0;J&9X)URF?PM9aV4=ENwAzqB4RF|LfE6?O'
    '6($gAk$xDH(rra$0S$k<luX8z{gA7R`%*MSn5tJEqv6&f~`@G-'
    '!rwKiwfn>BVU#iJ+^r$MrL7;rbFuru`7?FmD1dY(=4*N!iR$%rpNwH8<ofEDo~!Z`u?5FsUvnZmQrWB!{3#UN^^1Wq}48am9P7L;'
    'S3hCa7R3zz#Q+zE%?Xom4+@EtD+l|fz8hZd|vh$Gu?k=aJ(-yT#NOG8*1Kb0CpcvH4ae%8rl-'
    '4d7L%v)0PWvP&tI`vgR{YKm=eu~TNNtY;eCqka?5cd+w8#jr6k5<RU7F$QeC9`Q#XBmacF=lk_Cj%$ke5D<TV6AxyP7}y#p1>x>g'
    'J~zKjA4h`f0YG!j5(Cq7K|8YHl@U9n;H4Q;YcP_VNMBttge03dgybsKom&*H=hrV2Pc3CaTM4sz@3;A=vdGnN9pla?M5F~84NT5o'
    'BvV~h$CHNAo0%_x5ns5*L$nVDz>AI4S|_Qb9z}<2fkZ7ssJEOI&$02IGlV%E0eIr+J5e<SjipgLw6B&&@jwF2RRh98Bni|C%MVRW'
    '$&U=|B1(kO4(v=5(Tm(iJ45WwSEe{hxFnIN?fdpkFdXD>xg}n@Y_4Ca<rVmfnwe}S-{$~KaNof5FcO%6Z%6|ZA}jxy-Dl$DeL|)A'
    '>abFu_ro2ugSQ7A+`)koNdWjSG$OdR4g{H)N-'
    'ibQwC|49A&hr!BT!ut!_hf!R?}q5g~R*sUf0&`u+b}ph+1T*{3v8biok#;QSfkOl@H$UQPYv2>K{oHnD$aM+sLVEDTtohZH$w)g-'
    '&+`ph$@ck2m6hOQqwej>9{Fb^bPP3Sc7I%<i?;;O8LHxJaIRYa5*cb*QsftiqxYKWm5i#P4ar?uY*xG2G4P-'
    '(01vpD){EAPbF7S*P(5DL7!MZF!Oo#)jbPu(0mcPdYGv;W<ecNX-'
    'E%X}f=kX%RCnOFR<wA;EAk})bPMFP<Do(B1H?W?U6f2|O)ZPdQtYLj3L;74!`aY@V0U8g9&abW0CcuOlw@4zGkiR0EwT6g=B*)#F'
    'efp2^8#D4e7=BWTEn`ao>3#l}IQVy7Ss710TO)glYHwY19TG!%Cp7sTWbz*Ivkt(6A(%2|Vye!l*6NUjM88BZGcg`LymIV9}Fb-'
    'q5TvqzB%*;L8&GHOB)#ncx4p~{g@2=&I7>j_E8sjucbWMGkjIAW18p1%;32v$Tf)pw5S#iWk#T>g*79}m9J9Bzm`o7QM5vZSyqS$'
    'TAIedluo0lXWLrIn0lI+2X8msU*Y*9L(-_>ZU;B1$wjH}mF14TCDt<Rd-'
    '&1`XkJZtHiXGK<5!M4NMN3AR>5HZv2q0EPEB+3)RN!W;6)+Lfc8-k^kuzyMCWL1?}wWMfol46V<E3M!@GIG-'
    'wp<)BUZAYQKZC*6M5aY?Tm#DTjZ9FVE69B*CEMA|1P!#V$kiUQz+*3<pNg?YzQLwhw32<?9V=vIzyG3eqqm6DzT-cvh7mTm>%CLH'
    't`EXe#Hy7zCj_^K&MyI@^lj{Y3j3dCDHjal>)WPfQFVc2ay<BMP>7wp*^M#cspC8?n7qAPqQNTLBrI=-smsGNS{mZ-ee+K*#;nfP'
    'Kvp(@w@?7oUdFW4kobNb7(ux$8^*jUKU$MF8j)WCjs@B57hTgzbS_sMCGqk%?O&DNsv?sKltsC$ND^hb!GE}_jH1>~_oK2sVF?W<'
    'vwgs<-'
    'F={yo*@gnNI$*%inn@jAtkuM2rOYy+@mC%nk6BP`@8e;<1Eu!R#X%l?kj&tHfBdaH>zPSWV7sFZzco}N)!Lj{{5=$BugD#s@TpZo'
    '^@r-'
    '!{TWY`jYr{8qwpL<ZHjXjE0vwXrwx|ZCi3VZkCR36lwc82Ol<W}5q(H<`Gb55%wUQZbmxpWb)zbEE+?}1$p8>BGNWXGw&KV=XIG+'
    'N$XO?H9*B<Lc~XPvO)q-'
    '@dULUlOfH9!EL=iR53iSnPZDh0X*F`yAR?5#BM5^2%f=Hqcc)@MbD3E;cLgz+cO;F}@@u8=y1jk!65q5%oKQ~gX@)r2UfoVvINSU'
    'E5aqnMAc0}W_B3B7@jK7fCz|#!FL{Pyxa5y%;j`LpG(Vznh+h#U6)GW)PaB6!;=q(#lQ&NY!Fs%UZ%d_wG}4Y^HU;x3nlWc`_ytg'
    'kupk!Hwq4gu_*5-|Oqj)Nd+REDMSYPJ08%E#x}pt_li#WwC~x`by2{%0l>kQ!<VXqJxB+yc<T9*okizFX;9Ai0dbz}-'
    '%~~+4(d|HuEj%+r6w}m5Fic9@0`3^zVAdU)H<FK-Fy=cgb~*etAA+Jcw@(~vvOJO+JyFczs0!NhCYgp+6{_-'
    '{jD<ztG8n7FHcHNehmsO0pIMX`gTa~%tKwls=bsQC&;N*8r7=m3GAN)$2K-j`I)EvgAk&<*B-'
    'Woxv&2N1Q_&)kKq(%2Gl<aKoJBq|vmIt+P%<RldJZ~8j@{Ej+xBCBTMQL-i;!Aij(*T5S=Tx&7y_$OD@Ucaopo)WCUs{-'
    '&U`gyOXi_neJ4c+o%q_~w3cg$UOog(t!4RHfX~)dQFHb7b~LUN(i-'
    'AYM?4?ff&)XPA>>*xXPLZ{9Dt7b_U+gq)|&y2$(8s)$l=!&j*No8s3hU1sk=UoPCqFyq;9Ie=wgUT0d>_LW1bP#R3{1I|6+>OC2W'
    'DUdC5~-'
    'qL~Lb7qiQn&5H>D3`}R`vOI1#Xc;`M9sk4#AtDiVT#YS$j@+L7IT}gBCS!RZ6uqj+&n0LWZW{vro8@R{fgm@DmqXD>h|K{8Br}Mz'
    ')KhVlh@^9o|D<N$C*4uZG=y0dF_pZ41j$}?or-'
    'Ld)8*t|M$1+uexI8By2$`owEU=p7U<U}W$Qg`bw`Q9QH`jEVCOm^Srk!KO3xpUHw7WsACeOyUPJ*vbf-slp@Q_|tBE9G(q+X13y{'
    '5AR@(nS>K+h**=p!&Yoc4kf>f?+hZF=BW|tIXz-@Py@TjsT%6>|FdQoT8r#uxeQ-'
    ')%78pdt3U^3?DYEXk1vAG;Ay8!z*U&xMt;V%{iVs66OFMGI6!8|v^^_cD+wUMf~dJgiA4hEoe`*8haIDH34L$(J5aU2DAl{cyLQV'
    '5{aXBgJ<Gh(~^MHmF1;Q0wfcu6u;z;#hS2!*hGkivUXjm~YKd?QnKt-FvefzxZ7rGC4iug>xrQ|R4WJ=>?QakcMV0;W29wj|eKYb'
    '7ygBwPxB0dWC&;UyR`k!FXPf0?0$b10B6suhWd{&6!v8l$EnGb3tk0_yfzKIZl+cp&&L!mNwSY;#VtnXa`kMVY+38W#%=F23}j6F'
    '$oD0j76h*hZ_~u*48ow26bG3Z{%OQJT?AX(c&VyEC0*0hiiX`YWUF;<qQZLbP_OqN~4-'
    '><WWdif%lX_fAQ$2}R6u<(E}lY*Im=V&f6$9X$<;_gs69sbU(gg$QkX8zaXI>uAWZj^ir>S@I3&vT-s-PZ=ha@UitIsQ#_NkxghD'
    '%_Wa#7AtWMzJ;d}HNx8m)YZhJ7~WMSS&G#%s!}%hX`-'
    '8mbID*bMs8s0RPmf5UrxGNVhtoUGR}pdP9Rjm2X6@cQ<)JvTa{;<78g%YO-k_&+?gx}V{wi<ZQWzU*o#b6%ac`_n99qx3J?5<`Vl'
    'TAAhB_*2zC_2WZ2M|J_c*dzFr}Fmr8_+#SGC$QNVea;9*RSYxzJC4tOv^^^EaD%RgZ39@)X*8`ewp8`*oy#!K@sTakFxDHTQWRYV'
    '8YK0!2sG?_42H$uiHPbf}ZX2sURAT9UiTuq~N*~XU>)rzh0Twf@Q&yst3YrF~X=bt$v$3%W|{54l*Hi45(;wO*6H#JA_UG}geT9U'
    '89TAt7fGi*kd);&B3on5elz?7h^i4tX-rYrn=U8+k<Lay~Gi3rBZ!Z<6jbyGNWL<mTe8hvoitHoKp{xNgb+u+yH_QEj9QA+q?L{A'
    'odGyRXAcJwT9RJdfBD1^Bh3SA@J{4z2=aK{Az6}W`V6{WqCKI}Aj2=^+Q<39T3DpWJqUf(3iW}vYu3^TqWbjO}+5~`WU#v`g>2B9'
    'M67{t`MG<`9H<_esw(z>C2WTy=R-'
    'bY5g8TEiBEspWPf`TO#!!52vQQ+JFPK~^1ZFlM#xSNDGoRDL)c+JZ!VPHA!dAl|bPM)abfXXOi1#PxcdU|R_?DFP_(y+F2aCq4US'
    '8i2j&(WH_&>>^4V(D>on1z4SovB`u5MZO9JswnpZS0YPn6gsdkws3Wy<RhnMHXR(Yd9nJYguk)rYI3uHD9IB#fr2X=WTUu81c7GO'
    'v;sqBxR{9eYBnWUp5lqGFom-fXg$^WEMZR64ItZMc9LkNajc;`jvGCP?~r_9ci$@e0>isV^k$vlRX;wSE-'
    '5GO|${PRq&R|+M<@Gr1)87oy#}_3&@hs-4;!DCB5{~<{L((0_*vTpVV7`sw-^%R?#gU-ooO|kK-&Vf2(+TM0xqlVOI&lAbw&-'
    'Ga&-b&Z-$9Oz|x%kwEeW3?#5emx8+FprE59-AKKpCBvS#<^V67T$?$21iLG?O{Ef)DAz?VF;1_j^E{vKyY`)o4$BI-CuZVUReX9*'
    'X7*2QDwfwXM{724(6>NkrNNK#uVkcP_Z|z8<wjd;lXzumQV?kwcJGS5#<BiUEw)4-&AfKCMtw;tXQL56m$5~N{8~O-'
    '3V!=+VV|Z&5o|>9)4g5fa&oIJ4_ywHx<m2|n&s&#%5sqYHXj4Lg!7Le4~q%#s}R^M0wh4eZ<K*$;7F2@RmP(30*h^AC#VB@ZSM+t'
    'u^XV)>Dm)o!f`GDsW_oYKhKO7cgDdof_K(O4*sO%P@44RR1$8b?wWtaJxtYbs*RFXNBPA<4jkG+%eGk6Rx>Q7keIuAt`R*O65UN6'
    '0bF`2?pF%g6?Dhru&4yF-tlx_3vp7mP8LPRU%`c6xYtLhI3)p=n<GoM?$jLbg&>ko=i-'
    'bI22b%^LR=V?<<z*$Vy?jFSIJPN1tm&hk>v_tgXLFSWC@4LrP2n{I)7_}`CD<-'
    '(Ek5ZdLLV~K=ofOdT|TdY!%Ayf?zH0Fs0;2%W%LU;%~a06X>K(>X<YN*C4e)mGWITRBgZp&{^DViHO~Hg-'
    'xOE+Y}>STlG3!)R7kRxyQC>H^U!UTw;3Jbv6+#2}Yr4+SPG%G-Ux)mgOjBC39EP=1w*>;7!2_^NpuOE`~)lmLy`j0jl=xcLvdS-d'
    'vgEB;fU(XF(LCx`pX~Bx!I~*fj0i$>UUoU!vYi)qu__z3@)T^&t0WOdeb*4CTJ>-'
    'InW3&6qC6W^^@CXhK+s8<eHHYT$@2MEeC5^|$r*7asA2n*6~Lys420oNZn4(AL#-'
    '!;GujFn5+b5c}68p$n}f3SpL7A8ri+2BKu1in$7U3<_w4%IjI~lz0cxcFnR;Kv@n8MJaELplzegiHH}mu_^hblQOD6Y5IjsQfaq('
    'pg}4{rIDVzo7#eK<D#|^R&(rkC6J1ld{E#a9=EUoSvv6@4Donr<5)+7_eOt*V@tbv8rH33;<%nmh#^f}(oCvj9T_B+YeP}QkmjcR'
    'VkR5;tG)}F@Aj}!83HYLU)r0(er7N7dH_53MaCl;A^t*Qis{$U$dAxVnK<>~{fBQ^Kh>mM52XJrtm139O<y8`A&nGVq=FnXjyw}L'
    'qTCgQnYQ;$s_+SQ7OQd$_XH7l*+^Lj!a+HhL5!eQ!ldVpOGYhNz6)jfI*3)!wBIC3Dp8hEGdIN>sQ@mH{M&YPZL>Fh-'
    'g;n<$GLI6!mM}vPiZvAcd(C8#v;pl-'
    'K^+|7M&WvYCLp9LSszqOoLxME1b|<<uta%K&`08?#wNx(fK`VtVmtwE4B>hdn7uSlx2yTbah}v!tM&L6ngXYrn6<6z;r;IS(r6Z6'
    '6Tm_6C$m;ymR*!tg%-'
    'c%QwP1{(vkVUvu#qGJ)3Rkt0v+Y?14j^VMk2QcaiK(kN?p%rtJ4$Y~SszQ9Y$T;Xk>z6LHJpXkOSct#TWwBE+6>j||DT=n7_$9tK'
    '{`TI0ZMq5jmT<Mk(*{fEDYd7$UixF%JMclL!Lh!(>va<oA@qNrUZf1wUR&!Js!<t5lc05A#kBg=mSVQ!ohb868j|fje<gbHn(JX1'
    '|dnD0SQu8QqsEC1wS5=**EA~*My`ja$IBzgW2>yyUpc^JLKmU<gM|A4v+x}|=`utQ?jlQC&=pRwy(!*zKo8!r`r|F;4Xl{e&&IEa'
    '+W>{l+(@HCI30U8wpY(XB;9{Q86QuymQbA*d#I})PvBK{uJqc~8@L%HfInf=`$HsJP5D8BUSYDGEROmDtX<Mv__cGNo3iB%ZAZ<K'
    'JD*Z-3I$6+MJijiC;_btdGFj}Z)D0#?Ffm&P4%M<5O-r8E@lY}btz#XVr@QEq<!75Rrl9ndp7t2H{-'
    '_W<Rgoz`cw~1G{4UvJiKvxDQm+uVedRG_ZOMiH*vjrFweBSt7lKOBnI1PoC8wA=f;L~j=^mtb1R5Ij->b-'
    'pG5pp{P{*9oc9VX72X!*W-9Q`9X*nG?eiXnjky5_^2mwni%cYe?#29S`z%vd9ij3MpEVeCWF-'
    '!U^K1MG1HmbOXl6e)%0xn8O%$a54l9DKQ|21D9uqExDxM(NKxX8o@GG0CsEK2EB_5%9{mK5V%hMP`n;>KKdMoZ@NihP(XZ%~vFJ6'
    '3rOtXU!^o|`TRBs9h-KVB%aWV^TyXpLGwlJt35P_YoMc|MSd99hQ;QWY=*1-HkLnBfi?hN7|>4+k5k-'
    'xUPP{D~JGlRVQ5)C1o|QscXVP{8I|%KZC`1Ji7h0l-'
    '?c{Cd?ny^J$};0T`~k!gkIG13ZcP^~wA2#ZNeh|H&fnwT+rfogX&xQc9JR^WKE@yL;brs0Z5Z>;Gy7ydP7^Io!qd3jZF6{!7Ski5'
    'ppU29jj%z-HDDqnyQqV~pQ|4G{#*?qWa(t|F2o8HroN}Ndm#|vx|bCv<JXPr3iIU_pS0Qy<Cl!8(1Z|8-bs=$FEY-'
    'R!f4w!4ZaSCQU>}CNSmf`4(xJVCyKH7fp08b+U4hw@8fL!+>m`vFjQKBMiN6U*-'
    'LQp%#twUOQ=8l1<BUt5}uNA>H3LWyw9+?XheACn}IwzkSSQpc{JGL2W?+=e3x<uMCLa6tK+O`vnxnJu}%>L0(=NV^`nF%}T!$2Qr'
    'BpCe{mnh*j><*k1zuf6oDkf#mQkRfcAv7ga(aJuBBcDUabw3Ij?B7xtX5B4ltu>$6=|Es^K0Zt7tTcM=D-'
    'gB|4DXoXB_4as5o^7PTrF|Zf-hu*cWs+%nOr7qxSXeBrB8~_-->t(?}zs~S!Z%jNRb%_SUg#?8MY^u2#*HVa_KR(2B8m*un6}?-'
    'qm_2wbO7L`}OoqX_L*4TtGDEvl^1wD?%-'
    'Je((na#05QWk(wqf5Hir&QlEbw{N5NU<OazuM2{g#aT$xkx}=5iE>Y^vLr6j3mmFxHZ;;3_!MrgQS^ETICiWvt2A#F!qJG<2D|Ji'
    '~PzFRqo|pr%Qz^*k|FKQZ@A`~5iz`8E_2G=rG0{q$0K8ml5ymda+KbFrLP^aqq3Xr=in&#%fdZ>*@1>@oe91R9dpnO$|5V@V!(ye'
    '!yTWfjE{5+v{BWxH0DZ2#j+7=Vb}=O>OT;VvaAUXi(4v^kQkYD@61B$00-UyO14yT<=w-'
    'QRXH9Blu2?3uH(AmO^NY#gk*~<e3(=peUjl+?jz0ceK_=-'
    '~M`$Eh&%*zs3p7~UFlkpXi2)+2r#u?!#gMDQ%%u8J#2wU(3)X}=sCD%!P43w;#4PcD3W+fVNn+jDW^R(O<qlq-'
    'T+WPbDDbda2fcyR?WXQFhSXg>r3Y>J>(op7&bM`mtyAqK4X>-'
    'C%U8J&rU<TibFY*#kBm}v^*I*alUeZD+H8qF=q$flr!WBLE*=W(`QJ2E+z<<V2~!u|qUoh90dSf7KXSa%)-'
    '~|VO^*&N9j_afsDS>$S5uFxQG}H-Nm1ba-imPeGG)DzjA6epbd-tH8-'
    'rMK7GbIuMSMWiGPmJfue@>=6~J7a3e3c;GADC)p%*Qa_i~GgWTmtWIgipf)9zsQ?j`F@a%9fHAYDzmh^d1A#_WqN?@_#zW$XFgc>'
    'WtZ&&6^NKiU<P>Y`VJ$$X5IQCfHa4I#Z1l0WvE|0wWK0P6VVKe9Qj=U~aZ`*kbwor#bWJ!L)b@`H)+>UeUFx2)~_#)~f2qYgUB;u'
    's(#v$lS_*Zr3rl6NwbjTn8d<qn@Jen55cIb9gSW0v*$(J-LHWE*z7upMZ*W?Q|j%VNsBEWnEGn7!wPjReD?Nl4$>PV-'
    '!6S%V+Z;^yGj{Gye}lVg3R)H|o^IV#ND8A;=qU98DFbUfS5H#gDumGb*6qd}Htm5wjr=;|6BHJFWVpJpqX@eNr`brQ>rE`P5j8@d'
    'c!7_wyzp$;|YusEsZhg`p!J1esuW#@$Sx34yCJyH(dMb$jsary*}l>*z{l{HfWnKjnSvD{Oo+7y*jiOnJ;u`s(M36s231_o6c;@e'
    '7dorrhDcT!6Td_>bIZucx$y?~?K(psUvj(V>$vk36c2y5ADO7`O<({7atLB@#(3`r!kDj%R{glg(n=1tKN8uVs8&}mPNh^v@HX%i'
    '2C82+aEqF<E&sx|Cbr{z~R^oRJJE14pjCCg$HG$lEv_gg8<80!iyH$>A`D^t{Oyy@3zVCL9F8tl++^gFq@x(x>&+WN}&tpcv1DmM'
    'oFvwpgVqpM$%H?V}tl9}W0>P)JnXi3f>B|jcq1$rg3kDvy+=w_^M)QIMqJ3GonrX>CLPJBg<R?vSHi0P&<7`1kl8fN@#H1s6vw@V'
    '}x3LX(vCMsEi_*Sjpn_6T*!9%J``9%Y`ubQMkh*rANaun|Il*XQq@O_1y2hJ7NPk*eh_>Qqm63oJhj_09ytXQnNlA+vQ({xB>OT_'
    '}NULo7>WmefvH=mVsp%122t4p_HuhW+KY5T<F$gBO146LyJ1dIvCuvHh`qHZbPtaIeKMREfQhZe_;dEX4Ym7RmF@2nqfEsEF1g6_'
    'd@JwCOVlqOG(0hQprEPkos=xR;;#+&(KKE!zezXByr9<L7Bt0aVH@f5k@l}#^TRX;{rwzvY>k}AvKC7Vo0*HT%H0%4~vM}|(A7on'
    'Qb{oyP~nPK6X5#nWyTAyp3$a-77z`e!zlx+=y^*}Lz0y4lj$FH+Ec%P@K{8)GlQu9(cq^asL(d=1r2Ff^#<8s-'
    'T@4hH1A8g(Dbk&!@t+f?pJsJyyQ(+V@DgTFi#ueYf1UKChtE#-'
    '33i@d3tT^6p&4~L{#P#$IQAIfToQ#P_dU<NwW7|ztwo}@QY2HeEaL|W$xPF^~7f5?4v~~izLO4fApIf9mik1`nyRNj#oS%#}(ez*'
    'F(b3RnuS`*tyqC*+w>QPf%$JJWcUHVvSjQY|E(G9>!;-7^&e0VBMEZ$81bCYBe^cs<Yyq6*!@j&4_xXn$5o+#{fm6S81QB{$Y-'
    'W|eOf6bglKkxad~N*vwEhYmujtPo;Y(klrq45grgX|b=(^ne(hl?SH~#bIzyIy0|M<86<Nx{Fzkd8RHoRzV`rY>*zWMR%A0(7^)y'
    'De5!g_<dTlc3Qzy0>zU*3LtPk%Zbz5~5GXN>dw3+%`*l(_s4O6Oql4S)FY-TQBT`Z$|E{Fv9|je)+9)}J4E=~MoRHTyidT?S8Vdw'
    'co3F?X_BGfd}E$OLzuiA?m6R(jT4P@3M3@0w!{)tlb<wsbQQo8HF5X``9a{HE<KHF{HERg`2ImpNkXyE`xCH@k%-'
    'w<un+OW~vD<zQR|`$WS*5kYJUxAEDW!qFmsf>X&TL=`iT*2us~*BF||%lS;^sW&uo^RmwPPOB&pj;o!_NjJy9+@*aj#RE5dj67K4'
    'nGZfhU}2qsHRL_xhs1=<&%m7&#gM^~&I4OT>_*=Y5AltW2@~lF>3S&=5Gi2g*`-}gA#JTCX+HObbiaT<uCq@35&Iu9-caR-rKP0L'
    'yS)qfF1eIu_S(4CJl>WA*H!P{^RA~(;?Q~*ok{Fu)l-'
    '6?(*bm~y|2%u#gAKa*b5bGT4)8Eph+EdD=A#{bwq&O@|8(*?)e5h(TS+)QJQ{xy$GZfQ+Oc_Jl`s}?wmVpAOhQ+!iVq}+o#X-'
    'DlUXO)-'
    '`<`Ym=CrV;2TyC)tHd%e;#l7mV51*_x^0_O6`VTD*#_hT#Gtap(JYc#RQ_j@mtE%6SyfRVMXN2?rM3`rft6btjSoc;((O<f^7s?%'
    'o~iPl$QPE~>`U)4>_8c<t}mex~8Ty)Nc+arf&FN9#^LfAh;9loA<!IYTjv+3EB|khgL(vP5vK8NN3j3lG1`MctaKWlapyQL7pBr?'
    'S{D%UE}GV}gY5Lf@&T+D-'
    '1vtEO_5r_gEXO78(BU|^z!WwhSkc_S=Jo40FHBb#n?TiYu%sp!<9VsJtfdArY8kWfAS5!?iY&spAAd$Y-'
    'L%|xzxt&T~Ky&ZwVeKo6Yy}?A#SIvvu4+rRv?vc|sAE}h@cOQzec<%LP=08OT&nMwZ^X(KGXogKzYc+v*?Weym3%&qWezkku)*4o'
    '#tGSE)^(2(S9%jARLrYB9Mf)+;z9Vn0pbeR&rD~0ysS*z_45rSZyCh0w{22Z)X$PR@s(E!S;0FH074As5AiF+%vhp}GN#s-'
    'r&5A>SGm^af*^f`!F|zXf#3vsD3};B+raP=h<;;ZC4@$fBp7fB_w4zishUytKQ7y}!Bad$n+_j}BNxaezzmG60&B2DKFlAMgo<QU'
    'YO}o-S;WEh+IVH$JVlB-'
    'N2tO1lx}*uVhogh~3^Z$t&5;*Vr_+DqE%)$}7Nfg;d+SYx{X}w$>dGwgW)m|IJ{pV@ntk7&p7;^Z)8=VVg0ZPB_&lf`bMyUWupcv'
    ')Z@wrf^jKc54L&j0-oU`%G6gpUq@CP(O^K8wt0nIyj_?xHHh4sE035mmt=sf5Y8WSbV#-@sh5AcreNa(-'
    'P`AG>%<!{<&TrmBv3N@E@$$TsYctKf%_R(T8E>O=0c4L*zPJE1-'
    'R{?|!nnizQ;ztT{l**BZ@lrWRkrC5k4)bs=_V_sT^`6TH#IwZqv_JD>QTp5cBoMp1U~>eEFyNd^<Lb9Sn^34YMvzekrieZO9GMkR'
    '(JB~`iP>~6+(lz4ultAr+1$$1o_2jJ+xO=nV<H>WtB<zkJIjRSiciC#WT)!rRcmB(zCt1h^h8e=TWUj?;!~!cj@aILjBBOhn|Xx1'
    '{XgAaJV6TcZ~w(C^*oIGswgqyy#BP9#b;OO${3m@k^|>uEdWIq}`!~94AsYZ?e#{$Y20LAc;r!Ui+PFZzLzC!RbIaz3=dObgVq|o'
    'ovEmxvctH;LtU9mUy9oA598&wU?0>evaxE3GRa@N-'
    'D1a=+(u{R5~#*a0`jAuf~Zx9?BLz6>ZKj;tzr?a;&8WWq@qbb9|~zCh}y8QCFL-5uZ!#s=Dn`SM<rzxNahT!6-'
    'ZfL(yY3&<O5(AMx?l%*Bt1#*u}mKx-'
    'o`JmvMcSfMk#z!Zfk1@U{>Y#kh~<1ZYpMZnydp8`l#rGjsK$&va(Y)1=R;7*+T)lAouJH)ZO>~4X-2;XFCmD^EqWT%2xjXF-'
    'bf;|v43s=FgD!~=GMZp{}B$YWTwB2)*)vZs37{U<g6(=wGR--WqvMG56nKd8klup1pA^e$mcg}(!)eE*S*Ivryxd90OgVy_JQM9j'
    'd4wg!#GC)oTYHS+U%2<Q9if*n$)GH3kW6!+QXKCjH2wV%raj|&A3D4wG!L*1vRydpjPV0nUyks58cqLS1SrE<q$Jk)BAZSn%H8tX'
    '|cUKGp+uWrnZhFAJk2kEYMclY8kdQ69(Dtb@PV9#STE82rhR*k^Qv=7HK6P8m=Kwu;NGFIY3$%%S%6vH*|9~e~kb%-'
    'qpUgP?HS+X~;7*tIJ}nJMdHUHb^{NA9*hY8Dymqn%!0;u@S0JP4Z*iq%Q<L!^!h)FcQX$v(A_$AxSZB%z7o!e?Cuc{9d=MvWJ(0%'
    '-aNZ^4;Be8fi|XR;1j-kzPUA<tbQj=cY`-'
    '8h?cy!is`;cGgJnA(uCJZ{0W1y=0;|NfHP0p|4^Q3Z3>*uMam7?`N#l742j~(nC<1I;#o8@&sMJbHYLv?+nIo#^K|K|dNd}-'
    'oOqjvuM#+%Z0e<)LGMHrJe3jkft-dURobf)Uh;6t{?W;+Gys)sXs)-'
    'cikrv~<nz(#ldHHqD*g6rxq3jG8J>}9DUSvQL^H2tG#M3zafYOn~NQ92fdmI;o14c&b7}0=lQVTYME0f1fh`Z=rro8zrULu5MH|9'
    'xo`rL>RMgRf)87bzMrVoVBu^kQ^;3nXZOBuLk^4q6&E%%iH1D|ww{$XgxNhetRossVDTlVa^ruBL)oC|lEAqne{1ZO(K57>VLkzS'
    '{*hw*$VnrMQKtR&uH8j*uMM#Crw&NDhxg&a|?lHsqS*>D7^P_fhoNzA@c$~br#Wo<ew@C%fZP1LSOdr&;0t8S#1cap5I+y8FrRgI'
    'N_$DuElwK%ZYK$H$n3Jec2up{JW$fn6*SkN^9qp|RXU?IY}qI_3l7ZExDg~IZll@&zO#+)h<Ja=#@h+}_a@z(jKZwwF=gXwRz+jt'
    'ye?!_Mz9QBNy5m)ILUjr*7F*dKv$q^Ktf(ynXIL#H$A0x5JeU%0jR%yCpuOGbGjKh$)ttLmu!Ggh>$OmYUR4gB`faJOX_lUnpPGj'
    'TbJ4Qq)K#2(y(PW)RKqHlpNv774^&4i>Fv-F=g7^%<dMi6mO+$$A0PHI%nIol4tV{<ik2U4%N52lvpl^ent*fy!Q3z-VmtKK-Reb'
    's6L-jmQ;r&&X?6J3SfgOxV7tc>fmhoA~0aSU5tTi#faE4yu96~cL*_%u8Kp`E$lRT!BSIJr#2-;-'
    'DQ;xEqrjq@kd*BYKUKKK0$iwSiDGOi<n36&9kb5|D$e!L9lcM8>PF*Luk7q&wk{}^yOV`os;vrxmu_#^T;cBmSB64R0-'
    'G~W$jY+H9Cz>@D4tz~hWG{6?d#5fypK1wBg!bib00Nx|>9%sXCO$(cUSNFI5i<i+XZ?2Gyb-IqzPBDrwg)Dz?^$n~hQJ8n7PgKBR'
    'KMcUFcqY*7}zBeKCv7Z%VHs0Ut2#i=N+FzyNiIbn=fC0KsT6Cu{^Y-'
    '<bEmJzkC1ZTcy>jUZs*I&l^Mh9z9ch1uSuIJ>+e@dDO<~R`LHc&C2ssoe`I;^0m2AHohaOm864kruhK#5^zUbwO9sr#qjwUDdTvK'
    '({v}ZHh8YXHke&%HmRc*ItGXdq@#mB4mH>dh_uh-_E**7r%U#Xs|M_HE@w7oY*=b4@oC(hetocDd=*H_P8xz+ikY~ll{p((VJv*2'
    'aWljOKEJQq9`?Q0)D_7o%`Ens;*C4msXUlxo<`z;{gV%;WEnCFgsrhsRhd$7vVFRPv;~b~{8gy72NT;;<vgazF9*i7z#<+M1AWpy'
    '*KnkOVXx}JU=snU175mOSZF+3q+}M77G+iB4s^keAE^?H)BQr?uk*?E!1OHPiz&vxwx;W6o-;Npxsjl}Al|F=dXwaqZ_-'
    '`$ka5PdHC@X+s~zS;m98muVD=Eh7f!z-'
    'EHXfU+Jx(_SLo&Kg#~J=jg~jFRLg5`blsWOZD2h)rpg1$EvBqg`oXOp9S0O^<3DI3IAM|sP)zB^^j*g&V!@w34444J1{KWC=S9LH'
    '!Mao0bcKjB4me$Bd1ugMqr;6P7MOFFR)%TSz;M%`7lZQda~Kc>dYBW?B8?PP7N$$NMSE!goMnQ<Rp-'
    'u4P0{DU<X9&~Q^|h=9jOBjD|IZ?>a;4>FZ;G43M>V3U)E?*5qYv%4-'
    '}5$ozTb(Fl$h5xJGVgW#Wn;NBZs=p?CuO!RzY*$dmMO4dis6M!;@<H2_3m@>$yVOX0V_y%avmf`&K(At!0#5C6;V$*Y*(gb~|h!|'
    'u!^pW6St{KexSFC3w@EWMzAnY@8Jm#EQ@xOGTFC4Gc9emscapQpSzP5)P;kCQ77rBB0J?2s`An_5wH$`Xav<kq?6GSW_$#=$Wep5'
    '!a!)S;7Yc02yt{|8Qrt6vyc#L#TXO=-'
    'LTx;rZ%zI&zN?)2=;*ko)Yfjrwk_8fPmX`9a1(_~A(#?mI6j<xS16#=eg$UY<f#F_WzO#*c9IaEk58vduPw%=gP9>T_3;B37~xyy'
    'W`-Y$O<txzsvp<;>Udb6jrwlG;bG8RkDdWE?WmPIZXz45m)Eq!s2CZ!ltOwQ(8@G^xV8#~4tb!q&JH<hoO$)iOM-iETX=b?Mg!8s'
    ')#(7Z88n#(YK+TuV3+*=Vlp)D!PwuRE2fBxevNU6mFv^~a%A7bOZo%;Uvy5#qEm;6@cWMIuo_(mcy>n{TY<M)4j<svTY^>n5Mofq'
    'PN<6&1@4k}MWWN;1Id$zpL^a?EnHD6$_L^_q&aVW=}B4d<eycgYrrCTnxH`KI1V=J|mu`XPe-'
    'd0NF5MBg(Omu0J2p<1|N?2y>KHygEX*?i=naS%(e8w(BCUhFFFFymtGO$msVp`1iRV~WpbB^vBLaOJwC8hP-_Jx#Uo{riW=OW@L5'
    'c?f%7?As*>(1`8Q8zfqi7N)-o^DK$b0g7!PFsrX!sZ?49?h@Qvj>d3nYz9uas>RVtF_>@_NFIMrybO_IPkt4h*-ZKoN69-'
    '3wpqm4i?bAk3mIV2PoP1$l()7<P=ui>XIuJXfZG%$%)Bq^wv)e-'
    '`Ml}pfX0lM~d_M<mCIr*Q*ajFGEEA45u;0N<h|a0Jq>=yUevOt_r}K95nE>O@5!sg^or-'
    '5k!#6`^jJ7y?Z?(fa7co94CX_AN8zuRT&5dPm@UnalINp#$@)~qiQfg-ofoOD8L+Z)E{^j%ls1k`EBr~l?E9h@raA0Q}6bh|9N)D'
    'G!Jvn(W$x;U|7VAApO0BDb*35fcT-=LKGJ&`ZWlH-L;v=@gEe7g3iii8_jQ3(C8ovoCWb_uwx-'
    '!Uxj8QigV4|V*uAOiF_i5ngBpRwiy!xvO);5go{FoVjtn;u{KzErF8bxvFSHUCYfscfV0Cyxht(ez_KrovOz=8;f@j-'
    '<XVWsW?cypwW#Ru)O&%*Fk|-y>z$xyc0J8y(jd&T0Cy7Q4*)i%;d)?7Zlq3YTRi6YIBdop@tW8waYA<LJ(ycH_po^@-'
    '<rf<A^cH=&1WbI0nJGIhU|_fXG3eFDzdzO4V)y-Umqvg$yifi9<F=B4d$_<n8(5kBI_U8xg?fN&5JXF!5-'
    'k@cwfltaytPafj@NJF)XH{uRX$BiQ+x2>G<x0%+p747<U0*2RE6)N=VbWDPG(M*CtbS4IHe%exxmfD2n=ZehWJ56+7cUL{4UzewO'
    'r1NSj6c2k#pc&<AfKo8M01n5ocu)TQ$B?vHZCHW3~bgm{;Lq1}=E>(iq(ojD@C0AqS)(GO<Ia~(UFABN|dYs~Ld2ajwg(UNM`OW5'
    '0f@bXpb)?dzUr=d_Qsb{0M!W2LC=w;(s;r75Q0sxj|l0ChrDaaag;>1i*+Rl^W@Fg?_sQkFyqlU;+y@i)@7mZ8JT$;>Wc)1E};^J'
    'fJkl;N-g4(Foi)9cRxQyFm-XjZxx}6l9aO0$_Q!VLl<Rr$V<CVH_08Ensu3kOaY%Y1@TSokog5pt7$^tHhMxxEe24iv=<b7Go<;|'
    '-SRZ1;b`J7gGKS`(Wy+|%q^}5$@JxW^zN`4~EXP9JtLiJ&kEKG~FGsuOZ`-DA1_B5|Wj2WPGX>~*|oa5Lf(M-nyj-FfRh0MY+V}&'
    '#Zli5Bc3n*JGa-'
    'I8fGGf~*yj8T@=(p6wi&VcIg$i!~gcnRJ#R{@4tA}(RU0Y+XImUyz*c6P)Jqbpe%e>4o8n^@Qru$^UTVQQawOC&sWSptPI^$rXX0'
    '0E%wVf5jda;Jve?^IamENYnswT>W+B&?ZB8U3ffm$7wr;k4f;JSdH;RwOy_$cZrt0l4*vPk)-'
    'G;%dO?HxHBTD<X}!=onwp%(i64C%?$qX}ZN(X^__Pf^W7ChgB_fEwk)XvbTmVFh3-'
    '=1MQxq^%c{Wapn7AZ17w8HiMla7cTg4PmO#zsbv=8j<>vstcd?(mbFEI7AqFW0r62kbI4wP74n$c{G^$^hD4Ij`-'
    '@LzfISv5QyDVFb)}Udl(SQdi^imNgh?Mk@vf9?a)(RPKd%XKMI*iX*k0IYQf4HSmHc31;C5!Rk@+`O4-'
    'y>z!XzUX8tHAT5*d!1df@HMszkUUE3HNGbNwN5$W^-'
    'ditX*N}95iA>2)B73@)PQZ}L14lfL<{LS+PBmEuJOyQcd6;>YL7lC<h@(LByp&URO(5J7hJH#3CO{oRUZ>hkh+oK6h(HaT;Ev3#x'
    '`DRsO!%kc|kiA3oce0%k-@?*nY4F-'
    '1U%=`kwC`B9SQyKGnJ2Al%@6vd5j+Qmp1{OCirn7uie=W33JyY0gP?9yupl3c18azKo5)n(GKy~(aHXd!x;j(Y9aBO#f>SuvlZ|T'
    'sRKYQcM(ob0kYBPh=?cv$v4wW?ou9ahMG4CJRXm{*k^#FlX@?qP;x5IEZbXZ2I{O~;KE8=2Q@zd=4-'
    'XipL%9`C@diCU8~NA0Y^N%$UR8^m!%>)5nLQpHW4MmfSJ8?JT=HC6zD`!S8!5q5G2!~83B)&%NJOBd7&0A~^c!2rceKAu?niq17k'
    'MF*+9R92MUoh*NotdP#KGP)nqBdniVj~UEp%6GBbL1^6=!vj^RBfvx(5!#s(f?o2DKEGYU4Cf4Jgy$sY(lRqdEA7OrS5?8Wr*wUu'
    '0EPeiseks?R{3i0M2S<$@WGQyr~XaE#kHN5R*gIEFI@2b<@xHRGCa;ECt_a-Sq2dyS4+k4E1C{ExXHw6+&-'
    'Q*j8F$a*JMVcX{oMU1G(71}C=XAml@f&|p1a)~Mt+1UTC2}M8zjskg3U$tffU2}i_a(MsY+Xep6??&X9)3!q#qJ8FO=Vd{NxX1{?'
    '%?-pF>b^S3oC5@ISK$%`1Jg;2A1%_TilCmxQq5}DCIDGRmUIE&Iqel~j&669iT4rB&MBk^9?El-YzIo~F?Fb`vUW<N3ENl_F}zn;'
    'Qv_}BDlJ2SrkK5xMhotIG?}FA=FtuXJWo-0C-'
    'L<JDx^LRlC;c{VUhzF6(fAMq3~B7=qBLF{FOPtli%|Vl?uVcBAnE@s@J^5*J^svUU^fx)e5vFkFZxGn({O+2BB1O%q3`e#2@NI<P'
    'hKJSUquT3ATHqZ8(Tk9dENU&(RJp+N~RMLx?nz({otOlpV)WnB+Qb+dd7n)G-vp#AvE-Ax;0&#B_k@Q&T2~h;p8V{)2F0s+dKwVQ'
    '16&FB<fSJLOI4{^kiJ19R_9i&bMn93|SxM21Y>mk)lS;Bs|0fgB6xm^GUX9UR>{9TN!I?sN~`o03bUrznspf6P<ADOCo{;Bp4RgX'
    'zOifQFs~)mAXm{OMSOWKu1la$r7e{8WKN%H+18Jthz=%cPuZs7~>DV%r!j-Q-'
    '+iq>Z^bFG32a8bPU+KEdNjwbh!&S;I66TWDWy96x36fCzQFCsn54tzcDvX~^QqVs`kgYgWFP=_ZyhEDFki$t&oUkb$p5;QrOquq~'
    '9QrEKfTIA<G^R8i@;e}){T)(z=G*`_k3O@k=a3+G7NSh7zNDA^l^P!R#}^mU-VQ=0X1ONuTID3~8iy_p6T=ifpXJw0w#J&<tsJ8B'
    'o&HL#3zS0Ba{{$6&Tyh$2QHV<wq(fVOpFOk)>5l`$wt4X^%NM~QB<cmMpk%pd3HdK_V7WK+vLq<m~6(p9YK}daLlI!0?D79obfU>'
    '8mH0{+~bmC^k+0$AyReS`uaSLA^CxWJhcd3<onnVUn`H5d6NsYitg6moA?v~hrkF5BWa5glP=Y8A!(>08WxD{K%Bl)XZ%=H!?*D('
    'qlZKuhzIvz&5bxdUym7q8R#)V~FsctILft9Aa3BdSudDW2RZb*e>GC3yyreQrgo)9Qcr<_I8%eY|)25vx)Z0sR=B;$5`ikq_SDgf'
    'bKWd?>P^Y5rMNkIkDDI$(;lCQ&dg#4D0srXjquUkPSQpE^b3?~2ZlD??t0W!a*ii9`Y@7Xn<!DtL5D&4tImjwVG788#AqtN2T$xs'
    'kE$jrFW?*io-0OG*uPm}J(rvB{Pb!K{fZ*AYClz+#NnO(9!_jaq!uunIwJ-'
    'd1@ox*;{hTHB6Z@6yTIbW=rsHrnexu>Ld5P>PvcWR}`LBA#O{o<uJJfD4^mSTW?XYx0@raY`kze`RZ@pMZlCE7hAljcxgzS)r~Ia'
    'U;pZig9Ba-#*Iw=a0$MU-u-'
    'S@np4k?BQqAEFg=?PIbK`qyiRvTGOSY|`S!op?nsWdgh1VVLug#m0F>z?2b~L;Wx<rl~;nY>6qRz~lXhaMZ}gfT8JQRE|g`@E)GJ'
    '6&ugqh<czF)<ayyK=D21VrJLYNRd-AO=c)VgoBgjkHy7XlHOo!2QrNwVF92a_mkZK4K@yA>Yth!6ErhkKJ5`Z<z&hjo(k*7E&BZj'
    'vty*FiNPBCygtUyTqWZk4JEE{1~|~oXpM5Q?qHo$Py`V3F4(mbH8pIh4J!IB{TvdG%b<e}UF2A(Jr}+_g;Ou*#AG6lbj}S4K%6r$'
    '!f7yrW2S??U*rtnPpSqhT+_KFv+dcVi~Jx|adBnRm!p_xy>rdtT1Mli@hk~Ca8Z$8y00A%Xe`MYMc%&94?67BBWj^^nBGQ?dGzVi'
    '2EBWx>)O!!Vo1$aE`Ki^Gq*g8Tc_LeP^2zyOL9xIYU8j!kIikZ-dG9wYuwQ_US>>r)Z_mVjzfA=mOz>$Z+Gr9_H-Pxj*rzbmF^kz'
    'uu+p_iwwD7BRzQgUWA@<bqjC4Q^gE|KWwxrEG#g9^E%3Oz+^wpK1QO+J0VY1Y>u*deKj=_E{@fFVHqFDw7U8od;1iGEPR2RHQE|P'
    'TG?v9+25i4hI2b8Eu`az*s<s#5s0t0sRujKgoF6moIM@$>;*0Nj-'
    'j7p$wv!jMl+|y9iMIMQSSxd;rQXTe09k7vZZW7fHluiM@t2p-'
    'oO=V!Ym^l3ooaZG<rU#IOmwDq0y2*d0%nf7&`mBUHKY2t1HCd{DcH*(;Rbr7clo<4we6YJ~>Cva+Z4sDOG`c*yETja2!jyqdg9o9'
    '@|if1cCSV!r{U_Y+(=v&_vYRwGAsujvec&tB=?Wv`ekIhno(^VIBE=e<L@Ybl8_WU{9x}W%}UI!m$|*%KAv#_a^?s5>Lso?YsNkT'
    '(X-;7XlT3&^1)05WNXo^sBH%Z{$f6yOiG*jmIVJcqSj3#<Nc5-'
    '0TvHA&VZ4xDuF6;UM9Lj%2=R&JekV>S4OFeHF5C!<2^G<j|OInm4bCr3*A4l{0kBb1YvPo4dn{wuPXs?n(pJq<rCGPJ0dOu{O@!o'
    'IJm#s;f`kmqyK%a0emT(zqLqZsw|Ka7=Dq5j=L<+hrE)YkS)BrC|UY<uRm<?9GlsENARU2;Nl+w1!Sm0Fp^pPIc=t`$gO{rw8|TE'
    'M+_sI01=NYD85#8LyDWG#2O-$|R(W3OJ-KDzD($w-'
    'u^f!d*t+OgKC2z#0Z0pK8FYJgE`Z*TaQ1j;)^<1*1CE0eIw?{}KFJ!y*@vOem$q;nKw4F_brNGSXICl&c<bC8YdHIDk)!^zwV=n8'
    'hF1B3rDV`g~y$I6599?2)!JABp$w`$m?%x3hiCx6?Cx5HUjWA&ZYh!)#HpaXLxwH0(+>-'
    'm6s?vge7<(b9m05eyH?kN12CyLMwLT)g^f>RcpR7KR)5x{p#FxJS|8t#?d5usA~BBd<i*NVzF@pH`7k_@tFro?h<OT5HQ~4_A2CG'
    '&Hp+QYR~0wt)wC-'
    '^lEM=owNPDC3DJ6AzxEc@6%<6G+OmYW&N!IXZEqQ$kAod((8C5}Z5k``1%UCgURjc@OfcYa)Q`5tiV{^LS7VpY$3W4>Db6W8H(X`'
    'q98vKLh9n$sZ=m+u0Lr9>62)X!-'
    'tT#jNK%gZzhU=y6^#drCN1uKJH3|DQkq{ck`0&;R~^{{3G+eg%7?*a0nUQ&B6!i`nlR+~Kf4{rK&-'
    '@BZ@k6I%JF!{Iy7U42G!&cDElk>iMN+64~gVDSxq`0?HQZ+`kXn?L-'
    'R>%bWUegF3B!})=4SK13{>Unb8LR^7__40Y8LP!PjN3@d0qmT*iJQJDd<A@k$##gMB*&9qbFwK>6E1BN-wu}-'
    'Ancl|35du%Aj+c_Wi`~mZy#p+4Ff^(fFXcD8g*4wW+{;UmhvwyATm}22k53idY>J=p*}Ql*NyPaMI?Jt*fs^hygV#>Ln_qjLdP5^'
    'OuhH<*3@gSO)MA7@PFD;c**fgw$H;>Pv@^#K0iz!sSc3wVC0-'
    '?VTPeK>t?KcZE1Giv2oZfhJj6E|9H3n);d^Qc2y0RErf|EM!W#mJ@o+$AB$+$s3;5$Y>%<?i{~_bvq<&ahO8UIp`#71oJ1#uuHGR'
    '5U4qR8gd(XR`I*CK;U34a~lT}X%f=&m})%LzVmli*6&0#N8=vQRANnM39$gcW2BEW9>%A`5>d;^~7L{#-'
    'Ct<!@y;ZoQ(LK=9!Rc_rmci2D#wmXFn;W4&PpXXIv2zRV&dXS(xJI9`=57W7{%)7X8!4N{q@JvnY9V)0;psU#Ol_?++cfNmz*BI$'
    '}uHADzwGD=@E)~?e;lM&;u6OOS!K4T9%DrL8Rh<c^sAnN}tUn><9lI#;PEQ9tTELxd*zIQ;4&3WvJ{Nbt{&2MJ<nuSb{6Q&^so8O'
    '^?~zVV1bHhrBTED;S0lT9Cf(F`Y4RPMt7T1W+z#<n7W-uxI~-L+kSMqscKqSpPQilW7`@6<=(KdD_ka??jRZv5(RzR9jj$+f-'
    'mW<|lnZEdTiYu%sp!<9VsJt<y1LI;=$||N5${i{H=yp#Cb6RUtn-f~$KH-W;VUyI?bjPj1ijg+S_lX1-'
    'lJJLee;n@`F{7I7>nm#Z)W~ebntxMCD3_0x~+q1!Q8PX5U>687iPg1KpCQTuiK5!_3i*P38k>-'
    '{7KX=t}>}6?4p(5nhKnJ`~@8?=Fmw-zZ77Yx-gjQf!Xro-'
    'g+_o0S))yM?O)c2i%l9=nXE&t`DEAJdR8fITb>);t=4BB=3Iq;~TvbcYN|8z;K2%V!Fe6RL(fyO(H$@iu91xw4zishLZ7&@S``wr'
    'twgXntmP{l2KfgfqwX195`KntwtQiMafc0fa<C^p=r-'
    'uP7l)ao2LDXo~g20@@X*PzM`$*gfN<(L=Ps64$3nK>t@=x=l|x5RLA`L<}LlAM1?V)NMfONDT5!oc%_fo$Zjp3#PBdcXtwlTJf-'
    '9N+tq*zq7xW{OLI`Y&R7sU<`q^EUtD%_sT}ud0{3cEamplf=VOBQ%@@UJhi)?Rw&WogH*}Up^gf^T0Ff{1iICqELg*LO5Qf5!yL5'
    '|qP|c!{W`no3Rkx;10dDZsu@T-'
    '6*<TL2R|(jYV|Me@>;E;)2#L~MhZjh!1eiGJU?&ieNv7`EvpRIq$w|+d=iznE84&C+TcE{`l<hr?+a`R9mNc%I4ix)>;yJ@ap%7X'
    '6o{K1XZ24xb6&3957T<yfq<cb*HRTJm^FL}XF)G2%q4&|+7PSrZOUvZoV+nZyg{Jo&&xt`NR={}b7cpDWL08ywHS3>`@$;!)U3%@'
    'UC!dlq1WLx*I}=S8-tp#4Vt$0Fyf>bEAc^u?sVI^4Nc7Q}*^bdfP!N@1@vbZ(%I4I3&F6;d`3p&-mu-^<jFv^c1NS!M-'
    'YAkt==T^D4~{_j8xyqxXgNu)_g?V5FL()goi4<`16;mQ4!#mxnLr-'
    '8jLqMZs65%NG=2t`Mo01}Y}G=5rQq*M%I*n63=}E)Y<}del)DjB9vTP^z6E?(>YZ8O(AfHhW@e<cO?#`Js)Dm<7?N{3TOgvDAmgI'
    '$r33b!EXt<`f{aLQU(U*2kHJhspaY3I61N#j2P%CrxKJFtx6_#nctju?qXecBcjVO1f!5e1*U16=3X`|xA`(ksz@nu<OQKS2oq`v'
    '&(rC8D#bp*j-zAG^4)A<XE*oS}&4&dP6a@8}ZF<cI=U?fQshs8iBAB@`iQ{jwYTTET@`R<-=VmM=*d@#p-'
    '>>w@RKsC>_V83V#B(5<7)RBP6oj}QQiMiZi*{OaKo|f*#MHR0=;|qr!XWoq{@GAvgGc|0C0q$qiQFQ)Gf9HbA{vF>u$TZNPs@2;?'
    'I09Z29||&2ine<V}fUJTEh%Me5UL!<GUSF17*owWKmZhmn>p2mA4e5N9%2O6mqno=yke<xJB+tP}C*MAC4dSDPSN28b_Ur*8FJkb'
    '<EW{6Ns&)i83_?-'
    'F(tkE7Y%+%)63^t;`jOrDs7$DSk1Cob8jRKp8Py4XzTW^XoU_=uXiDi2K8EGNk1yWwX@&FUML*o~dOO0V^%^S#24qc0w}6$xtdbH'
    'YyJ&w1vMYk`&6Fx3iG-hV?IOab0HfRB4<(q=6kc@Y&x@%4$TZ!%J)0<q3j}(^f>98ZnpZDM=9wrfRO$lmal8Hd5*e_YkC%|4xGjv'
    'pSCpU)G8<L#AF@4NRDIR=qNX9xg68&vq>jPi?bqzf7Z@WMj%99PZ_FIHa2+Nj+F^=OygvDzrIy{belQy!&I4*1HWkLs`FMO@M`ZU'
    'c}PHvC-dOss>&V3WW(3WpGDUC&jJB_W`9I%bvAJm1iIY_;i&ju(Q4bCO8NN<4s#IM<HP(J6QsOVLLkuo4f5cv^funrQHhkN~*<q$'
    'vfCD_PD6g<IcaCP`d8GBiROKH7?M2M@`dHAg?zx67B#Z9O-L-z@Ih73a*p2$m9B_dgFyr0jNh|FF*zp<$qw@#E*R-!5-'
    '0ToS0w(A#}SY=M?I$e=W4(ve?bIn%7x_<X0*Dvct}YyUfsJMOqHydF<ue-gUaTYHB@e6kGPb-'
    '}={#UVZ_DJF}Mkq?W`9vI&I|=FMANRZTpA^`bcv0Hqbj-'
    'q$Gw;yM7?Qk=2GKuuo)1LqH&(pTyuL9r^UB*H*|Qi>~?&AY19Ru@@CZJeC1e(*?7Vw}`=O5bFqi9EmNL|)wi>aC&DKS?S;;M-'
    'xf+1Zmfs+7o3l#V|ndSisCD{?RXShZdhq*zoy=Xl?a+ECinFVFp0j}kmMDvE?Yf5MjNbmi_C-'
    'x{^%+eWRigi#&{X~zUPTFbgepb7GVtxA-'
    '1nVq0(HBaauvpL9K1QXv<8J)EqrcT?CMnIb5mWG7m<^;>t0xRZr7M?cJO_5oio;w>g+GZxbO*83SiW(PLLwe0p=*SxOdhCixFSL0'
    '(lvHXwT&14`^UJa&ISiH2%!D_d0O4>z{pB-Vm4-6m(P9?MMhu#;x!{Hj&+BC==t0Xw8AiNLSTcfY&%A(px8;QDI-dODNU1(Xn?m}'
    '9z8;hWbg%%1%~3W-&zzGKj3b4@UMNEew0q<b<1%JSF~jdi;c(ZJ;VG`Pz&BDOlEpRt2J^GC7R|=RL{DY*(#9N-'
    ')T(N4I~l5ybok~HBZOeBP(CBst(2|7K=ch*H>{(HI7o-'
    'UD!T=5I~f^=Dq=Z1CTAdD8h&j^9NypoGyTz5qB(25j2)igX^&DW%Ss0ysA>qN;nywO=1MquF3JST87cAI`#;~x#CF%tLm}q`I2&U'
    'S`H`cUPf~d|Ft~yoYh4T-G_11WO{6aiy-1+j-qGBlmWM9(&V^t)u`8Hun?BYO?yRp2nhCb-'
    'C++$<VsjE1|Dn~%mIJj{LV!>Y66g}Dc}h2_CTX;^;FRE=*+12gv|JS}4-'
    'is?gsm$#?W=pmChw$4Ap5vR0dcD;=&xI>brQ$zpL`$yIS-'
    '%`q+dg{tpR9XtBoD_UH$CB9!3o)p_S`e+G8L&l%o`sqb1FijfB~wtU>I-x;}ZNnj$%bEroOmAkQl}rdD2XU`X84ZIU$xL-eZ1So-'
    'Gic`5~;V1IYYt1b28G>vZ6%`jT13yEf}fcH=>V>+gvv>xgCTEWTKHUn>7c{Iy<^NxI8;PYxRoJKlC+Xr>Lik;SYb6P1dZl!Ur;Y#'
    'am0?suV&-JKW6@7J9U8fgx#1%#)5gnJcCMYnzq^#jyq0NJ&X)0&w{%k_UcDRC^GvR8H<aI<y@B_||gW}K5E2~$O8pUMx-'
    '^g{=H2*6oFOwgUGq<IjEY>3v?4eRRV29pTj+|BCStHj51n6%@=Q-'
    'u)0d6)7R?(UwnxfQ!7rx#%PmV+R(j}4!ae&#<O^9vP*%W)J)Jo&9Zs-'
    '9Of8(zCC3S8BN)>TXHk(sVd9)}rYMEQ_O;;y0mZ~V?RI?V`-'
    't55hLpIt|Jp*cJf^E||e?>|y%*}P*!%jJT$YLkKRHHgy$kpM0*^$2~W%bWXbIbczsiQ~Fu+(d_Bm}sY<D`Matg}$g<L-'
    '=&&k|ONVd-tO;RP>aj^7e`=T$ITaJhY&!t6m7G+0aqt2ZmSsIiad*XOruj53)r-'
    'Y?uzQXvvl4Af^y9LglK=V)vkyzow;*42#+!astX*fql8EtGnR7v$J7K_x6SM->oWCTzUNO~~<q0zj_jx>zp>!LxWF#3kZd0-'
    '}GVThm`VWRM}WU<?c@F@pdUQJ7bYL&sKY{C?vN=h2(3M#_49jd`c?nj%^_m;imdOy>4OfD^xRxzG+0LZ}%bmKPNA8APPndc9x_?I'
    'eSIr}|^($=fk5H?1vj`LKB{4UzbAog^cx&4BD%E%G`bV?-'
    'HBk6B~dFjQ8h0&)il9Qcy6yy=f~w|&VC(r?*fb+>gzBY}e(<V5w=MH9`lKHpWc{9qBCHlI7rF;jMH%h3%UW>COmEB3>Umi3o5^?N'
    'HojP<(JbsR%g^Ijn43<i{w!L#j#WZvd?P)cF1sm`UsD4w|u`b)q@Dq(|3(E=JOzCOhPo{2hzOiAYR7!Sz&FzQZFo6Rf_Yc|)%5aH'
    '?{B9xc7!sK>n!oy+8;3Twf_=wt$uEtI8=HAyiFa^lEY}2xv4B1d#S-'
    '#>HdoFf*6c9uMH8vS%yZKN|0%@2m5oMhqab~(E)ZNQnLmI++9LeC=hiTwcX;^@l97S?z4h~_D9#GJB5y)dPo}zcU!t-'
    'u4p$wHHpE(n$bn8O8QyeB#=x3Kl!G9QQ*9h9vkx2-'
    'UX#+5HNEDXk3z><$>C=l~{(5^b<u=En`MYR2&AJFOG68JorGYnjH~AZJpb}o-j%~s_4XOabNbJM+<C2Iy7{noRmGgdf-fE4u4diL'
    '1?__xg6Z~omCVw@%P5!fjQ95n#HYi~B1Hzs05O&5Uyqt`u^q7DrW8L$v5myUz==aoDp^%BPKTe;$Wm;C7tUEN{dpzF4)Df+6a3_|'
    '{m1$?pAk)5rxg2?&{&)v$fHI!Iq{tYhWBaB|nNSvj;%5Bcoz%Io321IaRpj!srML9e8XFO&$N-'
    'DpZea3+9<!Zc6ElS@3ijwUQ8eewR<~g0=04VJt8BAYgy@3k6pv~4+v~oz%>x`itfFR4u7ZJ+Jf`Hx(22Y0Vo3dvIAW&ZUzj^bM1b'
    'uzwL?1j7E|eu`fpaFGI01Jtpc~fy5B0zEWZH<g!JU=Nz&44+nVqJL_wH_fz)as$vhLN0KE`7FF%kAh<*cot-pJVE-hqZLJi%Hher'
    'z#Vp<1g^GI2nyh_%WT}E5C%V>sxc~Wbc)2uNfYEC=z6)SV1W*(;u2qJ*#F4W1ij3TRy7kK@LKbjL0*Nw?IgP+3@_1M_S`sspHsVh'
    'm)=JwhHGhEJ8ApFLeK$EoJifb{05HMOX#KHIcPK{!ssH-XExy{qCfdD@@X@Ng)B^VVCv{W0jcTBV^Ce<Pp<G|@(;RXMR%>RmOG(S'
    '7RDFA1_6r87qYDL=$YZ<gSKMGo4GN%;%j#+AhN(B)HO9YqNV_Dv~G_~=W+!#cn#}RAGFBBDSYpjn-VaS(LB}q20rP3ECVn}VZ=08'
    '8RwYYi2V<^X8B)8j=EkKIlz>yQ>2G^P@2o^*g38BabGhi-'
    'F=P7o;n0Yb%Z_485n}3XwyU_eFP>8Y)L*67&>utyYi#MidLlwF>IzAjcC9QB7l6j>NM-R#%E-'
    'x#}jHQh9yD03(Q6U}Xl6d3Y*Z_xwakM5W4h|jJ|C^+zf!;h2w)R`>b<a0^jvlTsiqEhWEgqx|)ba3xW}c*z!m<#s1Zye~9y%>}2e'
    '^!88+-'
    'FuPf;Vn!&?vH0j?gzTPoB;Ar7Nmv!r>0=!YM2XcRb~(_ABt%#oTjRkJzJ?`LiejWeUN>y(+>Rra>4bk%rr^mlb836F7A#9>3Hr?#'
    'u<k`SR;4IF?AL0czklE|Z-'
    '8Wbc8N(F@$4YeB6Y?x{Xegi|w9%L(f9lEUgfp%}fuxiwYg^5FnJ|lTBHOMFEl!<_X<z<n`62(inMM!}I6>5)QuB9*$J?Klfqv#U>'
    'fD@=l<=h}e1Zr49!iFaRIJx39anP3O#%B)Al#MOI)nLE^(hQ>rEvyYn$xi7--E<o{V9leFp!l*t_Daqd%aKt3Qj^-'
    '7&NWE(YFJA}&8H<&oE?gUv7wkFqXltN`|Ps3wE$q1>22#!WYL}ptXc98oz=^U?{T^6%w9%>Q>-'
    '^Y2uIecAV(Yrf+nhp+Fhs%@qE%VFiI#Y3!o`+fjrnBp%WQR4=c0F;s`ZSGu@QQtrX0e(*Zq-'
    'Yz|@XL6Ta0RPw5Mr4ipgIERn_d_g+mI2}oW<AJ7Y#w&G6AH$uNAS?3Iy1HC&YsIoifEzEF-Gq`$&s{*24wvVhgSWqR$xFibbwFxZ'
    'g>d?l+NV_Qq~$lo1@(!~m7x_PlqowQ6|EH`<Ad;y8Rw%Wgv15m@%a>;G;-@4BBL~LD)HkaCBSdBn8vy{t9FOM3hu?-@5BS-'
    '=47&6K(yDd@Cv*D2`~HqtAS>g2Rtnik9fF)uZQYp&yfkWtnY34p~TU7w@=|bZ5n`B){2tQJJARP_PyX4E7OgKwHxCNY49q9rhsw?'
    'sobe<)T-'
    '47586wCC5vG4YxOH)8v^{msJh7&WBT16rz~dS8A4nj$?b1xk0q&BP1ox1{=>JH46rR=;p?UF`eOQPGdda60SsOaSZdm4wRWZ0dM_'
    'qZPXmp#BG+C$42lK;41t_jBB~8)?g61#8=326%(6#iszvaNc}_qh`6=QNAQGxrh;V6Un<J;6gIqY3@zTy)ukUr@3Kn9po*WHxi!F'
    '53--0PP;aeM*5?LCE9C~oPOIU_Az6HRVxR`A+vTMSlh>x@omu$+Ea0N(9@J2^1$BHeKo1AX5_4L#eAOSNgcbFBwMT9Cds;a%i__;'
    'zUlEqx4`>Ynk|MnV!_6^I{tvX7IY8=-'
    'K_$w57t)xn7*37l<H1ot(U{m69NDT|qEkFw#`aQ)oZkn0aB@z38OQ`}ZEJr}6!T;ah)$}%!CCC5bGY`WeCAE)hFM%C+cE_-'
    'H!IQ9<HGEju2gC5i2mg2XwnU1ojEsoP_e!JgnbQbt4OR6%Gb1A-YOU#GCa{fgrO+#Tp36+}s2-'
    'Gb;#Q=4IyRuTANQ<?95y!$0V}S`F)rX<EtMK9U{5t_dQcYaT#*W#arjI#<oOaHU~o#7E0n80MrqHbHktEG-MDl%ll{hsI|^Ns$gD'
    'DM#GNC_$z8SF?yxcAL<vpv3Xn{mMqD`jZA%-VPX!6~L>s}zYQ5B+LqnE93{TKLB?;O?-vGmVGr6uw>fB8!!GQ_1DOJJ`6hF)-'
    'JUkc3K|En(IEvRi0eM2I1IxDj(vqzT@L8#4G#h`+w3`WsMw!vCuB*co++cKwamkIPA;xhSkqF%%oFx4*)!aB>9>u3g!W(u<SKuM_'
    'RWnT6sCO61VC|_xV>L?-'
    'gT`99FveJ(&Z<p?R(jQHJS3Q@9z(4{URRyz48Tgxq#o)ko%H+yIB(Y5A&!~mWCxiHIF~5`%N2%q$FS^#?hTo<TbSfh!jDK<N^>z&'
    '0z8{j9m^GSMHsjgkS{elRPu?_)=(*MoH$42OekqWim(n*%0cFCh)GEw*vX0|8YN14^h*jQ+PAbK^%0XHR@mTXrCjHU)rnso&dGNr'
    '@=F<B<m&6NH3)^Fpid6=E)EhoHJ`&VIsJmq9}uUNj^TBYSeto4dR%zMP6zp{8Xhu3#QnEs<dG-'
    'f(&EEtJfUe}H*J5Sb@a@~gZDlx-xZSfM2mrU1aSAuMoW>G$~$@(Z~afNG;7_vPf1x#j=t6QKv}0SN4;{#=eKRakVNttXm1>o#@pB'
    'lBoo5$EBeYM22IPC|29n!h0aBodCv|+HcV_|3u+Oo@wl=V-GUmx!YU3*D98eOc5DIFsnSg?LMJUNEer)Fpxn-'
    'ZGHfV2Vr0F0ihERvloFg-<IfQBKxW!zXOhWxAEXZXt63`2svMb-vuB8e&@!K_Od7pxyyM;9mgk(nMZi|kZy)#J<$?6k(-'
    'o13cn%@kSmy&16>4|i$yI<5M~aGqe>9yHR;>*?*$eT4XFSYgd#F7x^fH<0ghplpYy^)b=*2@e0t;!GfE^)HjCXXz_EhiMEDo@*tC'
    'gMBqT)`$92}WfJYII5cM8$fRNTYsF9I2k$g#j7gtf%)l`5J*&$mL^5Y{$U6^`^oT$12rK*8c+3!a6LyYId2e6y04mdMte3t`-'
    '4HEv8v=h*7rCozL<ygFnx0ty7M+t;c4H0cck)C<YTa2W)Hj=$|40fVD)N(fhr;M#0trVFA8Hk!v|LPZOHSH)zgUxFh;409m~`Y3X'
    't<yH*cm#Um`$pC<n(<_M8q)mYnI!koX>aUxzGf4K%lou&ZHADzO+fKpno~Gt`#Nei|4Lq+yr+-'
    '36PIs;;kIGsJ9>CG|(vwzk8YAv}{9fYPrCR+?TtD%aqE{YFmna7!MCs*5{6%>>lf54s*GD{Z?bMTAeDRsq@k!~Sgjpz)9Ee%4da;'
    'hI#PzRS*BGZ<fSn$n&!h$2W<$JFesPr}zIrW#b4h{n;7c-'
    '6qo~)JIM`XbLALn3Z~o=S7c`&~je)*ti=<Q~D|moVRrw$nr`Y?#H;$IrTv9K~Bb1mkh38xOgsNV3{Ri@L45L&})hfe(h{EEp_vq`'
    'kQj&?Y+%mwQrJ+6-'
    'Z3N%OS>Vu0=ea9xMg_fyug2Nq87p?n*<nGo^3k03M66XVlQ5TS0T4t|W`wIb%Q080eApK_PCZ@FU??w7gkI<LujA|?(fJQ%`SL`r'
    'N9K709}r2maA^r)INK<*jTbOrLgvGz^xQZwEEza(918<nYKx0<H{+zJB5aOCXJopajGhP|VO!Bd3=8UPV2r1p-'
    '+4l>X8)L`=odYw^|oWp_!hqDd;+i@wXujA#PvHUuUo`#kPmUqm;GG@6c&PGY25X!t3#g6;DK9|Bxd?4lmnO$0}^w%#~&)ST5f%VO'
    'X!@Fz!WaPZ+T>fZ_i)jT&F2`Fo)Tr<alg+@~{t(pe&>28kBehvELd!zym$%)*7&9ujn08DW6$(8bAo2^~N(6a-'
    '&hlm!3+Ay9QyM26_`5l*U09&aCe6U>lm|o?bSMO#HRL(tVOGQxyPi1lP!mg-'
    'i*90b}@_vvH?v86N_4SvLq>sBNHWz80l7DRJam+Lu-p-'
    '|D9V$!P0nExIU|_tUB2M(qQ?K$NqzwR*}A#F>JdB)J<%$>~mXrT~Xa?JlB%wv4wvWJ|#qY)p32qTkJ3nw<V(rQ)8LfkUk@#56_OC'
    'OSP*G0KEBpL2aYGeo;dfo(3+6q3x0buGx0=#W}KnjHfS(M0Dn)BrW7v7-'
    'J#Iy6x2HACdk?0^P`lv~o(<z;3gQo7P1On<8;5<bhKAQ4>UT^tPtOa?|A3#bfJ(c$VoUFpZVKr*LGxUP~WtwKI<`7}=t>U|Q5+6I'
    '$(9kNfV0Dy?oWO%lWy=KHF+kg!@KcyK|Q_hiA$1vx;?T8Jw4=B!wClW=ni7iM(Z-O3IqfG*KjaXZlxEok-'
    '9=h!pN<Ko=hYKsV(Kh9o?RZT5Sy{0n;KLp`zaK8IW6iG$$L-@~nUobhWM3f~2u=AxSoLsr3bV1W8!vht7)|aV_tW;p!-'
    'ZG)X;v+x!8IT-RF=dJAPMVWdcU-@bXq|$I~daq*<@09RSiZ7Y&2l7ER?=#e~>zXC15lI93dvl0)nVu3wDXX6uSfr6=Djxa>-'
    '_S=<;ZbEuv0=(ref9;r&)HflqL4sU&ps|9w2NT<Hq6+Pw6>+K#^ID{(P=GgM4j_8(?unq=9sGs31X39bdS;wp*LN1ZR_-'
    'l!ygN|SV$xqVvp2GkgXYLgGYfgPPWI(V(@o4rhxLuKb0b{cfv^m%#8Bc80gLWb5uMVgk_QM|`uaFvM|1ZFhZZZNbogEzr2{>U-'
    '~s)1Je_AzIBK*W<m&kS?ds#}NlscAN_ke^D=#k$a0Mrt?YG{y=%6G*dI!j+?w?!J5pSQdAu0<nQyPl3QJr6tyW+OKecUl%2M;;3H'
    'e|G=KsPrxI^{N>ru(~kT=qwU)O?$YkRJlP@wfB*R%K7apTe)^Ap|L_0(^S}M{Uw{3dpZ@dn-'
    '(jy6n}dT><55ZzyxKoLVfy}6f$%qf`2P35`GO|??sWQR0C8M#n(HsH^R>X9@V_V>gVkU7hd+J)!*Bomc{Km{Ct1B@5Be%r^YX%L9'
    'h)x<qnE+$;&qX1`1*Zgo$R$rTIW^B0C(Pr4D=A+J5wGk4R6W_tqpU<@0$#7oGqh;iVSb#<%oGyrySX#pdviJ08&SgfEg$mmwRJUz'
    'S=D$tKji+UW>mqF9+i)NCb8FiZ5of_Kff5{cj#?uHbn#t@FC|WZ<N0JQ|a*_;BOYdo*(M8lDf$u%cACizjm;dNwe2DI2$V;D)b}2'
    'MgfH#xDU+Kl)$|(op=8m`wTkv6JHj3$=L6$#(LClE+1VA0Fb1k(`qLf%tc72?*%`GKcW68bYe#M>6lV*h4B7Rgwujme+~@#Qv9z+'
    'e`XkX({RRZtp_AOD?6ErtWzetFz@O<+AeF-'
    'u2W;99nbH8N^OjJtYXb96&eQ`}SN~ecT$uUZ`N#O)A&~P3l5jy?NEw5dn6~k9jV~Q?sKQ-'
    'H52_QJS8;UIbE#DZG#do^O>~cg`I)5P=;p;X`<h!}G_yiVNY6bxq5C@V+_rL>=1BrDfj5jSGfQtcFKwSkfdHE+}5bDXVAD0cWH8c'
    'X*8v=d`Y@Sp~gj=;~SmtQ!ujsK32ympx2+0PoxzhFsNIN40tvrwTsnj$JiSPfrJX-gJ|0*uw`62e!JHuf^Se{PAqv$=AR9`ahHs8'
    'Gbo)E%}dfPm@l|W+GU*8a+wpNqG1s7j<i_)-^FmbgO32U&>;CTgHxN3nEB#+~@pis@*DF=uhMdr5SWuYj|t{CE&pXX>qjP-'
    '<c5>rOn$l9bZNo-PZOBO)5Hds2H4}b3uO(eaAve@#TMlo1pMLzSv7{^%Fc_dtF^gj(r$`!gpp)+OId52>Pyhk^A8Q{b-'
    'AvzWGX}e82lrjK#Cn%*=m_4xTSWG)`kOGe#4}ka$e3CJ?Xv^cQBq7t|xex!3D0#7g-'
    'iD2Uz;LMiOIeiJqEstl?LyAX1Fi$Ot~(DMgqwxg4$FE|d?7e-'
    'S+e+~9Hw;u6m^rY}LudW5$z)x5&fx!hi_TiJA$B{`Qr$T5}d;~Zm$=uI=eM78Z!#5uS3}>hvraP=h<xFf_yZVJ&2Df9rbzTg09#c'
    '_s!=~|2jp<vTJ1U*7lER?dR^1N~PT>$0#?ntNNtwY_aY55wI-MS6JDX?6eEGHsR?>Uf#ZL&M=}Gix!syx&d7ntyM57~LQ#$6~ceA'
    'u#GK?pZSZH0!;KwQjR5WGs@i0JWcICbqD#!UdHjQgYFlz-'
    '^(dD_=nVI`2;mDH37jHYcRF3;HfDh`afX%jI?tD(re*1UDXoqex*&bYiG#xv4|NBV~5cxx%xNoxcUJ4=f57iKc!pB{@MLeixQAo3'
    'gx3*QcrcD8E@TXS<`claLdeFT~z@8kl%X6>)x2pahf4{>Ew6yUJBlcl6TND}=!~wnbLUeM{bLQpoI_C@sc9;eCYDdcU9>#4GmZED'
    'K*U7S8=^4>b{nz(dM9FK*nYC8bTOf=73VI;j6Kbp}UnHIXPt7GprEWO%K3dzNhSz>+nH+qUw(VeHm*>Qw6Dwdm^^2IT=%DB9*+KQ'
    's$N2r!xG}x<_LEOZ=;-?D*d=$aW61?$tT-6Mt(gFo;6&bgqfC%Pd7V_0$I3L%NF-DzI5J5I7VYMSzO6+LIvdp-WHCA&6rTi)mPLF'
    '@{mOR{_o6r=p<8rN?>FM)PbO#uz;fjyq+{=gf?=`O=t4})!QIPTcsoY!7H4(m|DFWp$#$jTGq^K4ibrAN7UHXdK>iR9*7ZUW%ClW'
    'EKd6wzprQ5Barp_81ZD%>S?&G|c2t~utDd@;vS7ICHIr_E2xfwWi<&$SxMQ#&pB@M@AZ<7j7t*d3&7;S)p>8c68>sY$!G+?$y`9E'
    'nKqCU-809aOs3Vtl4z$MJQk@*XuMl~8IVH1K36-$iHnPc>zH!ND)VnZ?XH0X97+HYTK*~8~-'
    '1(H+Wr77slw1lg3m7QSm(uIfYrZ)DlRlTKwdXu@pQ+gV<MU9D)-i)<;4i`t?a=?B;$On7e}E}E<+r<k6C@rY1Arg4%6P<kJ1-'
    'NcyrAVqZ*yFfKVMp3nHVU>Sc%&34J1l*aoonD2%{e`8f5G#b=BU(dCi6}sR56iQEHW$3ay$-'
    '@_;E9TeJnKgASy46h$I5$R1Av)`S#Bh6cGkp(jqavq}5fuB9*-'
    'aROAUfMwrT5hEfT5|H2!lF^vMJNrIno>@=;qHajwl!K?C!xU;^GxlldbCt9Zx$mHzaN>>T7Js0?1gQ+@mK3xi6+#@?eiml&nE&+v'
    'o0lFT8e<mvJ9tmE%xU(?-8`&ZLF%?FpYigazGSE0H9N)WaGe6_f`V=v$a5LuD?&-$W}nL^t3Bd?eIB~3R>p2}3=&-'
    '%$UxUNC$N*%?=`c)>CYH%2w(^;Z4H${D0S0&B^q}TUlNQc%PScAjrWMeV40cdz=x2;q)w!3d(fi>K%XhaBtYJ*bY9MZN8<vEF%Q@'
    'dzy_F;*N8#i_1Qe8sNGt_igBSbFSsXTjA8`2oD`wMcql`+#;9V7?PWtXV3^SWzAc?ouK^nYPcd0JbLY$W6sS$k*-'
    '^XO9)+FUaXxGoQ+^GBoOBG5Hnq0&pX1?cvRT=<cXV@AY7~=#C@dw(zs_J5`ts;;9#pDWiMs+m*c+bTnQ?idbx65#Vyh6?3gL#=Ez'
    'M2?^gpt`to1h6o1}g}vHk@U^eomL35S?oG;zy7*c4RhYDc^+uESLnRy#<F4a^Ion3XZ*+FODIO<7Qs-rvCP5fXNk0#<0%6wR!;*?'
    '&35e@NMj=;$Vy@%1}Ge%ng=y$bKehVql}cEqlc9sN}a9x%*+o;T!VRD<jmm3#j20#u;u#Evq^+ZU|q2=Wm67`!%4BH_0yE3GvY!x'
    'UI=${n=c4$Qzz1Vgo3&<(^}Lgd@pGXm~Au;~kZ6otHoPHkmQoNZC<L<%?h>n!T+5X~ZQ{^zNigJ&P*fo?Wk+v3534DdEytXBpM_-'
    '#rPzbx(LEd^YRDM_<rG`yFGe7)Y)R*Jt?h|CtXFSwQ=cn0thTti$iv2)icMrnL7^eViMl69+rK?nl6tx4K<yI$El@za5Cd+^47bA'
    '?fm;Ncay;BWUrD!iTm-'
    'V+bCNIj%U1ZyJ(A!1D0S`5C+zMx1;EG9FG9~A8wd&&|^2z6wH#{h#2co>QIV~?as0{#f5hGz)Q>;`o`hiHcF3o7Ric^tB`d{<Y?c'
    '`uf^D09Q%;CC%!nMkUnMH*@})d6m4$AT0oZ;5cEFU1(wTTPDd$2M_U<377YfOj@5Vz<BMc$8rS99J~E{Mc(0g*lU_)|yWZhCY`OA'
    'Jq7SQj76+W<AYjR;S4#<&tsjerA<JSJ<>e{YD)TDuOWc<Dry=Z57H<!r9Y^iPBpLgth|92VonGPNvE`LM$oT;-dIU=SqvP4{6-'
    'd>(!+$DAFh<w>@nJC`&vGzVwce%(0o4IHhly!e?Rj3}B&p&&A{uOm9z2hvjmteL<nox_jJ(yN#VdM-OCnl`1%mVhcMn4(2`b8&eI'
    'LEi#CmB`h36bW@0)4h3hoH~Oa=;;F0@&wLhiYqiZ73GsHPq<Zk=FOQnGe?FyZ1u@~WyU6itEn22H&PL4koJV$AB!2(>5C3FzIUkK'
    'C@cOu0No=*z<4F&29M||Hq%$Q<^E^A%pRxO6Lm~(*4QrWLquYEc-GU_68M@p-?*|wY?E#(CjzRkb-Kt2Ze|w~sYuaOsnOcm}7<ie'
    '9v6$0%d6=c(CiDzm*>K@i=^nGZL;RJ;pU14!jjz2z{edzCYGj8&I)L~0<8S3j$jl-'
    '?+Xi(UtRd^C7U9hD>6m?a0YL;uk5z>9AJwazGe#wQ9t8}I;$#d!DUMyN^>s>zHfmiP$g>9lPF68f0yIR@F7FWN3HXs)9%M>j1k-'
    '%JJ7&Dc7u9)ld5F~~b$znZ$dL!Jl_ItrMF~71hm*(-'
    '@O9RlstRaHl=C=}5KB3P$M;K!Cn@9|wa&BZfe@O>5syIsvUu{*?oixXU)`J8G?tll<yMmS`dKnk@2*vm>;B-'
    '$WIeT2b5M5dDLXiMSKkBN=k}LV(SnA!9c9xLnMBe&K^`h-d0UF-'
    '!VOZf9kHtYLsJq8HTd;FQlAlm;k4VuESgVA?>OUMh<M{=dS8ztgo$3yEX_JI&F=z&<CpYZf7DB91hP0*qvfrOY=}`mttU(Y0KCL2'
    'RP=sv%2t)X<HdHmxUe_1^1%@S`8@(tC4J2=EU)9Ue-blO9*_p-JK$F25SGk0l{TST{hmD=3NmU84kjjSL0v3EHzE1vh2mojjBQN|'
    'KHTy+S-C!nLvLcA1U1B2AX+9Ihd?{t^lj3BJ2T4yqeiC_Je0$UNw)c8NrjOQAu|K7bAc!e!Pc-Nw7lyNQL{1fGa`WnbY6hp$|eF>'
    'NeOPqMT%hm{6VPs6XhNSAwPjBJY-}L{kU6rKI(B8CLU0-'
    '9^G^f^3y1w+uDzmnrZPVMk)OapH%6KqrllfjhZa~$i1!xP|5qUQ}*qs*_ogDc)LzC-KG%FXhA<L!5wQ^bryfKHI_pyz1{+s+fX#f'
    'oZC@wE0wa&ph+Z7pZR{st#z=Q1($-'
    '*93|KL3b8}sN>p3x%Wy8vPG!WNyILkSG7rKi(8G6(Fh$5doqUA<#AJ9&8<TYp$wOQMg^XL6u7%4db8aZwHo$Ze?l){1k?a|5M=+p'
    '{Y_T<N`5#j55XkDp8lpnsTvP;Lpk6owg8g`u7yU=rn_&zuL-oi;*oTe4Ke4l}y~I`zO5c-'
    'Cq#<6c5*HH5y<k6wdaZLwc7E(yWAD`9kky6E!3yQ44zxYKJ+xX=@u=Gl6wqh{7X(VyNy4f~*pvmp5I3xqM<|7&V(8YCY_vGckwZ$'
    '_XZTGGQr^y0@GYw<KrG^*L7an$^AN|u9XSmz77jaQ>fq2*z*_CnQw(rwV<Cnr3&6_4;{@Ek--'
    'C1W*2yceDhop@S}7Pab2PXsj00PaQC--1oX}zir|=hBavqG6Ee#ejT#N~qQB#@i$Sx-'
    'X0J(pQa+>Ii#IrDp1HP^xp;`9<RKopt&bcwHeP)DR`E(dml;GIsh?d4Ji-`Rcz45bj?<H6kmY?dm#~{02U6hl+#>M9>-'
    '#+M1XL*FFdYvqd4lrNa0#t=nzFm@Kbog#yDR@p5$`&jl4WsM0b2*{Kb1D!9sz80j#kkoQjTciV)RKpqz0Yi7NkJ8br=JZ?Z}pT+M'
    'uXRM(p01C4N4InFEPgO`G_VupjHs|MWfGZSgM8Vh{T7Z0*<V(Uq_U><Co{(Zv~$8S4Kzp>r=EK!X;IK$*Q(R1TT0C&NRnTx@5hES'
    'jS=nGHSLm7_n>SeTs-jR&(?WEOKq_J*J8oxZVh~*{MkA*o_7gvbj<QY#iOFXTB}{jZ`SbZsw;dpc^k^JT_Q|u#O-'
    'U0`@zw&RW;he!=6n4FDT+6=bE5Cu8AcbCf2mi2{;jE5vvV46~{<Q{2kQBHLAd>RLd>Qt*DjpElU?ai<DvYKJ{0_z`NZd9(s|D~q*'
    'Ql;VzK(zmp$w*eWukZBot8aD-~MI9!R$nQZHQ4_!|rYG)m6;*|TvIl!~rg^|bEpJbF$I_T0?&$WvJ`Q+jQ|q_>;2`YINHDa-0-'
    'n_42N)!{dbxX%y_)QKX|~j;#zYxPL_O6GB{cXm3ox;gdtpyaA{87g^v*JP&1DQqmt!3MsK9DH&+X~H`YyTg4o0ugT?{$!`G@N{8U'
    '$-{lrvYRH4%&@@tnqZnHnQF?>!KQR<>(MlqZtG3}TUmZV$deCmCd}n~I$^g_vx^6iKt-'
    'Tq2bi*MhO>WKZ*8K})ujJhcOZtPE7TOmJ4J6)nAvq~;*oK-AgR@;7NhO8P)jrw`A*Dkpjr`j4K}?ktH(xQ3ZffVn*SJqvbX80i+c'
    'PXGW0Tvg<Tv@P-'
    'hXHTM`>*G+aPA@YBou~T}>4cU{2V2gLQf{%}92;DytQ16dn6nAfQG)m6QKNb`{}3+@+JSUg++ff%zRIYNENP32hYb{<u-'
    's)+9HPmg1T++RYuXOCC$G{#YCKdbh_hR4+Nya)C4{CK+)%K86(=j6D;eRcAhA_riweL!YOHEidWTMIw0*T~LOEZY3Dp>fOI;(4ZY'
    'VYOLI#U|w|m4Ns--Eg^*o*olf%h7hR6zecrI|HVtRiIBgA$h%Pq-Nj{(E}V8C+UfP>7@lyi|xoUWeCVd}pu5(P3kHcSwRBG{UIR*'
    '{!kJSe&Aa+49#DKojCIWt%`y*>BW5uQ>7$zF~8G$W$~&`!Z~CTpX)|2%s&^MFHy0H=?;kG}Y%VbPLR(s^z&fWR8QA=>m7o$4?e3%'
    '0ENqFW2R<yP=HDubY&g-1)@NS~qm4cS40+J=XP(I<$&t&=Z}5PtY(m9Us;^xY!>L4jpZ#!y;W%<a9SC!P0!0Dp{JlQw&WZcC-'
    'l1rnSd*J=y@-wlIk`#wfTVg&^gFMe(U)HW~3>&T*o3HXfn0AANoMc(XozpBuVEwx1sktv9X8q*pe5+Uq16>W3o>%H*f9tKE6o-'
    'wC+>uNFX(tEX;Mua-9Ws#+_vEJo`azrs)#5mK<MC6j0%AZ3xg1QUx+?Hj~DlF2CkcVfVh6KhRGK-jWxC&r7s7<o6l3Ua9D+ZqqH9'
    'k=pCE5hAS|rWSfuro6tf?>+JMe3blsyF<9LE9xiqmxT`^+dGF=mkwoU<Ne@V}I<mZU+Xl3pvV%=}MmVe^D@W|Vz8Iw2NLFl=3_ii'
    '#POQpluh@|XorQ#_vtKRS7>D*}NXW?-m<uHItfxdUg-'
    'W$lHY*Kw0IkP$X;Z4_={qeHl)#c_Aw$Ucyom$gvH@lgZLXJFtFPX)wrUot$eUqvwk;Nz=wiPBO}V-'
    'o<69={qQODt5)k~SZXwj9QYKGqKs<>oI5_<h!uc+;qr-'
    'c<Ug+$0E>@~%b7&a)2EOMhRr7o*AHN5^PVSEP}%296sXkKBzw0rNJf&0^&dm7yM=+~(ZyvZvQ=p+p=%J$IFn892y-'
    '4%1P~jziqd5*2)DW5L-G_yq7)mOq%a>f>`sBRSc;fH4HCymuP<xegK);!(_uIPMVe=IwhqJ^`lS`X-'
    '{FV@}D3Z(rL|cbOFiEoWxO``qSpM*)zk&y`i%;Qe>|_mojq8Zo)Cvwba;ys={3MAr&U_=Qujrdv!^E)kt+_V5?gi5n$5VFg{NSf3'
    'o-l3JOrwTmm>ySf@}I0f}+-y~L58`|Vi3sD>j5l(7+<e8DHd&aWw*0JQX?_icQB2nMfC-'
    'TiijrGsZ_mt}cimk6i2yZ83`ua4dLt5ExQU@;YH+6)tlw!{zK@%FHJVregHi1ePu9KmjElu1!kn=8<eS99)=wo7_p8J3yu-edZKf'
    '2{acp7F%Pp+LqaW9&9@hi;m)7s6k4edAuEh@04RoJ(lmauWz#8WmvJXaB9Eu?vvz84Lh2z!x9@1B16@elVEaGG*<Qz4KYv#5iw<l'
    '5Fu8iz;>MK5bNsV7HKRV(K)z3=e;JG!$uH*vuy*Hu5rvGNjB&~=ww9pwcDPKK+2N&pk_I<HBdU_q~xwCmKcf`<2!2v$VdI?WsuGg'
    '3z=*i>A12-u48;axi+YZ88yh;nSo`j}gU{`cK_lIYH;L59Xl&vKi$MV~YR#Iv#SY}V><iZN7CGP)-'
    't*z0LxMbkRNt!4P!qg}Z?AWQzCtEnN9W>=!3(3UlfzEZ&^2(}8Z7)sk4Q@KGjN0-^`-'
    'hws6uCaV0#Nt1YMICD{UPC|4x;%39hn+2Q9dnKpZF8v!D_f#Y6A4ow<zwo~s#t(N)9cvhLxC&BXHK!8nUN8`te|mH6u70u4UD%T6'
    'Bn<#t{a6Iftiy{AQDEcn^jLC%dRu<oqV@KD>Vb-Q0Eg6NJLtTh-;q7x|<M>b6oPU&EN4&%b@u+;#{Z>!3~HIbkaR_CXkld7-'
    'cM|7qZ&EM8qMY|6V0;mXK10xj6&U!pJ$l3N1}Wu7dY|@Nl~Wx-dQV<$tQv#o{Cbk#Q<JMJF)Il1FsaeDpha8nx<wRiFA}PbTVUVk'
    '{-=_|AMr&5=-5VkUH(^aP$y6{O0e@ysxnlPXoL>NaRU-&Nbumg4vS67SBRMU+Z+f{=i*Fsx1bN};i6q)Dx*97O?DMNXp)21zj-'
    '^$`2(m&<k6RV!Nii)%#1);QfxK!oa~wLI-knG;G&YSQ^sG8r60A3Cy6`5~rM@lORwUsLf3Txe9dnu>cAU^23=2u7Cdu0&hN;yO=}'
    'cT$dcTw9H;*p5|(!kVS?`$>7H3!ra`auaCF^n0X1E=ACm?c|#n0%|6HC$rIKmxxtP*KA_^fua+<@(%APFj;K?F!zk$Vq<l1B_+nx'
    '0O*H9yE!-'
    'e(Jgf)OXn#*ZmwlDHkd~z5(K1)kis%Qv^CwW=gOviFS$`$JgrS2<kPS6Mv)6+Xcn36T8n02>JGKr`FiTgRLzksI#(;>jPf26s-'
    '+8B2wfvejTU+m+19KBFry}FBrRMQ1uR5H9u7}6!|_B2sbjXL>SKXx*{ihAuwM(0;=7PDP-kXSQo%G>%9Ze5GM-'
    'I^g7<(;n}#Vxxtk5XR2KJDa7;Hh25)M8<lANFw3AKI`VD9iQoL2*72{6O*1x{1n<by*6A4Y|lg*SOf;8A}Y)e*9WwYC4m>=R1<Z5'
    'EEg`dXEl}nxzuTvFQfm-'
    '+msc78p4ZuDI(pDEJ0_+8~2`1aV+4iFD%S}^8bD6&MDt7d&np|O<16U^xd%k2&7j+Ff;I)BjBe!Qntw$QQGP^c)g2s&freoJyIHe'
    '-4(8EB_wyQCKkVw$LLW>m!HK>FE)+#egqry#R%ic~t_9G)C8TwoBU;?X|lXxO3MR7A;8!~aM$1SN?KL_p=Q=biczO;6~ff!2?4Po'
    'Dm%v_Ae80os!Dwh4w4zxV_f-BidI>D%v;H()M7a@1D-Euck9hz$h!Kz5J?7)6LG4;fIe(iHRQW$KAQDEL!BE@iK5G|_QDGkjkI-'
    '7A(!`O*=z~QHhDbNgErO6AmknmVCrtjqOM$MKbO4dpt5EsE8aNgZv9fhTxX6bNSJVdk4uLe2N4o%i%<}qe`gQUllDPhWO$d(ls0Z'
    'rK+rkcw9J{8{_fKi5JxkN1=03Cuhphyc6%HbK*$(qUZlR?6VY_#%7b`*f{WxAp#SWK4I93b8dM-'
    '46rRRsK!vvaxqZhXDR?Dbapjf!i1dMA@J5r$l~E~Zi=%OY$vQMN%;WthjNk6Xu{BEM@c;t#HZq-FD*xSsK*t~U{~*pO8l)_h({K8'
    '*+6#f2F+mq!Gqs@`y?U~j{w?UvD)vGae?vOZOar}TO^(Bjq1c}awS9?H#>+X@9S0UJv@DE;you0QaiiJ2osjzsca>)x8HFm$;ZUR'
    'RCwdZYHbifmAuvXT~&Ux5U#e8VAKiHh9(5)fQ+B&O#IzDO4)LNd5{7ygfK5<k@V1dGQa`lh4`DrcTcQp{w0QE(X)F$?ZmIWlxJb3'
    'Mk<9RE2EL&Q3!P1o~d6C<{oVN=KDlGug<<Dn&!x7t+<1-p584<7K>qiJY-'
    '$%snKjcR*bn1zm<S82j#$TxXouLSnaj9zo|J!S2lW7`!k(H5NLujoMOZ~#po>uZGAlaWHq-'
    '!%?gm`c<7QzFb8nC+b%=r!ILEMoxOSjO@4X(O4b8s$^j1#~r;-{eu`u{vFZ3g3~eQH}AZSMFp+Q<VlIWL>~V6D|J<-'
    'a^Q$Pf<;1Gwmzp&Oon8CL!dO*~mP%eC5v4|IKdl^ez-@UuMDTKCaq_6m4q?Sw-'
    '{{{2MdTv|RP@nw1U34l>0KweV3zAS;Tho7}ocKBRy>p!NHUX0cv-'
    'pL_(s!0&#^_J*Eq8|#U7x<@@uU7Kq+(G}5i%Jmpt$LCGF5p8QFUiq-zYtR}I-'
    '{2wTw8fdHD$MuH5hL!M%QC}vh+j}$S9|jW95zy9tywe#=n%Gs<?U@(MJ^pxZ_e?UeaUs)w^Rftn~2>lZr!j`YR6TPHDwW*Uf+3su'
    '9;%2gOnPZblpU*BPY@u^IJ4oc8;B}IY;t^Mr;)+J<YQHV#!qLpc00Ou7^p3m?wEVW=1yALeZ3vuuP%yIj$aJt{GwoWvC9nMVdU%l'
    'O}818!}Hnb_hu4<!VQdO>vC?yX}F<I^cjl6l)7uuWv&Nzx{qJ>0!B?*#}4H&vk)+Q2rpEhcrit;6t3XT4=8!hrOc|(6cP`;)ZhXV'
    'ug8Kv?gS_?qG5V$Cfpf%23Ai9;6a=aZ~|o5D7D?$F(d5O&z_wku`#Cg*M%T4>T@;t$aYyr-pTs?xtTfCsM0@sUZ+X<rn&Vn6bxZ<'
    '*(S#N@;xQMP-0%yL#7L-4(GW_~2`ujrV>!U8@`eNJE-'
    'R@7yeVM3)QiA)W8+izr|rDjzaPadP!d{1Ua1$<J)A^lTEHA(WIQNztS<z>_ORt)#V4T2GhQjMa?#pInbrM?$9EXW63b@#LTWRAB6'
    'y8cEa;QOY^-'
    'gKwe~5)&#HTpOwg!$tn<@`{CR)#AkoUe17?*`hHd#%EJ>;M0)(D`TpG!+|wmpX=+mV*ruFpKx5`p=KTyH9pxL%8~VDKhS<p2WZVd'
    '@vBEFGH{jM*m2--@V>+a56>fFxF^$6(WNc1`Il92-w`55KJ7s_5WEU<#Ykfe2zB8mYPI0fCK?-'
    'olfQtdoW=cOh8M;8$S{_)%5t<mI#|@FrOO_BdTx;pP5u~z62ZKze#vY<zr5Vh8}!m%=he%fffpu^MTha^2#zs9gN$Hp*W6iEjFEG'
    '#0(y4Tw76(O##32}yG)ceFKCw35e?~f&PxkjDRzj_8Ho9V>q*8sDQRGBoSP0kL$dEhfuE+}^~8Leg~1yIxon<a15!|(sr;a!xcCg'
    'R<Xwg(G)u!dhN2O7ZRZwNl6pGMuuz1S{0H|);m*7J4Qw7ubez%2XWCP0d!A=c{os8{b+q6cFme{@*r*I}t9g@VPP97$eR-'
    'X7!Aj87RMe~3YjP6lGoi?`e}Wq`Sp!+d+7xzO3v4zoVCWU4giewvP`0$dC~<JI<{;Kb1@dv*{%Y3?){HZNiK>IQx&E7yV`Gzc6*l'
    '_L?~`*DYz`)P_=5PY>th=-Upc2J_U*}Eo+IM5Jd{C}^o?I15WVq~ALz1K{+5G0|KI-u7i)Bt'
)
)).decode("utf-8"))

from v44.gold_floor import GoldFloorConfig as _V48GoldConfig
from v48.fast_route_router import FastRouteConfig as _V48Config
from v48.fast_route_router import build_fast_route_router as _v48_build
from v23.state_encoder import get as _v48_get

_V48_CONFIG = _V48Config(**{'yarn_first_start': 88, 'farm_first_start': 120, 'yarn_second_start': 153, 'yarn_third_start': 216, 'yarn_third_prefixes': (('BRUNCH_SPOT', 'PET_CAFE'), ('PET_CAFE', 'FARMERS_MARKET')), 'terminal_rule': 'collision'})
_V48_GOLD_CONFIG = _V48GoldConfig(**{'clone_preempt_horizon': 2, 'clone_streak_required': 24, 'clone_distance_threshold': 2.0, 'clone_detection_start': 48, 'clone_maximum_batch': 10, 'clone_active_start': 160, 'bakery_capital_enabled': True, 'bakery_capital_start': 160, 'bakery_capital_second_shops': ('PIZZA_SHOP',), 'bakery_capital_minimum_cows': 3, 'bakery_capital_minimum_sheep': 2, 'bakery_capital_minimum_melons': 10, 'bakery_capital_maximum_geese': 0, 'clone_veto_enabled': True, 'clone_veto_step': 120, 'clone_veto_first_shop': 'BAKERY', 'clone_veto_minimum_sheep': 4, 'clone_veto_maximum_cows': 1, 'clone_veto_minimum_wheat': 8, 'clone_veto_minimum_melons': 7, 'clone_veto_maximum_geese': 0, 'clone_phase_detector': False, 'clone_phase_horizon': 3, 'clone_phase_maximum_batch': 20, 'clone_phase_detection_start': 144, 'clone_phase_detection_stop': 159, 'clone_phase_minimum_excess_units': 2, 'clone_phase_maximum_excess_units': 4, 'clone_phase_future_window': 2, 'clone_phase_items': ('STRAWBERRY', 'MELON', 'MILK', 'WOOL'), 'terminal_rule': 'collision'})
_V48_POLICY = _v48_build(_V48_ROUTES, _V48_CONFIG, _V48_GOLD_CONFIG)


def agent(obs, configuration=None):
    try:
        return _V48_POLICY(obs, configuration)
    except Exception:
        seat = 1 if int(_v48_get(obs, "player", 0) or 0) == 1 else 0
        farms = list(_v48_get(obs, "farms", []) or [])
        farm = farms[seat] if seat < len(farms) else {}
        return {
            "farmer": ["PASS"],
            "hands": [["PASS"] for _ in (_v48_get(farm, "hands", []) or [])],
            "market": [],
        }


def _kaggle_submission_entrypoint(obs, configuration=None):
    return agent(obs, configuration)
# ===== v48plus: hand-ported V50 economic layers on the v48 decoded source =====
# Base: references/data/intel-notebooks/v48build/main.py (sha256 dadee25a…),
# the byte-exact source of the running v48 public-derivative submission.  Every
# layer below is appended AFTER the base file; no base line is modified.
#
# Upstream sources (public notebooks, Apache-2.0, notices retained):
#   * V49 "kaggriculture-v49-funded-sale-timing-and-worker" (agent sha
#     ed89be8c…) carries the open economic layers of Thomas Tschinkel's
#     "The 2945 Farm" (v9/4): COURIER, CARROT/CARROT2, HERD, FERT, ORDERPRI2,
#     CAPHARV, SHEDROOM.
#   * V50 "kaggriculture-v50-early-yarn-commit" (agent sha 044a2660…) adds
#     weedlag (EXP338) and v233x (day-11 yarn commit + last-day skips).
# Ported here (subset chosen for substrate compatibility with this base):
#   * COURIER  — evening walk-and-drop of premium cargo with a same-day SELL.
#   * SHEDROOM — sell shed goods before the midnight auto-drop would discard
#     them at the shed capacity limit.
# Ported, measured, then removed (kept out of the shipping build):
#   * CAPHARV  — harvest-before-cap rescue.  On this base's six routes it never
#     found a swap candidate (the tapes already harvest animals before their
#     caps: 0 swaps across every tracked game, see
#     exports/probes/v48plus/v48plus_layer_ablation.json), so the layer was
#     dead code here and is left out of the build.
# Not ported, with reasons:
#   * weedlag (V50) — already carried by this base: scripts.v22_weed_repair
#     replays weed-blocked build/plant intents for the same bounded 8 steps.
#   * v233x day-11 yarn commit (V50) — no V233 substrate in this base: the
#     six-sheep V233 project, its per-day request/confirm state machine
#     (_v233_request/_v233_worker/_V233_STATES) and its day-12 expansion do not
#     exist here; this base's yarn routes already commit sheep on days 7-9 and
#     buy their second land on day 11 (step 265 of yarn_fast).  Accelerating a
#     tape expansion that does not exist would be a route rewrite, not an
#     economic layer, and upstream's +3,674 paired-margin claim is measured on
#     the V233 substrate only.
#   * CARROT/CARROT2/HERD/HERD2/COWSWAP/FERT/ORDERPRI2 (V49) — require the
#     upstream closed-loop chassis (_IMPL.chassis) or crop-yield simulation
#     hooks this base does not expose; porting them would rewrite validated
#     route behaviour rather than append layers.
# Engine facts this port relies on (verified in vendored kaggriculture.py):
#   * dawn reset: farmer respawns at the shed spawn, all hands are fired and
#     inventories auto-drop into the shed, so a courier detour cannot leak
#     position drift into later days;
#   * unit actions resolve before the market, so a DROP followed by a SELL in
#     the same action sells the dropped units the same step;
#   * the midnight auto-drop runs after the day's last market and discards
#     overflow above shed capacity;
#   * animal production on a fed night yields 1 + pending_care_bonus (one
#     bonus per cared+fed day), capped at the animal's max_held.
# All layers are pure functions of the observation plus per-seat state that
# resets on step 0 and on step rewind; every layer is individually guarded so
# a failure falls back to the unmodified base action.

from v19_terminal import MAX_ORDERS as _V48P_MAX_ORDERS
from v19_terminal import projected_shed as _v48p_projected_shed


def _v48p_standard(configuration):
    """True when the episode runs on the standard board the tapes assume."""
    if configuration is None or not isinstance(configuration, dict):
        return True
    for key, default in (
        ("boardSize", 10),
        ("turnsPerDay", 24),
        ("shedCapacity", 100),
        ("maxMarketOrdersPerTurn", 10),
    ):
        if key in configuration and configuration[key] != default:
            return False
    return True


def _v48p_access(board):
    half = board // 2
    return ((half - 1, half - 1), (half, half - 1),
            (half - 1, half), (half, half))


def _v48p_tape(seat):
    """The selected route tape for a seat (the planner replays it open-loop)."""
    try:
        name = _V48_POLICY.selected.get(1 if seat == 1 else 0) or "default"
    except Exception:
        name = "default"
    tape = _V48_ROUTES.get(name)
    if not isinstance(tape, list) or not tape:
        tape = _V48_ROUTES.get("default")
    return tape if isinstance(tape, list) else []


_V48P_REPORT = {
    "courier_trips": 0, "courier_units": 0, "courier_errors": 0,
    "sr_turns": 0, "sr_units": 0, "sr_errors": 0,
}


# ---------------------------------------------------------------------------
# COURIER (from The 2945 Farm v9 layer, as carried by V49): from hour 12 a
# tape worker carrying premium cargo whose every remaining command today is a
# PASS or a move walks to the nearest shed-access tile, drops, and the units
# are offered in the first market slot the same day.
# ---------------------------------------------------------------------------
_V48P_COURIER_ITEMS = ("STRAWBERRY", "MILK", "WOOL", "MELON")
_V48P_COURIER_FROM_HOUR = 12
_V48P_COURIER_IDLE = frozenset(
    {"PASS", "NORTH", "SOUTH", "EAST", "WEST", "DROP"})
_V48P_COURIER_MOVES = {"NORTH": (0, -1), "SOUTH": (0, 1),
                       "EAST": (1, 0), "WEST": (-1, 0)}
_V48P_COURIER_STATE = {}


def _v48p_courier_walk(pos, target):
    x, y = pos
    tx, ty = target
    return ([["EAST"]] * max(0, tx - x) + [["WEST"]] * max(0, x - tx)
            + [["SOUTH"]] * max(0, ty - y) + [["NORTH"]] * max(0, y - ty))


def _v48p_courier_plan(tape, unit, pos, commands, step, end, board):
    """Walk-and-drop route for an idle tape worker, or None if it has work left today."""
    if commands[unit] and commands[unit][0] not in _V48P_COURIER_IDLE:
        return None
    for t in range(step + 1, end + 1):
        a = tape[t] if t < len(tape) else {}
        units = [a.get("farmer") or ["PASS"]] + list(a.get("hands") or [])
        command = units[unit] if unit < len(units) else ["PASS"]
        if command and command[0] not in _V48P_COURIER_IDLE:
            return None
    access = _v48p_access(board)
    target = min(access, key=lambda a: abs(a[0] - pos[0]) + abs(a[1] - pos[1]))
    walk = _v48p_courier_walk(pos, target)
    return walk + [["DROP"]] if len(walk) <= end - step else None


def _v48p_courier(obs, action, st):
    step = int(obs["step"])
    player = int(obs["player"])
    if step >= 718 or step % 24 < _V48P_COURIER_FROM_HOUR:
        return action
    day = step // 24
    if st.get("day") != day:
        st["day"] = day
        st["plans"] = {}
    tape = _v48p_tape(player)
    if not tape:
        return action
    farm = obs["farms"][player]
    positions = [tuple(farm["farmer"])] + [tuple(p) for p in farm["hands"]]
    inventories = obs["private"]["inventories"]
    commands = [list(action.get("farmer") or ["PASS"])] + [
        list(c) for c in (action.get("hands") or [])]
    commands += [["PASS"]] * (len(positions) - len(commands))
    end = day * 24 + 23
    plans = st["plans"]
    # Only tape workers: overlay-dedicated hands are appended after the crew.
    crew = 1 + max(len(tape[t].get("hands") or [])
                   for t in range(day * 24, min(len(tape), end + 1)))
    board = len(farm["tiles"])
    delivered = {}
    changed = False
    for unit, pos in enumerate(positions[:crew]):
        inventory = inventories[unit] if unit < len(inventories) else {}
        cargo = {k: int(v) for k, v in inventory.items()
                 if k in _V48P_COURIER_ITEMS and int(v) > 0}
        plan = plans.get(unit)
        if plan is None:
            if not cargo:
                continue
            route = _v48p_courier_plan(tape, unit, pos, commands,
                                       step, end, board)
            if route is None:
                continue
            plan = plans[unit] = {"route": route, "start": step}
            _V48P_REPORT["courier_trips"] += 1
        index = step - plan["start"]
        if index >= len(plan["route"]):
            continue
        command = plan["route"][index]
        if command == ["DROP"]:
            if pos not in _v48p_access(board):
                plans[unit] = {"route": [], "start": step}
                continue
            for item, n in cargo.items():
                delivered[item] = delivered.get(item, 0) + n
        commands[unit] = command
        changed = True
    if not changed:
        return action
    result = dict(action)
    result["farmer"], result["hands"] = commands[0], commands[1:]
    if delivered:
        market = [list(o) for o in action.get("market") or []]
        prices = obs["market"]["prices"]
        for item, n in sorted(delivered.items(),
                              key=lambda kv: -int(prices.get(kv[0], 0)) * kv[1]):
            if int(prices.get(item, 0)) < 2:
                continue
            existing = next(
                (o for o in market
                 if o and o[0] == "SELL" and len(o) >= 3 and o[1] == item),
                None)
            if existing is not None:
                existing[2] = int(existing[2]) + n
                market.remove(existing)
                market.insert(0, existing)
            elif len(market) < _V48P_MAX_ORDERS:
                market.insert(0, ["SELL", item, n])
            _V48P_REPORT["courier_units"] += n
        result["market"] = market
    return result


_V48P_COURIER_PARENT = agent


def agent(observation, configuration=None):
    action = _V48P_COURIER_PARENT(observation, configuration)
    try:
        player, step = int(observation["player"]), int(observation["step"])
        st = _V48P_COURIER_STATE.get(player)
        if st is None or step <= st["step"]:
            st = _V48P_COURIER_STATE[player] = {"step": -1}
        st["step"] = step
        if not _v48p_standard(configuration) or not isinstance(action, dict):
            return action
        if step == 0:
            _V48P_REPORT["courier_trips"] = 0
            _V48P_REPORT["courier_units"] = 0
            _V48P_REPORT["courier_errors"] = 0
        return _v48p_courier(observation, action, st)
    except Exception:
        _V48P_REPORT["courier_errors"] += 1
        return action


# ---------------------------------------------------------------------------
# SHEDROOM (V49 layer): in the last two hours of the day, sell shed goods that
# the midnight auto-drop would discard at the shed capacity limit (with a
# small safety margin), keeping the tape's next-day feed and fertilizer.
# ---------------------------------------------------------------------------
_V48P_SR_MARGIN = 4
_V48P_SR_HOURS = (22, 23)
_V48P_SR_PRODUCTS = ("WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON",
                     "EGG", "MILK", "WOOL", "FERTILIZER")


def _v48p_sr_tape(seat, t):
    tape = _v48p_tape(seat)
    if t < 0 or t >= len(tape) or not isinstance(tape[t], dict):
        return {}
    return tape[t]


_V48P_SR_PARENT = agent


def agent(observation, configuration=None):
    action = _V48P_SR_PARENT(observation, configuration)
    try:
        step = int(observation["step"])
        if step == 0:
            for key in ("sr_turns", "sr_units", "sr_errors"):
                _V48P_REPORT[key] = 0
        if not _v48p_standard(configuration) or not isinstance(action, dict):
            return action
        if step % 24 not in _V48P_SR_HOURS or step >= 717:
            return action
        seat = int(observation["player"])
        farm = observation["farms"][seat]
        priv = observation["private"]
        board = len(farm["tiles"])
        access = _v48p_access(board)
        proj = _v48p_projected_shed(observation, action)
        market = [list(o) for o in (action.get("market") or [])]
        left = dict(proj)
        night_shed = sum(max(0, int(v)) for v in proj.values())
        for o in market:
            if len(o) >= 3 and o[0] == "SELL":
                got = min(max(0, int(o[2])), max(0, int(left.get(o[1], 0))))
                left[o[1]] = left.get(o[1], 0) - got
                night_shed -= got
            elif len(o) >= 3 and o[0] in ("BUY_PRODUCT", "BUY_ANIMAL"):
                night_shed += max(0, int(o[2]))
        units = [action.get("farmer") or ["PASS"]] + list(
            action.get("hands") or [])
        carried = 0
        all_positions = [tuple(farm["farmer"])] + [
            tuple(p) for p in farm["hands"]]
        for i, pos in enumerate(all_positions):
            inv = priv["inventories"][i] if i < len(priv["inventories"]) else {}
            held = sum(max(0, int(v)) for v in inv.values())
            cmd = units[i] if i < len(units) and units[i] else ["PASS"]
            tile = (farm["tiles"][pos[1]][pos[0]]
                    if isinstance(pos, (list, tuple))
                    and 0 <= pos[1] < board and 0 <= pos[0] < len(farm["tiles"][pos[1]])
                    else None)
            op = cmd[0] if cmd else "PASS"
            if op == "DROP" and tuple(pos) in access:
                held = 0
            elif op == "HARVEST" and isinstance(tile, dict):
                held += max(0, int(tile.get("yield_units", 0)))
            elif (op == "COLLECT_FERTILIZER" and isinstance(tile, dict)
                    and tile.get("fertilizer_available")):
                held += 1
            elif op in ("FEED", "FERTILIZE") and held > 0:
                held -= 1
            elif op == "PICKUP" and len(cmd) >= 2 and tuple(pos) in access:
                held += max(1, int(cmd[2]) if len(cmd) >= 3 else 1)
            carried += held
        cap = 100
        if isinstance(configuration, dict):
            cap = int(configuration.get("shedCapacity", 100))
        overflow = night_shed + carried - cap + _V48P_SR_MARGIN
        if overflow <= 0:
            return action
        need = {"WHEAT": 0, "FERTILIZER": 0}
        for t in range(step + 1, min(719, step + 25)):
            act = _v48p_sr_tape(seat, t)
            for c in [act.get("farmer") or ["PASS"]] + list(
                    act.get("hands") or []):
                if not c:
                    continue
                if c[0] == "FEED":
                    need["WHEAT"] += 1
                elif c[0] == "FERTILIZE":
                    need["FERTILIZER"] += 1
        prices = observation["market"]["prices"]
        cands = []
        for item in _V48P_SR_PRODUCTS:
            spare = int(left.get(item, 0)) - need.get(item, 0)
            if spare > 0 and int(prices.get(item, 0)) >= 2:
                cands.append((int(prices.get(item, 0)), item, spare))
        cands.sort()
        sold_now = 0
        for price, item, spare in cands:
            if overflow <= 0:
                break
            q = min(spare, overflow)
            for o in market:
                if len(o) >= 3 and o[:2] == ["SELL", item]:
                    o[2] = int(o[2]) + q
                    break
            else:
                if len(market) >= _V48P_MAX_ORDERS:
                    continue
                market.append(["SELL", item, q])
            overflow -= q
            sold_now += q
        if sold_now:
            _V48P_REPORT["sr_turns"] += 1
            _V48P_REPORT["sr_units"] += sold_now
            action = dict(action)
            action["market"] = market
    except Exception:
        _V48P_REPORT["sr_errors"] += 1
    return action


def _v48plus_entrypoint(observation, configuration=None):
    return agent(observation, configuration)


agent.telemetry = _V48P_REPORT
